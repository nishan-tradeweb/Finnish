/* OCR for PDFs that cannot be read as text (scans, damaged fonts). Runs ON THE DEVICE with Tesseract (tesseract.js):
   the engine and the language pack are downloaded once while online and kept on the device, so later runs also work offline.
   Nothing is sent anywhere – the page images stay on the device. There is no cloud / AI-vision option by design. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {};
  var TJS = 'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';
  var LANGPATH = 'https://cdn.jsdelivr.net/gh/tesseract-ocr/tessdata_fast@4.1.0';
  var LANGS = [['mal', 'Malayalam'], ['hin', 'Hindi'], ['tel', 'Telugu'], ['tam', 'Tamil'], ['ara', 'Arabic'], ['eng', 'English']];
  var GUESS = { ml: 'mal', hi: 'hin', mr: 'hin', te: 'tel', ta: 'tam', ar: 'ara' };
  THK.ocrLangs = LANGS;

  function loadLib() {
    if (window.Tesseract) return Promise.resolve(window.Tesseract);
    return new Promise(function (ok, bad) {
      var s = document.createElement('script'); s.src = TJS; s.crossOrigin = 'anonymous';
      s.onload = function () { window.Tesseract ? ok(window.Tesseract) : bad(new Error('The OCR engine did not start.')); };
      s.onerror = function () { bad(new Error(navigator.onLine === false ? 'OCR needs the internet the first time (about 5–15 MB for the engine and language). Connect and try again; afterwards it also works offline.' : 'The OCR engine could not be downloaded. Check the connection and try again.')); };
      document.head.appendChild(s);
    });
  }

  /* lang: 'mal+eng'; o.progress(pageNo, total, status, fraction); o.cancel = { v: false } */
  THK.pdfOcr = function (buf, fname, lang, o) {
    o = o || {}; var cancel = o.cancel || { v: false }, worker = null, doc = null;
    function stop() { var p = worker ? worker.terminate().catch(function () { }) : Promise.resolve(); worker = null; try { doc && doc.destroy(); } catch (e) { } return p; }
    var cancelled = function () { var e = new Error('cancelled'); e.cancelled = true; return e; };
    return Promise.all([loadLib(), THK._pdfLoad()]).then(function (r) {
      var T = r[0], m = r[1], cur = { p: 0, n: 1 };
      if (o.progress) o.progress(0, 1, 'Loading the language (first time: downloading)…', 0);
      return Promise.all([T.createWorker(lang, 1, {
        langPath: LANGPATH, gzip: false, cacheMethod: 'write',
        logger: function (e) { if (o.progress && e && e.status) o.progress(cur.p, cur.n, e.status, e.progress || 0); }
      }), m.getDocument({ data: new Uint8Array(buf.slice(0)), cMapUrl: new URL('vendor/pdfjs/cmaps/', document.baseURI).href, cMapPacked: true, isEvalSupported: false, verbosity: 0 }).promise]).then(function (w) {
        worker = w[0]; doc = w[1]; cur.n = Math.min(doc.numPages, 400);
        var pages = [], conf = [], i = 0;
        function next() {
          if (cancel.v) throw cancelled();
          if (i >= cur.n) return Promise.resolve(pages);
          cur.p = ++i;
          if (o.progress) o.progress(i, cur.n, 'Reading page ' + i + ' of ' + cur.n + '…', 0);
          return doc.getPage(i).then(function (pg) {
            var vp1 = pg.getViewport({ scale: 1 }), sc = Math.max(1.6, Math.min(3, 1800 / vp1.width)), vp = pg.getViewport({ scale: sc });
            var cv = document.createElement('canvas'); cv.width = Math.round(vp.width); cv.height = Math.round(vp.height);
            var cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height);
            return pg.render({ canvasContext: cx, viewport: vp }).promise.then(function () { return worker.recognize(cv); }).then(function (res) {
              var items = [], lines = (res.data && res.data.lines) || [];
              lines.forEach(function (ln) {
                var words = (ln.words || []).filter(function (w) { return w.text && w.text.trim(); }), seg = null, h = Math.max(4, (ln.bbox.y1 - ln.bbox.y0) / sc);
                words.forEach(function (w) {
                  if (w.confidence != null) conf.push(w.confidence);
                  var x0 = w.bbox.x0 / sc, x1 = w.bbox.x1 / sc, y = vp1.height - ln.bbox.y1 / sc + h * 0.2;
                  if (seg && x0 - seg.x1 < vp1.width * 0.05) { seg.t += ' ' + w.text; seg.x1 = x1; }
                  else { if (seg) items.push(seg); seg = { t: w.text, x0: x0, x1: x1, y: y, h: h }; }
                });
                if (seg) items.push(seg);
              });
              pages.push(THK._pageRows({ items: items.map(function (s) { return { str: s.t, transform: [s.h * 0.8, 0, 0, s.h * 0.8, s.x0, s.y], width: s.x1 - s.x0, height: s.h * 0.8 }; }) }, vp1.width, vp1.height));
              cv.width = cv.height = 0; try { pg.cleanup(); } catch (e) { }
              return next();
            });
          });
        }
        return next().then(function (pgs) {
          var avg = conf.length ? conf.reduce(function (a, b) { return a + b; }, 0) / conf.length : 0, low = conf.filter(function (c) { return c < 60; }).length;
          return stop().then(function () { return THK.pdfPagesToScript(pgs, fname, { method: 'OCR (' + lang + ')', ocrDone: true, ocrInfo: { avg: Math.round(avg), low: low, words: conf.length } }); });
        });
      });
    }).catch(function (e) { return stop().then(function () { throw e; }); });
  };

  /* the whole screen flow: choose language → progress with Cancel → resolves with the imported script (or null if cancelled) */
  THK.pdfOcrFlow = function (buf, fname, hint) {
    return new Promise(function (resolve, reject) {
      var A = THK.app, wrap = A.el('div', ''), sel = [], saved = '';
      try { saved = localStorage.getItem('fn_ocrlang') || ''; } catch (e) { }
      var first = saved || GUESS[hint] || 'mal';
      wrap.appendChild(A.el('p', '', 'Reads the pages as pictures with an on-device engine. The first time it downloads the engine and the language (about 5–15 MB, needs internet); after that it also works offline. Pages never leave your device.'));
      var row = A.el('div', 'pdflist');
      LANGS.forEach(function (l) {
        var lab = A.el('label', 'pdfsim', '<input type="checkbox" value="' + l[0] + '"' + (l[0] === first || (l[0] === 'eng') ? ' checked' : '') + '> ' + A.esc(l[1]));
        row.appendChild(lab); sel.push(lab.querySelector('input'));
      });
      wrap.appendChild(row);
      wrap.appendChild(A.el('p', 'pdfmore', 'Tip: choose the language of the script plus English (scene headings, names). Reading a long script can take several minutes.'));
      var d1 = A.dlg('Read this PDF with OCR', wrap, [
        { l: 'Cancel', fn: function () { resolve(null); } },
        {
          l: 'Start', cls: 'pri', fn: function () {
            var langs = sel.filter(function (i) { return i.checked; }).map(function (i) { return i.value; });
            if (!langs.length) langs = ['eng'];
            var lang = langs.join('+'); try { localStorage.setItem('fn_ocrlang', langs.filter(function (x) { return x !== 'eng'; })[0] || 'eng'); } catch (e) { }
            run(lang); return true;
          }
        }
      ], { nofocus: true, onclose: function () { } });
      function run(lang) {
        var cancel = { v: false }, box = A.el('div', ''), msg = A.el('p', '', 'Starting…'), bar = A.el('div', '', '<div style="height:8px;border-radius:99px;background:rgba(128,128,128,.25);overflow:hidden"><div class="ocrbar" style="height:100%;width:0;border-radius:99px;background:#5e6cf2;transition:width .25s"></div></div>');
        box.appendChild(msg); box.appendChild(bar);
        var d2 = A.dlg('Reading with OCR…', box, [{ l: 'Cancel', fn: function () { cancel.v = true; resolve(null); } }], { nofocus: true });
        var fill = bar.querySelector('.ocrbar');
        THK.pdfOcr(buf, fname, lang, {
          cancel: cancel, progress: function (p, n, st, fr) {
            msg.textContent = st.length > 60 ? st.slice(0, 60) + '…' : st; var total = n || 1, v = ((p ? p - 1 : 0) + (fr || 0)) / total; fill.style.width = Math.max(2, Math.min(100, Math.round(v * 100))) + '%';
          }
        }).then(function (d) { d2.close(); resolve(d); }, function (e) { d2.close(); if (e && e.cancelled) resolve(null); else reject(e); });
      }
    });
  };
})();
