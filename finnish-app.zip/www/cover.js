/* Cover page designs & options – shared by the editor, the live preview in the Cover dialog, and the PDF / print output.
   Settings live on the script as  d.cv (style)  and  d.cvo (options: acc, size, up, wide, al, v, rule, fr, lbl).  */
(function () {
  'use strict';
  var CV = THK.cv = {};
  CV.STYLES = [['classic', 'Classic'], ['elegant', 'Elegant'], ['industry', 'Industry'], ['poster', 'Poster'], ['banner', 'Banner'], ['corners', 'Corners'], ['editorial', 'Editorial'], ['spine', 'Spine'], ['glow', 'Glow'], ['modern', 'Modern'], ['left', 'Left aligned'], ['bold', 'Bold title'], ['minimal', 'Minimal'], ['framed', 'Framed']];
  CV.BY = { industry: 1, elegant: 1, poster: 1, banner: 1, corners: 1, editorial: 1, spine: 1, glow: 1 };   /* these default to "Written by" labels */
  CV.SWATCHES = ['#1f3a5f', '#7a1f2b', '#0f5f4d', '#b7791f', '#5a3e8a', '#c2410c', '#1d4ed8', '#be185d', '#444444'];
  CV.SIZES = [['s', 'Small', 0.8], ['m', 'Medium', 1], ['l', 'Large', 1.22], ['xl', 'Extra large', 1.48]];

  function hex(c) { return /^#[0-9a-f]{6}$/i.test(c || '') ? c : ''; }
  function rgb(h) { return [parseInt(h.substr(1, 2), 16), parseInt(h.substr(3, 2), 16), parseInt(h.substr(5, 2), 16)]; }
  CV.opts = function (d) {
    var o = (d && d.cvo) || {}, st = (d && d.cv) || 'classic', sz = 1;
    CV.SIZES.forEach(function (s) { if (s[0] === o.size) sz = s[2]; });
    return { st: st, acc: hex(o.acc), sz: sz, size: o.size || 'm', up: !!o.up, wide: !!o.wide, al: o.al || '', v: o.v || '', rule: o.rule || '', fr: o.fr || '', lbl: o.lbl || (CV.BY[st] ? 'by' : 'plain') };
  };
  /* class names for the cover element (same in the editor, the preview and the print page) */
  CV.classes = function (d) {
    var o = CV.opts(d), c = ['cv-' + o.st];
    if (o.up) c.push('cvo-up'); if (o.wide) c.push('cvo-wide');
    if (o.al) c.push('cvo-al-' + o.al); if (o.v) c.push('cvo-v-' + o.v);
    if (o.rule) c.push('cvo-rule-' + o.rule); if (o.fr) c.push('cvo-fr-' + o.fr);
    return c.join(' ');
  };
  /* custom properties: accent, ink on accent, soft glow, title size */
  CV.vars = function (d, fallback) {
    var o = CV.opts(d), a = o.acc || hex(fallback) || '', s = '--cs:' + o.sz;
    if (a) { var r = rgb(a), lum = (0.299 * r[0] + 0.587 * r[1] + 0.114 * r[2]) / 255; s += ';--ca:' + a + ';--cat:' + (lum > 0.62 ? '#111' : '#fff') + ';--cag:rgba(' + r.join(',') + ',.16)'; }
    return s;
  };
  CV.labels = function (d) {
    return CV.opts(d).lbl === 'by' ? { w: 'Written by', d: 'Directed by', t: 'Date' } : { w: 'Writer :', d: 'Director :', t: 'Date of the exporting :' };
  };
  /* editor / preview: paint an existing #cover-like element */
  CV.apply = function (c, d) {
    c.className = (c.classList.contains('cvp') ? 'cvx cvp ' : 'cvx ') + CV.classes(d);
    c.style.cssText = CV.vars(d, '');
    var L = CV.labels(d), bs = c.querySelectorAll('.cl b'); if (bs[0]) bs[0].textContent = L.w; if (bs[1]) bs[1].textContent = L.d; if (bs[2]) bs[2].textContent = L.t;
  };

  /* ---------- editor / preview CSS (ids so they beat the older cover rules) ---------- */
  var E = '#cover';
  var css =
    E + '{--ca:var(--acc,#3b5bdb);--cat:#fff;--cag:rgba(80,100,200,.14);--cs:1}' +
    E + ' .ct{zoom:var(--cs,1)}' +
    E + '.cvo-up .ct{text-transform:uppercase}' + E + '.cvo-wide .ct{letter-spacing:.14em}' +
    E + '.cvp{min-height:0;aspect-ratio:1/1.36;width:204px;max-width:100%;padding:18px 14px;font-size:7.6px;margin:0 auto 14px;box-shadow:0 4px 16px rgba(0,0,0,.2),0 0 0 1px rgba(128,128,128,.25);pointer-events:none;overflow:hidden;border-radius:4px}' +
    E + '.cvp .cl b{font-weight:700}' +
    /* new styles */
    E + '.cv-elegant .ct{text-transform:uppercase;letter-spacing:.12em;font-weight:600;font-size:1.75em;padding:.95em 0;background:linear-gradient(var(--ca),var(--ca)) top center/3.4em 1.5px no-repeat,linear-gradient(var(--ca),var(--ca)) bottom center/3.4em 1.5px no-repeat}' +
    E + '.cv-elegant .cl b{font-weight:400;font-style:italic;opacity:.75}' +
    E + '.cv-poster .ct{text-transform:uppercase;font-weight:800;font-size:2.7em;line-height:1.06;letter-spacing:.03em;width:100%;border-top:.16em solid var(--ca);border-bottom:.16em solid var(--ca);padding:.35em 0}' +
    E + '.cv-poster .cl b{text-transform:uppercase;letter-spacing:.14em;font-size:.72em;opacity:.7}' +
    E + '.cv-banner{justify-content:flex-start;padding-top:clamp(36px,12vw,100px)}' + E + '.cv-banner .ct{background:var(--ca);color:var(--cat);width:100%;padding:.8em .6em;text-transform:uppercase;letter-spacing:.06em;font-size:1.9em;border-radius:3px}' +
    E + '.cv-banner .cl b{opacity:.65}' +
    E + '.cv-corners{background-image:linear-gradient(var(--ca),var(--ca)),linear-gradient(var(--ca),var(--ca)),linear-gradient(var(--ca),var(--ca)),linear-gradient(var(--ca),var(--ca)),linear-gradient(var(--ca),var(--ca)),linear-gradient(var(--ca),var(--ca)),linear-gradient(var(--ca),var(--ca)),linear-gradient(var(--ca),var(--ca));background-repeat:no-repeat;' +
    'background-size:34px 2px,2px 34px,34px 2px,2px 34px,34px 2px,2px 34px,34px 2px,2px 34px;background-position:18px 18px,18px 18px,calc(100% - 18px) 18px,calc(100% - 18px) 18px,18px calc(100% - 18px),18px calc(100% - 18px),calc(100% - 18px) calc(100% - 18px),calc(100% - 18px) calc(100% - 18px)}' +
    E + '.cv-corners .ct{font-size:2.3em;letter-spacing:.04em}' +
    E + '.cv-editorial{align-items:flex-start;text-align:left;justify-content:flex-end}' + E + '.cv-editorial .ct{font-size:2.7em;line-height:1.1;padding-top:.5em;background:linear-gradient(var(--ca),var(--ca)) top left/2.2em .14em no-repeat}' + E + '.cv-editorial .cl{justify-content:flex-start}' + E + '.cv-editorial .clogo{margin-left:0}' + E + '.cv-editorial .cl b{text-transform:uppercase;letter-spacing:.12em;font-size:.7em;opacity:.7}' +
    E + '.cv-spine{align-items:flex-end;text-align:right;justify-content:flex-end;border-right:clamp(10px,2.4vw,20px) solid var(--ca)}' + E + '.cv-spine .ct{font-size:2.5em}' + E + '.cv-spine .cl{justify-content:flex-end}' + E + '.cv-spine .clogo{margin-right:0}' +
    E + '.cv-glow{background-image:radial-gradient(ellipse at 50% 36%,var(--cag),transparent 64%)}' + E + '.cv-glow .ct{font-size:2.3em}' +
    E + '.cv-modern{border-left-color:var(--ca)}' +
    /* options */
    E + '.cvo-al-left{align-items:flex-start;text-align:left}' + E + '.cvo-al-left .cl{justify-content:flex-start}' + E + '.cvo-al-left .clogo{margin-left:0;margin-right:auto}' +
    E + '.cvo-al-center{align-items:center;text-align:center}' + E + '.cvo-al-center .cl{justify-content:center}' + E + '.cvo-al-center .clogo{margin-left:auto;margin-right:auto}' +
    E + '.cvo-al-right{align-items:flex-end;text-align:right}' + E + '.cvo-al-right .cl{justify-content:flex-end}' + E + '.cvo-al-right .clogo{margin-left:auto;margin-right:0}' +
    E + '.cvo-v-top{justify-content:flex-start;padding-top:clamp(30px,10vw,80px)}' + E + '.cvo-v-mid{justify-content:center}' + E + '.cvo-v-low{justify-content:flex-end}' +
    E + '.cvo-rule-none .ct{border-bottom:0;background-image:none;padding-bottom:0}' +
    E + '.cvo-rule-line .ct{border-bottom:1px solid var(--ca);padding-bottom:.55em}' + E + '.cvo-rule-double .ct{border-bottom:5px double var(--ca);padding-bottom:.55em}' + E + '.cvo-rule-thick .ct{border-bottom:4px solid var(--ca);padding-bottom:.55em}' + E + '.cvo-rule-dots .ct{border-bottom:3px dotted var(--ca);padding-bottom:.55em}' +
    E + '.cvo-fr-none{outline:0;border:0}' + E + '.cvo-fr-thin{outline:1.5px solid var(--ca);outline-offset:-20px}' + E + '.cvo-fr-double{outline:5px double var(--ca);outline-offset:-20px}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  /* ---------- print / PDF CSS (mm and pt). o = { H: page height mm, fs: body pt, tc: text colour } ---------- */
  CV.printCss = function (o) {
    var H = o.H, fs = o.fs, k = '.cover', tx = o.tc, ca = 'var(--ca,' + tx + ')';
    var corner = function (pos) { return 'linear-gradient(' + ca + ',' + ca + ') ' + pos; };
    return k + '{--cs:1}' + k + ' h1{zoom:var(--cs,1)}' +
      k + '.cv-elegant h1{text-transform:uppercase;letter-spacing:.12em;font-weight:600;font-size:' + (fs * 2) + 'pt;padding:9mm 0;margin-bottom:12mm;background:linear-gradient(' + ca + ',' + ca + ') top center/34mm 1.2pt no-repeat,linear-gradient(' + ca + ',' + ca + ') bottom center/34mm 1.2pt no-repeat}' +
      k + '.cv-elegant .by{font-style:italic}' +
      k + '.cv-poster{padding:0 4mm}' + k + '.cv-poster h1{width:100%;text-transform:uppercase;font-weight:800;font-size:' + (fs * 3.3) + 'pt;line-height:1.06;letter-spacing:.03em;border-top:5pt solid ' + ca + ';border-bottom:5pt solid ' + ca + ';padding:9mm 0;margin-bottom:14mm}' + k + '.cv-poster .by{text-transform:uppercase;letter-spacing:.16em;font-size:' + (fs * 0.72) + 'pt}' +
      k + '.cv-banner{justify-content:flex-start;padding-top:34mm}' + k + '.cv-banner h1{width:100%;background:' + ca + ';color:var(--cat,#fff);padding:13mm 8mm;text-transform:uppercase;letter-spacing:.06em;font-size:' + (fs * 2.3) + 'pt;margin-bottom:16mm}' +
      k + '.cv-corners{padding:20mm;background:' + [corner('top left/22mm 1.3pt no-repeat'), corner('top left/1.3pt 22mm no-repeat'), corner('top right/22mm 1.3pt no-repeat'), corner('top right/1.3pt 22mm no-repeat'), corner('bottom left/22mm 1.3pt no-repeat'), corner('bottom left/1.3pt 22mm no-repeat'), corner('bottom right/22mm 1.3pt no-repeat'), corner('bottom right/1.3pt 22mm no-repeat')].join(',') + '}' + k + '.cv-corners h1{font-size:' + (fs * 2.7) + 'pt;letter-spacing:.04em}' +
      k + '.cv-editorial{align-items:flex-start;text-align:left;justify-content:flex-end}' + k + '.cv-editorial h1{font-size:' + (fs * 3) + 'pt;line-height:1.1;padding-top:8mm;margin-bottom:12mm;background:linear-gradient(' + ca + ',' + ca + ') top left/26mm 4pt no-repeat}' + k + '.cv-editorial .by{text-transform:uppercase;letter-spacing:.14em;font-size:' + (fs * 0.7) + 'pt}' +
      k + '.cv-spine{align-items:flex-end;text-align:right;justify-content:flex-end;border-right:6mm solid ' + ca + ';padding-right:12mm}' + k + '.cv-spine h1{font-size:' + (fs * 2.8) + 'pt;margin-bottom:12mm}' +
      k + '.cv-glow{background:radial-gradient(ellipse at 50% 36%,var(--cag,rgba(120,120,120,.14)),transparent 64%)}' + k + '.cv-glow h1{font-size:' + (fs * 2.6) + 'pt}' +
      k + '.cv-modern{border-left-color:' + ca + '}' +
      /* options */
      k + '.cvo-up h1{text-transform:uppercase}' + k + '.cvo-wide h1{letter-spacing:.14em}' +
      k + '.cvo-al-left{align-items:flex-start;text-align:left}' + k + '.cvo-al-center{align-items:center;text-align:center}' + k + '.cvo-al-right{align-items:flex-end;text-align:right}' +
      k + '.cvo-v-top{justify-content:flex-start;padding-top:40mm}' + k + '.cvo-v-mid{justify-content:center;padding-top:0}' + k + '.cvo-v-low{justify-content:flex-end;padding-top:0}' +
      k + '.cvo-rule-none h1{border-bottom:0;background-image:none;padding-bottom:0}' +
      k + '.cvo-rule-line h1{border-bottom:.8pt solid ' + ca + ';padding-bottom:6mm}' + k + '.cvo-rule-double h1{border-bottom:4pt double ' + ca + ';padding-bottom:6mm}' + k + '.cvo-rule-thick h1{border-bottom:3.5pt solid ' + ca + ';padding-bottom:6mm}' + k + '.cvo-rule-dots h1{border-bottom:2.5pt dotted ' + ca + ';padding-bottom:6mm}' +
      k + '.cvo-fr-none{border:0;padding:0}' + k + '.cvo-fr-thin{border:1.4pt solid ' + ca + ';padding:14mm;height:' + (H - 43) + 'mm}' + k + '.cvo-fr-double{border:5pt double ' + ca + ';padding:14mm;height:' + (H - 43) + 'mm}';
  };
})();
