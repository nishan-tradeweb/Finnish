/* finnish – multi-language screenplay writer (English first). Offline, no dependencies. Creator: Nishan */
(function () {
  'use strict';
  var THK = window.THK, VERSION = '2.0.0';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  function uid() { return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4); }
  function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var N = window.finnishNative || null;
  var PT = (function () { var t = document.createElement('div'); try { t.contentEditable = 'plaintext-only'; } catch (e) { } return t.contentEditable === 'plaintext-only' ? 'plaintext-only' : 'true'; })();

  /* ------------------------------------------------------------------ constants */
  var LAB = { scene: 'Scene heading', action: 'Action', char: 'Character', paren: 'Parenthetical', dial: 'Dialogue', trans: 'Transition', shot: 'Shot', note: 'Note' };
  var ORDER = ['scene', 'action', 'char', 'paren', 'dial', 'trans'];
  var NEXT = { scene: 'action', action: 'action', char: 'dial', paren: 'dial', dial: 'char', trans: 'scene', shot: 'action', note: 'action' };
  var PH = { scene: 'INT. / EXT. – place – time', action: 'Action…', char: 'Character', paren: 'parenthetical', dial: 'Dialogue…', trans: 'CUT TO:', shot: 'Shot', note: 'Note' };
  var MARKS = [['Yellow', 'rgba(255,214,10,.55)'], ['Green', 'rgba(52,199,89,.45)'], ['Blue', 'rgba(10,132,255,.40)'], ['Pink', 'rgba(255,55,140,.40)'], ['Orange', 'rgba(255,149,0,.50)']];
  var PRESETS = [['White', '#ffffff', '#000000'], ['Cream', '#fbf3df', '#2b2118'], ['Sepia', '#f1e4c8', '#4a3420'], ['Grey', '#e9ebee', '#1b1d21'], ['Mint', '#e3f6ec', '#0f3a2a'], ['Sky', '#e4f0ff', '#10264a'],
    ['Rose', '#fde8ee', '#4a1428'], ['Legal pad', '#fff8b8', '#222222'], ['Night', '#14171d', '#e8ecf3'], ['Black', '#000000', '#ffffff'], ['Amber', '#1a1208', '#ffb454'], ['Terminal', '#06130b', '#6dff9c']];
  var PAPERPX = { a4: 794, letter: 816 };

  /* ------------------------------------------------------------------ settings */
  var S = { theme: 'dyn-white', ml: false, lang: 'en', lastId: '', wall: '' };
  try { Object.assign(S, JSON.parse(localStorage.getItem('finnish.set') || '{}')); } catch (e) { }
  function saveS() { try { localStorage.setItem('finnish.set', JSON.stringify(S)); } catch (e) { } }
  var THEMES = [['auto', 'Auto', 'linear-gradient(135deg,#dde0fb 50%,#0d1040 50%)'], ['light', 'Light', 'linear-gradient(135deg,#dde0fb,#ede3fb)'], ['dark', 'Dark', 'linear-gradient(135deg,#0d1040,#241b5e)'],
    ['crimson', 'Crimson', 'linear-gradient(135deg,#6e0c12,#e0222d)'], ['saffron', 'Saffron', 'linear-gradient(135deg,#8a4a00,#f5a800)'], ['slate', 'Slate', 'linear-gradient(135deg,#262f33,#8da2a8)'], ['cobalt', 'Cobalt', 'linear-gradient(135deg,#0a0d55,#4a44ff)'], ['emerald', 'Emerald', 'linear-gradient(135deg,#03280f,#2fb558)']];
  /* Theme registry – add a new entry here and it appears in the Theme window automatically.
     DYN item: [id, label, family (css data-dyn), variant, dark?, preview style, description] */
  var DYN = [
    ['dyn-white', 'Matte White', 'white', '', 0, 'background:#e6e7e9;box-shadow:inset 3px 3px 6px #b3b6bd,inset -3px -3px 6px #fff', 'Soft sculpted surfaces that press in'],
    ['dyn-black', 'Matte Black', 'black', '', 1, 'background:linear-gradient(180deg,#1b1b1d,#020202);box-shadow:inset 0 0 0 1px rgba(255,255,255,.3)', 'Deep black with glass edges']
  ];
  function dynOf() { return DYN.filter(function (t) { return t[0] === S.theme; })[0]; }
  function applyTheme() {
    var r = document.documentElement, dy = dynOf();
    if (dy) {
      r.dataset.theme = dy[4] ? 'dark' : 'light'; r.dataset.dyn = dy[2]; if (dy[3]) r.dataset.fur = dy[3]; else delete r.dataset.fur; delete r.dataset.tone;
    } else {
      delete r.dataset.dyn; delete r.dataset.fur;
      var tone = THEMES.some(function (t) { return t[0] === S.theme; }) && ['auto', 'light', 'dark'].indexOf(S.theme) < 0 ? S.theme : '';
      var dark = !!tone || S.theme === 'dark' || (S.theme === 'auto' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
      r.dataset.theme = dark ? 'dark' : 'light'; if (tone) r.dataset.tone = tone; else delete r.dataset.tone;
    }
    if (window.THK && THK.x && THK.x.accent) THK.x.accent();
    var m = $('meta[name=theme-color]'); if (m) { var pc = dy ? getComputedStyle(r).getPropertyValue('--page-c').trim() : ''; m.content = pc || (r.dataset.tone ? getComputedStyle(r).getPropertyValue('--bg1').trim() || '#0b0f17' : r.dataset.theme === 'dark' ? '#0b0f17' : '#dfe9f7'); }
    applyWall();
  }
  // id, label, text mode over it (dark = white text, light = dark text), scrim strength
  var WALLS = [['smoke', 'Smoked Glass', 'dark', .22], ['copper', 'Copper Foil', 'dark', .42], ['silver', 'Silver Foil', 'light', .38], ['snow', 'Snow Fur', 'light', .3], ['grass', 'Green Fur', 'dark', .32],
    ['gold', 'Gold Fur', 'dark', .5], ['crimson', 'Crimson Fur', 'dark', .24], ['sky', 'Sky Fur', 'light', .42], ['olive', 'Olive Plaster', 'dark', .3], ['steel', 'Steel Glass', 'light', .5]];
  function wallUrl() {
    if (!S.wall) return ''; if (S.wall === 'custom') { try { return localStorage.getItem('finnish.wallimg') || ''; } catch (e) { return ''; } } return 'walls/' + S.wall + '.jpg';
  }
  function applyWall() {
    var u = wallUrl(), w = $('#wall'), r = document.documentElement; if (!w) return;
    var m = WALLS.filter(function (x) { return x[0] === S.wall; })[0] || ['custom', '', 'dark', .32];
    if (u && !r.dataset.dyn) { w.style.backgroundImage = 'url("' + u + '")'; w.style.setProperty('--scrim', m[3]); r.dataset.wall = 'on'; r.dataset.wallmode = m[2]; } else { w.style.backgroundImage = ''; delete r.dataset.wall; delete r.dataset.wallmode; }
  }
  function pickWall(done) {
    var f = el('input'); f.type = 'file'; f.accept = 'image/*';
    f.onchange = function () {
      var file = f.files[0]; if (!file) return; var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        var k = Math.min(1, 1600 / Math.max(img.width, img.height)), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        try { localStorage.setItem('finnish.wallimg', c.toDataURL('image/jpeg', .82)); S.wall = 'custom'; saveS(); applyWall(); done && done(); } catch (e) { toast('That photo is too large to keep'); } URL.revokeObjectURL(url);
      }; img.onerror = function () { toast('Could not read that image'); }; img.src = url;
    }; f.click();
  }
  /* Theme window: preview + collections (tabs) + cards. Everything is driven by the registry above. */
  function themeDlg() {
    var tab = dynOf() ? 'dynamic' : 'colour', box = el('div', 'thbox');
    var prev = el('div', 'thprev glass', '<div class="pb"><span class="btn sm">Home</span><span class="pt">Untitled</span><span class="btn sm pri">Next page</span></div><div class="pp"><i></i><i></i><i style="width:60%"></i></div>'); box.appendChild(prev);
    var tabs = el('div', 'thtabs'), body = el('div', 'thbody'); box.appendChild(tabs); box.appendChild(body);
    var GROUPS = [
      { id: 'dynamic', label: 'Dynamic', hint: 'Restyle the whole app – surfaces, depth and shape.', items: function () { return DYN.map(function (t) { return { id: t[0], name: t[1], sub: t[6], css: t[5] }; }); } },
      { id: 'colour', label: 'Colour', hint: 'Liquid-glass themes with a colour mood.', items: function () { return THEMES.map(function (t) { return { id: t[0], name: t[1], css: t[0] === 'auto' ? 'background:linear-gradient(135deg,#fff 50%,#14182b 50%)' : t[0] === 'light' ? 'background:#fff' : t[0] === 'dark' ? 'background:#14182b' : 'background:' + t[2] }; }); } },
      { id: 'wall', label: 'Wallpaper', hint: 'Shown behind the start, saved, cover and paper screens.' },
      { id: 'accent', label: 'Accent', hint: 'The highlight colour of buttons and selections.' }
    ];
    function card(css, name, sub, sel, fn) { var c = el('button', 'thcard' + (sel ? ' sel' : ''), '<i class="thsw" style="' + css + '"></i><b>' + esc(name) + '</b>' + (sub ? '<small>' + esc(sub) + '</small>' : '')); c.onclick = fn; return c; }
    function draw() {
      tabs.innerHTML = ''; body.innerHTML = ''; var dy = !!dynOf();
      GROUPS.forEach(function (g) { var b = el('button', 'btn' + (tab === g.id ? ' on' : ''), g.label); b.onclick = function () { tab = g.id; draw(); }; tabs.appendChild(b); });
      var g = GROUPS.filter(function (x) { return x.id === tab; })[0]; body.appendChild(el('p', 'thn', esc(g.hint)));
      var grid = el('div', 'thgrid');
      if (g.items) g.items().forEach(function (t) { grid.appendChild(card(t.css, t.name, t.sub, S.theme === t.id, function () { S.theme = t.id; saveS(); applyTheme(); draw(); })); });
      else if (g.id === 'wall') {
        if (dy) { body.appendChild(el('p', 'thwarn', 'Wallpapers appear with the Colour themes. Dynamic themes use their own surface.')); grid.classList.add('off'); }
        grid.appendChild(card('background:linear-gradient(135deg,#fff 45%,#999 45% 55%,#fff 55%)', 'Off', '', !S.wall, function () { S.wall = ''; saveS(); applyWall(); draw(); }));
        WALLS.forEach(function (w) { grid.appendChild(card('background:url(walls/t-' + w[0] + '.jpg) center/cover', w[1], '', S.wall === w[0], function () { S.wall = w[0]; saveS(); applyWall(); draw(); })); });
        grid.appendChild(card('background:linear-gradient(135deg,#6c7bff,#f27bc8)', 'My photo', '', S.wall === 'custom', function () { pickWall(draw); }));
      } else if (g.id === 'accent') {
        if (dy) body.appendChild(el('p', 'thwarn', 'Dynamic themes keep their own monochrome accent. Pick a Colour theme to use a custom accent.'));
        var ax = el('div', 'thax'); if (dy) ax.classList.add('off'); if (window.THK && THK.x && THK.x.accentUI) THK.x.accentUI(ax); body.appendChild(ax); return;
      }
      body.appendChild(grid);
    }
    draw(); dlg('Theme', box, [{ l: 'Done', cls: 'pri' }]);
  }

  /* ------------------------------------------------------------------ storage (IndexedDB, localStorage fallback) */
  var DB = {
    db: null,
    init: function () {
      return new Promise(function (res) {
        try {
          var r = indexedDB.open('finnish', 1);
          r.onupgradeneeded = function () { r.result.createObjectStore('docs', { keyPath: 'id' }); };
          r.onsuccess = function () { DB.db = r.result; res(); };
          r.onerror = r.onblocked = function () { res(); };
        } catch (e) { res(); }
      });
    },
    all: function () {
      var ls = []; try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf('finnish.doc.') === 0) ls.push(JSON.parse(localStorage.getItem(k))); } } catch (e) { }
      if (!DB.db) return Promise.resolve(ls);
      return new Promise(function (res) {
        var q = DB.db.transaction('docs').objectStore('docs').getAll();
        q.onsuccess = function () { var m = {}; q.result.concat(ls).forEach(function (d) { if (!m[d.id] || m[d.id].updated < d.updated) m[d.id] = d; }); res(Object.keys(m).map(function (k) { return m[k]; })); };
        q.onerror = function () { res(ls); };
      });
    },
    put: function (d) {
      var ok = function () { return true; };
      if (!DB.db) { try { localStorage.setItem('finnish.doc.' + d.id, JSON.stringify(d)); } catch (e) { } return Promise.resolve(); }
      return new Promise(function (res) {
        try { var tx = DB.db.transaction('docs', 'readwrite'); tx.objectStore('docs').put(d); tx.oncomplete = function () { res(ok()); }; tx.onerror = tx.onabort = function () { try { localStorage.setItem('finnish.doc.' + d.id, JSON.stringify(d)); } catch (e) { } res(); }; }
        catch (e) { res(); }
      });
    },
    del: function (id) {
      try { localStorage.removeItem('finnish.doc.' + id); } catch (e) { }
      if (!DB.db) return Promise.resolve();
      return new Promise(function (res) { var tx = DB.db.transaction('docs', 'readwrite'); tx.objectStore('docs').delete(id); tx.oncomplete = tx.onerror = function () { res(); }; });
    }
  };

  /* ------------------------------------------------------------------ document model */
  function newDoc(fmt, paper, cover) {
    cover = cover || {};
    return norm({ id: uid(), fmt: fmt, paper: paper, lang: 'en', font: THK.defaultFont('en'), title: cover.title || '', writer: cover.writer || '', director: cover.director || '', date: cover.date || '', blocks: [{ id: uid(), t: 'scene', x: '', x2: '' }] });
  }
  function norm(d) {
    d.id = d.id || uid(); d.fmt = d.fmt === 'two' ? 'two' : 'std'; d.paper = ['a4', 'letter', 'legal', 'a5', 'custom'].indexOf(d.paper) >= 0 ? d.paper : 'a4'; if (d.paper === 'custom') { d.pw = Math.min(600, Math.max(60, +d.pw || 210)); d.ph = Math.min(900, Math.max(80, +d.ph || 297)); } d.cv = d.cv || 'classic';
    d.title = d.title || ''; d.writer = d.writer != null && d.writer !== '' ? d.writer : (d.author || ''); d.director = d.director || ''; d.date = d.date || '';
    d.font = d.font || 'Manjari'; d.size = d.size || 12; d.pageColor = d.pageColor || '#ffffff'; d.textColor = d.textColor || '#000000';
    d.lang = d.lang || 'ml'; d.cfm = d.cfm || {}; if (!THK.FONTS.some(function (f) { return f.id === d.font; })) d.font = THK.defaultFont(d.lang);
    d.ct = (Array.isArray(d.ct) ? d.ct : []).map(function (t) { return THK.el ? THK.el.clean(t) : null; }).filter(Boolean); if (!d.ct.length) delete d.ct; if (d.cl) { d.cl = THK.cv && THK.cv.norm ? THK.cv.norm(d.cl) : null; if (!d.cl) delete d.cl; } d.created = d.created || Date.now(); d.updated = d.updated || Date.now(); d.credit = d.credit || 'Written by';
    d.blocks = (d.blocks && d.blocks.length ? d.blocks : [{ t: 'scene', x: '' }]).map(function (b) { b.id = b.id || uid(); b.x = b.x || ''; if (b.t && ['scene', 'action', 'char', 'paren', 'dial', 'trans', 'shot', 'note'].indexOf(b.t) < 0 && !(d.ct || []).some(function (t) { return t.id === b.t; })) b.t = 'action'; if (b.t === 'scene') b.x2 = b.x2 || ''; return b; });
    return d;
  }
  var cur = null, cb = null, handles = {};
  var hist = { st: [], re: [], t: 0 };
  function snapStr() { return JSON.stringify([cur.blocks, cur.title, cur.writer, cur.director, cur.date, cur.cfm, cur.titleFont]); }
  function snap(force) { clearTimeout(hist.t); hist.t = 0; var s = snapStr(); if (hist.st[hist.st.length - 1] !== s) { hist.st.push(s); if (hist.st.length > 120) hist.st.shift(); hist.re = []; } }
  function snapSoon() { clearTimeout(hist.t); hist.t = setTimeout(snap, 700); }
  function restore(s) { var a = JSON.parse(s); cur.blocks = a[0]; cur.title = a[1]; cur.writer = a[2]; cur.director = a[3]; cur.date = a[4]; cur.cfm = a[5] || {}; cur.titleFont = a[6]; renderAll(); dirty(); }
  function undo() { if (hist.t) snap(); if (hist.st.length < 2) return; hist.re.push(hist.st.pop()); restore(hist.st[hist.st.length - 1]); focusBlock(cb && blockById(cb.id) ? cb.id : cur.blocks[0].id); }
  function redo() { if (!hist.re.length) return; var s = hist.re.pop(); hist.st.push(s); restore(s); }
  function blockById(id) { for (var i = 0; i < cur.blocks.length; i++) if (cur.blocks[i].id === id) return cur.blocks[i]; return null; }
  function idxOf(id) { for (var i = 0; i < cur.blocks.length; i++) if (cur.blocks[i].id === id) return i; return -1; }

  /* ------------------------------------------------------------------ autosave + crash journal */
  var saveT = 0, jT = 0, status = 'saved';
  function setStatus(s) { status = s; var e = $('#svdot'); if (e) { e.textContent = s === 'saved' ? '● Saved' : '○ Saving…'; e.style.color = s === 'saved' ? '#30d158' : '#ff9f0a'; } }
  function dirty() {
    if (!cur) return; setStatus('saving');
    clearTimeout(jT); jT = setTimeout(journal, 200);
    clearTimeout(saveT); saveT = setTimeout(persist, 700);
  }
  function journal() { if (!cur || status === 'saved') return; try { cur.updated = Date.now(); localStorage.setItem('finnish.recover', JSON.stringify(cur)); } catch (e) { } }
  function persist() {
    if (!cur) return Promise.resolve(); clearTimeout(saveT); cur.updated = Date.now(); cur.author = cur.writer; S.lastId = cur.id; saveS();
    var c = JSON.parse(JSON.stringify(cur)); delete c._tmp;
    return DB.put(c).then(function () { if (window.THK && THK.x && THK.x.version) THK.x.version(c); setStatus('saved'); try { localStorage.removeItem('finnish.recover'); } catch (e) { } });
  }
  document.addEventListener('visibilitychange', function () { if (document.hidden && cur) { journal(); persist(); } else if (!document.hidden && window.THK && THK._checkPending) THK._checkPending(); });
  window.addEventListener('pagehide', function () { if (cur) journal(); });

  /* ------------------------------------------------------------------ UI helpers */
  var toastT = 0;
  function mob() { return isPhone(); }
  function clean(s) { return String(s == null ? '' : s).replace(/\s*…\s*/g, ' ').replace(/\s+$/, '').replace(/\s{2,}/g, ' '); }
  function toast(msg) { var t = $('#toast'); if (mob()) msg = String(msg).replace(/\bClick\b/g, 'Tap').replace(/\bclick\b/g, 'tap'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(function () { t.classList.remove('show'); }, 2200); }
  function dlg(title, body, acts, opt) {
    var sc = el('div', 'scrim'), d = el('div', 'dlg glass'); opt = opt || {};
    if (title) d.appendChild(el('h3', '', esc(clean(title))));
    if (typeof body === 'string') d.appendChild(el('div', '', body)); else if (body) d.appendChild(body);
    var close = function () { sc.remove(); if (opt.onclose) opt.onclose(); };
    if (acts) { var a = el('div', 'acts'); acts.forEach(function (x) { var b = el('button', 'btn ' + (x.cls || ''), esc(clean(x.l))); b.onclick = function () { if (!x.fn || x.fn(d) !== false) close(); }; a.appendChild(b); }); d.appendChild(a); }
    sc.appendChild(d); sc.addEventListener('mousedown', function (e) { if (e.target === sc) close(); }); $('#layer').appendChild(sc);
    var f = $('input,textarea', d); if (f && !opt.nofocus) setTimeout(function () { f.focus(); }, 50);
    $$('select', d).forEach(upgradeSelect);
    d.close = close; return d;
  }
  /* premium animated glass popover (shared by every drop-down in the app) */
  function pop(anchor, fill, opt) {
    opt = opt || {}; var L = $('#layer');
    $$('.menuscrim').forEach(function (s) { s.remove(); });
    var m = el('div', 'menu' + (opt.cls ? ' ' + opt.cls : '')), sc = el('div', 'scrim menuscrim'), r = anchor.getBoundingClientRect(), shut = false;
    function close() { if (shut) return; shut = true; m.classList.add('out'); setTimeout(function () { sc.remove(); }, 140); if (opt.onclose) opt.onclose(); }
    sc.addEventListener('pointerdown', function (e) { if (e.target === sc) close(); });
    fill(m, close); sc.appendChild(m); L.appendChild(sc);
    var w = m.offsetWidth, h = m.offsetHeight, x = opt.right ? r.right - w : r.left, y = r.bottom + 8, up = false;
    x = Math.max(8, Math.min(x, innerWidth - w - 8)); if (y + h > innerHeight - 8) { up = true; y = Math.max(8, r.top - h - 8); }
    m.style.left = x + 'px'; m.style.top = y + 'px'; m.style.setProperty('--ox', Math.round(r.left + r.width / 2 - x) + 'px'); m.style.setProperty('--oy', up ? h + 'px' : '0px');
    m.close = close; return m;
  }
  var baseH = 0;
  function kbOpen() { var h = window.visualViewport ? visualViewport.height : innerHeight; baseH = Math.max(baseH, h); return h < baseH - 120; }
  function menu(anchor, items, right, opt) {
    var o = Object.assign({ right: right }, opt || {});
    var ae = document.activeElement; if (ae && ae.classList && ae.classList.contains('ed') && !kbOpen()) ae.blur();
    var m = pop(anchor, function (m, close) {
      var n = 0; if (o.minw) m.style.minWidth = o.minw + 'px';
      items.forEach(function (it) {
        if (it.hr) return m.appendChild(el('hr')); if (it.hd) return m.appendChild(el('div', 'hd', esc(clean(it.hd))));
        var b = el('button', it.sel ? 'sel' : '', (it.dot ? '<i class="chip" style="background:' + it.dot + '"></i>' : '') + '<span class="ml">' + esc(clean(it.l)) + '</span>' + (it.s ? '<small>' + esc(it.s) + '</small>' : '') + (it.k && !mob() ? '<small>' + esc(it.k) + '</small>' : ''));
        if (it.ff) b.style.fontFamily = it.ff; b.style.setProperty('--i', Math.min(n++, 9)); b.onmousedown = function (e) { e.preventDefault(); };
        b.onclick = function () { if (!it.keep) close(); it.fn(); }; m.appendChild(b);
      });
    }, o);
    var s = $('button.sel', m); if (s) setTimeout(function () { try { m.scrollTop = Math.max(0, s.offsetTop - m.clientHeight / 2 + s.offsetHeight / 2); } catch (e) { } }, 0);
    return m;
  }
  /* turn any <select> into a glass pill that opens the premium menu (the select stays as the data holder) */
  function upgradeSelect(sel) {
    if (sel.__dd) return; sel.__dd = 1; sel.classList.add('ddsel');
    var b = el('button', 'btn ddp', '<span class="dl"></span>'); b.type = 'button'; b.onmousedown = function (e) { e.preventDefault(); };
    sel.parentNode.insertBefore(b, sel);
    function lab() { var o = sel.options[sel.selectedIndex]; b.firstChild.textContent = o ? o.textContent : ''; b.title = sel.title || ''; }
    var d = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value'); Object.defineProperty(sel, 'value', { get: function () { return d.get.call(sel); }, set: function (v) { d.set.call(sel, v); lab(); }, configurable: true });
    new MutationObserver(lab).observe(sel, { childList: true }); sel.addEventListener('change', lab);
    b.onclick = function () {
      var items = [].map.call(sel.options, function (o) { return { l: o.textContent, sel: o.value === sel.value, ff: o.dataset.ff, fn: function () { sel.value = o.value; sel.dispatchEvent(new Event('change')); } }; });
      var short = items.every(function (x) { return x.l.length <= 7; }); b.classList.add('open'); menu(b, items, false, { cls: 'ddm' + (short ? ' sm' : ''), minw: short ? Math.max(84, b.offsetWidth) : 0, onclose: function () { b.classList.remove('open'); } });
    }; lab();
  }
  function ask(title, label, val, ok, okLabel) {
    var i = el('input', 't'); i.value = val || ''; i.placeholder = label;
    var d = dlg(title, i, [{ l: 'Cancel' }, { l: okLabel || 'OK', cls: 'pri', fn: function () { ok(i.value.trim()); } }]);
    i.addEventListener('keydown', function (e) { if (e.key === 'Enter') { ok(i.value.trim()); d.close(); } });
  }
  function confirmD(title, msg, ok, label) { dlg(title, '<p>' + esc(msg) + '</p>', [{ l: 'Cancel' }, { l: label || 'OK', cls: 'pri', fn: ok }]); }
  function isPhone() { return (window.Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform()) || (matchMedia('(pointer:coarse)').matches && innerWidth < 900); }
  function show(id) { ['splash', 'home', 'wiz', 'app', 'nt', 'cvEd'].forEach(function (s) { if (s !== 'splash') $('#' + s).hidden = s !== id; }); document.documentElement.dataset.scr = id; }

  /* ------------------------------------------------------------------ HOME */
  var homeTab = 'start';
  function svgStd() { return '<svg viewBox="0 0 96 72" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><rect x="20" y="3" width="56" height="66" rx="5" opacity=".5"/><path d="M34 16h28M44 28h18M38 36h26M44 52h22"/></svg>'; }
  function svgTwo() { return '<svg viewBox="0 0 96 72" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><rect x="8" y="3" width="80" height="66" rx="5" opacity=".5"/><path d="M48 14v50" stroke-dasharray="4 4"/><path d="M16 22h24M16 32h20M56 40h24M56 50h20"/></svg>'; }
  function renderHome() {
    var h = $('#home'); h.innerHTML = ''; var c = el('div', 'center'); h.appendChild(c);
    c.appendChild(el('div', 'hero', '<div class="wm" role="img" aria-label="finnish"></div><p>Mobile screenplay writer</p>'));
    var tabs = el('div', 'row'); [['start', 'New script'], ['saved', 'Saved']].forEach(function (t) { var b = el('button', 'btn' + (homeTab === t[0] ? ' on' : ''), t[1]); b.onclick = function () { homeTab = t[0]; renderHome(); }; tabs.appendChild(b); });
    c.appendChild(tabs);
    if (homeTab === 'start') {
      c.appendChild(el('h2', '', '<span style="font-weight:600;font-size:19px;display:block;text-align:center">Which format do you want?</span>'));
      var g = el('div', 'formats');
      [['std', 'Standard', 'Classic screenplay layout', svgStd()], ['two', 'Two Column', 'Action on the left, dialogue on the right', svgTwo()]].forEach(function (f) {
        var b = el('button', 'fbtn', f[3] + '<h2>' + f[1] + '</h2><small>' + f[2] + '</small>'); b.onclick = function () { wizard(f[0]); }; g.appendChild(b);
      });
      c.appendChild(g);
    } else {
      var p = el('div', 'panel glass'); p.appendChild(el('h3', '', 'Saved on this device')); var list = el('div', 'saved-list'); p.appendChild(list); c.appendChild(p);
      DB.all().then(function (ds) {
        ds.sort(function (a, b) { return b.updated - a.updated; });
        if (!ds.length) list.innerHTML = '<p style="color:var(--ink2)">Nothing saved yet. Everything you write is saved here automatically.</p>';
        ds.forEach(function (d) {
          var r = el('div', 'sv', '<div class="n"><b>' + esc(d.title || 'Untitled') + '</b><small>' + new Date(d.updated).toLocaleString() + ' · ' + (d.blocks || []).length + ' lines</small></div><span class="tag">' + (d.fmt === 'two' ? 'Two column' : 'Standard') + '</span>');
          var x = el('button', 'btn sm sq danger', '✕'); x.title = 'Delete';
          x.onclick = function (e) { e.stopPropagation(); confirmD('Delete script?', '“' + (d.title || 'Untitled') + '” will be removed from this device.', function () { DB.del(d.id).then(renderHome); }, 'Delete'); };
          r.appendChild(x); r.onclick = function () { openDoc(norm(d)); }; list.appendChild(r);
        });
      });
    }
    var row = el('div', 'row');
    var imp = el('button', 'btn', 'Import'); imp.onclick = pickImport; row.appendChild(imp);
    var ab = el('button', 'btn', 'About'); ab.onclick = about; row.appendChild(ab);
    var th = el('button', 'btn', 'Theme'); th.onclick = themeDlg; row.appendChild(th);
    if (window.THK && THK.pro) { var sr = el('button', 'btn', 'Search'); sr.onclick = THK.pro.search; row.appendChild(sr); var bk = el('button', 'btn', 'Backup'); bk.onclick = THK.pro.backupDlg; row.appendChild(bk); }
    if (window.THK && THK.games) { var gm = el('button', 'btn', 'Games'); gm.innerHTML = THK.games.joy + 'Games'; gm.onclick = THK.games.open; row.appendChild(gm); }
    if (window.THK && THK.notes) { var nb = el('button', 'btn', 'Notes'); nb.onclick = function () { THK.notes.open(); }; row.appendChild(nb); }
    c.appendChild(row);
    show('home');
  }

  /* ------------------------------------------------------------------ WIZARD: cover -> paper -> editor */
  function wizard(fmt) {
    var data = { title: '', writer: '', director: '', date: '' }, paper = 'a4', w = $('#wiz');
    function stepCover() {
      w.innerHTML = ''; var c = el('div', 'wizcard glass');
      c.innerHTML = '<div class="steps"><i class="on"></i><i></i></div><h2>Cover page</h2><p style="margin:0;text-align:center;color:var(--ink2);font-size:14px">' + (fmt === 'two' ? 'Two Column' : 'Standard') + ' format · you can edit this any time before exporting</p>' +
        '<label>The main title</label><input class="t" id="w1" placeholder="Title of the film" value="' + esc(data.title) + '">' +
        '<label>Writer :</label><input class="t" id="w2" value="' + esc(data.writer) + '">' +
        '<label>Director :</label><input class="t" id="w3" value="' + esc(data.director) + '">' +
        '<label>Date of the exporting :</label><input class="t" id="w4" placeholder="Leave empty = date of export" value="' + esc(data.date) + '">';
      var a = el('div', 'row'); var back = el('button', 'btn', 'Back'); back.onclick = renderHome; var nx = el('button', 'btn pri', 'Next');
      nx.onclick = function () { data = { title: $('#w1').value.trim(), writer: $('#w2').value.trim(), director: $('#w3').value.trim(), date: $('#w4').value.trim() }; stepPaper(); };
      a.appendChild(back); a.appendChild(nx); c.appendChild(a); w.appendChild(c); show('wiz');
    }
    function stepPaper() {
      w.innerHTML = ''; var c = el('div', 'wizcard glass');
      c.innerHTML = '<div class="steps"><i></i><i class="on"></i></div><h2>Paper size</h2><p style="margin:0;text-align:center;color:var(--ink2);font-size:14px">Which size will you print or export to?</p>';
      var g = el('div', 'papers');
      [['a4', 'A4', '210 × 297 mm', 84, 119], ['letter', 'Letter', '8.5 × 11 in', 86, 111]].forEach(function (p) {
        var o = el('div', 'paper-opt' + (paper === p[0] ? ' sel' : ''), '<i style="width:' + p[3] + 'px;height:' + p[4] + 'px"></i><b>' + p[1] + '</b><br><small style="color:var(--ink2)">' + p[2] + '</small>');
        o.onclick = function () { paper = p[0]; $$('.paper-opt', g).forEach(function (x) { x.classList.remove('sel'); }); o.classList.add('sel'); }; g.appendChild(o);
      });
      c.appendChild(g);
      var a = el('div', 'row'); var back = el('button', 'btn', 'Back'); back.onclick = stepCover; var go = el('button', 'btn pri', 'Open first page');
      go.onclick = function () { var d = newDoc(fmt, paper, data); openDoc(d, true); }; a.appendChild(back); a.appendChild(go); c.appendChild(a); w.appendChild(c);
    }
    stepCover();
  }

  /* ------------------------------------------------------------------ EDITOR: render */
  function applyLook() {
    var A = $('#app'), s = A.style;
    s.setProperty('--pagec', cur.pageColor); s.setProperty('--textc', cur.textColor);
    s.setProperty('--font', THK.fontStack(cur.font)); if (cur.titleFont) s.setProperty('--tfont', THK.fontStack(cur.titleFont)); else s.removeProperty('--tfont'); s.setProperty('--fs', (cur.size * 1.3333).toFixed(2) + 'px'); s.setProperty('--pw', THK.paperPx(cur) + 'px');
    var pg = $('#page'); pg.className = cur.fmt === 'two' ? 'two' : 'std';
    var Lg = THK.lang(cur.lang); ['#cover', '#page'].forEach(function (q) { $(q).style.background = cur.pageColor; $(q).style.color = cur.textColor; $(q).lang = Lg.bcp || 'en'; $(q).dir = Lg.rtl ? 'rtl' : 'ltr'; });
    if (window.THK && THK.el) THK.el.apply(cur);
    if (window.THK && THK.pro) THK.pro.apply(cur);
  }
  function mkBlock(b) {
    var w = el('div', 'b ' + b.t + (b.al ? ' al-' + b.al : '') + (b.pb ? ' pb' : '') + (b.mk ? ' mk' : '')); w.dataset.id = b.id; w.dataset.lab = LAB[b.t];
    if (b.pb) w.dataset.pg = 'page break · next page'; if (b.mk) w.style.setProperty('--mk', b.mk);
    var ed = function (f, ph) { var e = el('div', 'ed'); e.dataset.f = f; e.dataset.ph = ph; e.contentEditable = PT; e.spellcheck = false; e.setAttribute('autocapitalize', 'off'); drawRich(e, b[f] || '', b.fm && b.fm[f]); return e; };
    if (b.t === 'scene' && cur.fmt === 'two') { w.appendChild(ed('x', 'Place')); w.appendChild(ed('x2', 'Day / Night')); } else { var ex = ed('x', PH[b.t]); if (b.t === 'paren') { ex.dataset.ph = ''; drawRich(ex, '(' + (b.x || '') + ')', sliceRuns((b.fm && b.fm.x) || [], 0, (b.x || '').length, 1)); } w.appendChild(ex); }
    return w;
  }
  function renderCover() {
    var c = $('#cover'); c.innerHTML = ''; c.className = 'cvx ' + THK.cv.classes(cur); c.style.cssText = THK.cv.vars(cur, '');
    if (cur.logo) { var lg = el('img', 'clogo'); lg.src = cur.logo; lg.alt = ''; lg.draggable = false; c.appendChild(lg); }
    var f = function (key, ph) { var e = el('div', 'ed'); e.dataset.f = key; e.dataset.ph = ph; e.contentEditable = PT; e.spellcheck = false; drawRich(e, cur[key] || '', (cur.cfm || {})[key]); return e; };
    var t = f('title', 'The Main Title'); t.classList.add('ct'); c.appendChild(t);
    [['writer', 'Writer :', 'name'], ['director', 'Director :', 'name'], ['date', 'Date of the exporting :', 'auto – today’s date when you export']].forEach(function (r) {
      var l = el('div', 'cl'); l.appendChild(el('b', '', r[1])); l.appendChild(f(r[0], r[2])); c.appendChild(l);
    });
    var LB = THK.cv.labels(cur); c.querySelectorAll('.cl b').forEach(function (b, i) { b.textContent = [LB.w, LB.d, LB.t][i]; });
    if (window.THK && THK.pro) THK.pro.coverExtras(c, cur);
    c.appendChild(el('div', 'edh', 'Cover page – editable until you export. It has no title or page number on top.'));
  }
  function renderAll() {
    applyLook(); renderCover();
    var pg = $('#page'); pg.innerHTML = ''; cur.blocks.forEach(function (b) { pg.appendChild(mkBlock(b)); });
    var t = $('#ttl'); if (t) t.firstChild.nodeValue = cur.title || 'Untitled'; refreshSide(); refreshRibbon();
  }
  function blockEl(id) { return $('#page .b[data-id="' + id + '"]'); }
  /* ---- rich text: a field's DOM is text nodes plus <span data-r='{"b":1,"c":"#f00","z":18}'>; the model keeps text + runs {s,e,b,i,u,c,z} ---- */
  var RK = ['b', 'i', 'u', 'c', 'z'];
  function attrsOf(r) { var o = {}; RK.forEach(function (k) { if (r[k]) o[k] = r[k]; }); return o; }
  function akey(r) { return RK.map(function (k) { return r[k] || ''; }).join('|'); }
  function mergeRuns(runs, L) {
    var out = []; (runs || []).slice().sort(function (a, b) { return a.s - b.s; }).forEach(function (r) {
      var s0 = Math.max(0, r.s), e0 = Math.min(L, r.e); if (e0 <= s0 || !akey(r).replace(/\|/g, '')) return;
      var p = out[out.length - 1]; if (p && p.e === s0 && akey(p) === akey(r)) p.e = e0; else out.push(Object.assign({}, attrsOf(r), { s: s0, e: e0 }));
    }); return out;
  }
  function sliceRuns(runs, a, b, to) { var out = []; (runs || []).forEach(function (r) { var ns = Math.max(r.s, a), ne = Math.min(r.e, b); if (ns < ne) out.push(Object.assign({}, attrsOf(r), { s: ns - a + to, e: ne - a + to })); }); return out; }
  function shiftRuns(runs, d) { return (runs || []).map(function (r) { return Object.assign({}, attrsOf(r), { s: r.s + d, e: r.e + d }); }); }
  function runStyle(r) { return (r.b ? 'font-weight:700;' : '') + (r.i ? 'font-style:italic;' : '') + (r.u ? 'text-decoration:underline;' : '') + (r.c ? 'color:' + r.c + ';' : '') + (r.z ? 'font-size:' + (r.z * 1.3333).toFixed(2) + 'px;' : ''); }
  function drawRich(e, text, runs) {
    e.textContent = ''; if (!text) return; runs = mergeRuns(runs, text.length); var p = 0;
    runs.forEach(function (r) {
      if (r.s > p) e.appendChild(document.createTextNode(text.slice(p, r.s)));
      var sp = document.createElement('span'); sp.dataset.r = JSON.stringify(attrsOf(r)); sp.style.cssText = runStyle(r); sp.textContent = text.slice(r.s, r.e); e.appendChild(sp); p = r.e;
    });
    if (p < text.length) e.appendChild(document.createTextNode(text.slice(p)));
  }
  function readRich(e) {
    var text = '', runs = [], w = document.createTreeWalker(e, NodeFilter.SHOW_TEXT), n;
    while ((n = w.nextNode())) {
      var t = n.nodeValue; if (!t) continue; var a = null, p = n.parentNode;
      while (p && p !== e) { if (p.dataset && p.dataset.r) { try { a = JSON.parse(p.dataset.r); } catch (x) { } break; } p = p.parentNode; }
      if (a) runs.push(Object.assign({}, a, { s: text.length, e: text.length + t.length })); text += t;
    }
    if (text.slice(-1) === '\n') text = text.slice(0, -1);
    return { x: text, runs: mergeRuns(runs, text.length) };
  }
  function readField(e) { return readRich(e).x; }
  function tlen(n) { return n.textContent.length + (n.querySelectorAll ? n.querySelectorAll('br').length : 0); }
  function offAt(e, node, off) { var r = document.createRange(); r.selectNodeContents(e); r.setEnd(node, off); return tlen(r.cloneContents()); }
  function getCaret(e) { var s = getSelection(); if (!s.rangeCount || !e.contains(s.anchorNode)) return tlen(e); return offAt(e, s.anchorNode, s.anchorOffset); }
  function getSel(e) {
    var s = getSelection(); if (!s.rangeCount || !e.contains(s.anchorNode) || !e.contains(s.focusNode)) return null;
    var a = offAt(e, s.anchorNode, s.anchorOffset), b = offAt(e, s.focusNode, s.focusOffset); return a <= b ? { s: a, e: b } : { s: b, e: a };
  }
  function pointAt(e, pos) {
    var w = document.createTreeWalker(e, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, { acceptNode: function (n) { return n.nodeType === 3 || n.nodeName === 'BR' ? 1 : 3; } }), n, rem = pos;
    while ((n = w.nextNode())) {
      if (n.nodeType === 3) { if (rem <= n.length) return [n, rem]; rem -= n.length; }
      else { if (rem === 0) return [n.parentNode, Array.prototype.indexOf.call(n.parentNode.childNodes, n)]; rem -= 1; }
    }
    return [e, e.childNodes.length];
  }
  function setCaret(e, pos, end) {
    var a = pointAt(e, pos), b = end == null ? a : pointAt(e, end), r = document.createRange(); r.setStart(a[0], a[1]); r.setEnd(b[0], b[1]); var s = getSelection(); s.removeAllRanges(); s.addRange(r);
  }
  function drawBlockField(b, f) {
    var w = blockEl(b.id); if (!w) return; var e = $('.ed[data-f="' + f + '"]', w); if (!e) return; var r = (b.fm && b.fm[f]) || [];
    if (b.t === 'paren' && f === 'x') drawRich(e, '(' + (b.x || '') + ')', sliceRuns(r, 0, (b.x || '').length, 1)); else drawRich(e, b[f] || '', r);
  }
  function setFm(b, f, runs) { if (runs && (runs = mergeRuns(runs, 1e9)).length) { b.fm = b.fm || {}; b.fm[f] = runs; } else if (b.fm) { delete b.fm[f]; if (!Object.keys(b.fm).length) delete b.fm; } }
  function focusBlock(id, pos, field) {
    var w = blockEl(id); if (!w) return; var e = $('.ed[data-f="' + (field || 'x') + '"]', w) || $('.ed', w); e.focus(); setCaret(e, pos == null ? e.textContent.length : pos); keepVisible(e);
  }
  function keepVisible(e) { try { e.scrollIntoView({ block: 'nearest' }); } catch (x) { } }
  function setCur(id) {
    var b = blockById(id); if (!b || cb === b) { updateElSel(); return; } cb = b;
    $$('#page .b.cur').forEach(function (x) { x.classList.remove('cur'); }); var w = blockEl(id); if (w) w.classList.add('cur'); updateElSel(); suggest();
  }

  /* ------------------------------------------------------------------ editing events */
  var tl = { buf: '', len: 0, pos: -1, el: null, busy: false };
  function syncField(e) {
    var rd = readRich(e), f = e.dataset.f;
    if (e.closest('#cover')) {
      cur[f] = rd.x; cur.cfm = cur.cfm || {}; if (rd.runs.length) cur.cfm[f] = rd.runs; else delete cur.cfm[f];
      if (f === 'title') { var t = $('#ttl'); if (t) t.firstChild.nodeValue = cur.title || 'Untitled'; }
    } else {
      var w = e.closest('.b'); if (!w) return; var b = blockById(w.dataset.id);
      if (b && b.t === 'paren' && f === 'x') {
        var t2 = rd.x, inner = t2.replace(/^\(/, '').replace(/\)$/, ''), off = t2.charAt(0) === '(' ? 1 : 0, ir = sliceRuns(rd.runs, off, off + inner.length, 0);
        if (!/^\([\s\S]*\)$/.test(t2)) { var c = getCaret(e); drawRich(e, '(' + inner + ')', sliceRuns(ir, 0, inner.length, 1)); setCaret(e, Math.max(1, Math.min(c, inner.length + 1))); }
        b.x = inner; setFm(b, 'x', ir);
      } else if (b) { b[f] = rd.x; setFm(b, f, rd.runs); }
    }
    dirty(); snapSoon();
  }
  function trFn() { return S.lang === 'ml' || !(window.THK && THK.IT) ? ML.translit : THK.IT.fn(S.lang); }
  function tlType(e, ch) {
    var pos = getCaret(e), sel = getSel(e), over = sel && sel.s !== sel.e;
    if (over || tl.el !== e || tl.pos !== pos) { tl.buf = ''; tl.len = 0; tl.el = e; }
    if (!tl.buf) tl.len = 0; tl.buf += ch; var out = trFn()(tl.buf), start = over ? sel.s : pos - tl.len, endp = over ? sel.e : pos;
    tl.busy = true; try { setCaret(e, start, endp); document.execCommand('insertText', false, out); } finally { tl.busy = false; }
    tl.len = out.length; tl.pos = start + out.length;
  }
  function tlBack(e) {
    var pos = getCaret(e); tl.buf = tl.buf.slice(0, -1); var out = tl.buf ? trFn()(tl.buf) : '', start = pos - tl.len;
    tl.busy = true; try { setCaret(e, start, pos); if (out) document.execCommand('insertText', false, out); else document.execCommand('delete'); } finally { tl.busy = false; }
    tl.len = out.length; tl.pos = tl.buf ? start + out.length : -1;
  }
  function addAfter(i, nb, focusPos) {
    snap(); cur.blocks.splice(i + 1, 0, nb); var w = mkBlock(nb), ref = blockEl(cur.blocks[i].id); ref.after(w); snap(); dirty(); refreshSide(); focusBlock(nb.id, focusPos || 0);
  }
  function onKey(ev) {
    var e = ev.target.closest && ev.target.closest('.ed'); if (!e) return; var inCover = !!e.closest('#cover');
    var k = ev.key, mod = ev.ctrlKey || ev.metaKey;
    if (mod) {
      var lk = k.toLowerCase();
      if (lk === 'z' && !ev.shiftKey) { ev.preventDefault(); return undo(); }
      if (lk === 'y' || (lk === 'z' && ev.shiftKey)) { ev.preventDefault(); return redo(); }
      if (lk === 's') { ev.preventDefault(); return ev.shiftKey ? saveAs() : save(); }
      if (lk === 'f') { ev.preventDefault(); return findDlg(); }
      if (lk === 'b' || lk === 'i' || lk === 'u') { ev.preventDefault(); return applyFmt(lk); }
      if (lk === 'k') { ev.preventDefault(); return palette(); }
      if (k === 'Enter') { ev.preventDefault(); return nextPage(); }
      if (k === ' ') { ev.preventDefault(); return setLang(S.lang === 'ml' ? 'en' : 'ml'); }
      if (k === 'ArrowUp' || k === 'ArrowDown') { ev.preventDefault(); return jumpScene(k === 'ArrowUp' ? -1 : 1); }
      return;
    }
    if (inCover) {
      if (k === 'Enter' && !ev.shiftKey) { ev.preventDefault(); var all = $$('#cover .ed'), i = all.indexOf(e); if (i < all.length - 1) { all[i + 1].focus(); setCaret(all[i + 1], 1e6); } else focusBlock(cur.blocks[0].id, 0); return; }
      if (k.length === 1 && S.ml && /[A-Za-z]/.test(k) && !ev.altKey && e.dataset.f !== 'date') { ev.preventDefault(); return tlType(e, k); }
      if (k === 'Backspace' && tl.buf && tl.el === e && tl.pos === getCaret(e)) { ev.preventDefault(); return tlBack(e); }
      tl.buf = ''; return;
    }
    var w = e.closest('.b'), b = blockById(w.dataset.id), i2 = idxOf(b.id), f = e.dataset.f;
    if (k.length === 1 && S.ml && /[A-Za-z]/.test(k) && !ev.altKey) { ev.preventDefault(); return tlType(e, k); }
    if (k === 'Tab' && !ev.shiftKey && window.THK && THK.x && THK.x.snippet && THK.x.snippet(e, b)) { ev.preventDefault(); return; }
    if (k === 'Backspace' && tl.buf && tl.el === e && tl.pos === getCaret(e)) { ev.preventDefault(); return tlBack(e); }
    if (k !== 'Shift' && k !== 'Control' && k !== 'Alt') tl.buf = '';
    if (k === 'Enter' && ev.shiftKey) { ev.preventDefault(); document.execCommand('insertText', false, '\n'); return; }
    if (k === 'Enter') {
      ev.preventDefault(); var pos = getCaret(e), rd = readRich(e), txt = rd.x;
      if (b.t === 'scene' && cur.fmt === 'two' && f === 'x') { var e2 = $('.ed[data-f=x2]', w); e2.focus(); setCaret(e2, 0); return; }
      if (b.t === 'paren') { addAfter(i2, { id: uid(), t: 'dial', x: '' }, 0); return; }
      var before = txt.slice(0, pos), after = txt.slice(pos);
      if (!txt.trim() && f === 'x' && b.t !== 'scene' && !b.pb) { setType(b, 'scene'); return; } // Enter on an empty line → scene heading
      var lr = sliceRuns(rd.runs, 0, pos, 0), rr = sliceRuns(rd.runs, pos, txt.length, 0);
      b[f] = before; setFm(b, f, lr); drawRich(e, before, lr); var nt = NEXT[b.t] || 'action';
      if (b.t === 'scene' && cur.fmt === 'two' && f === 'x2') { if (b.x2 === undefined) b.x2 = ''; }
      var nb = { id: uid(), t: nt, x: after }; if (rr.length) nb.fm = { x: rr }; if (nt === 'scene') nb.x2 = ''; addAfter(i2, nb, 0); return;
    }
    if (k === 'Backspace' && getSelection().isCollapsed && (getCaret(e) === 0 || (b.t === 'paren' && readField(e) === '()' && getCaret(e) <= 1))) {
      if (f === 'x2') { ev.preventDefault(); focusBlock(b.id, null, 'x'); return; }
      if (i2 > 0) {
        ev.preventDefault(); snap(); var pv = cur.blocks[i2 - 1], rd2 = readRich(e), txt2 = b.t === 'paren' ? (b.x || '') : rd2.x, r2 = b.t === 'paren' ? ((b.fm && b.fm.x) || []) : rd2.runs, joinAt = (pv.x || '').length;
        if (!txt2 && pv.t === 'scene' && cur.fmt === 'two' && false) { }
        setFm(pv, 'x', ((pv.fm && pv.fm.x) || []).concat(shiftRuns(r2, joinAt))); pv.x = (pv.x || '') + txt2; cur.blocks.splice(i2, 1); w.remove(); drawBlockField(pv, 'x'); snap(); dirty(); refreshSide(); focusBlock(pv.id, joinAt + (pv.t === 'paren' ? 1 : 0));
      }
      return;
    }
    if (k === 'Tab') { if (!ev.shiftKey && window.THK && THK.x && THK.x.snippet && THK.x.snippet(e, b)) { ev.preventDefault(); return; } ev.preventDefault(); var j = ORDER.indexOf(b.t); j = j < 0 ? 1 : j; setType(b, ORDER[(j + (ev.shiftKey ? ORDER.length - 1 : 1)) % ORDER.length]); return; }
    if (k === 'ArrowUp' && !ev.shiftKey && caretOnFirstLine(e) && i2 > 0) { ev.preventDefault(); focusBlock(cur.blocks[i2 - 1].id, null); return; }
    if (k === 'ArrowDown' && !ev.shiftKey && caretOnLastLine(e) && i2 < cur.blocks.length - 1) { ev.preventDefault(); focusBlock(cur.blocks[i2 + 1].id, 0); return; }
  }
  function caretRect(e) { var s = getSelection(); if (!s.rangeCount) return null; var r = s.getRangeAt(0).cloneRange(); var rs = r.getClientRects(); return rs.length ? rs[0] : e.getBoundingClientRect(); }
  function caretOnFirstLine(e) { if (e.textContent.indexOf('\n') < 0 && getCaret(e) === 0) return true; var c = caretRect(e), b = e.getBoundingClientRect(); return !c || c.top - b.top < 6; }
  function caretOnLastLine(e) { var c = caretRect(e), b = e.getBoundingClientRect(); return !c || b.bottom - c.bottom < 6; }
  function onInput(ev) { var e = ev.target.closest && ev.target.closest('.ed'); if (!e) return; if (tl.el === e && !tl.busy && getCaret(e) !== tl.pos) tl.buf = ''; syncField(e); keepVisible(e); suggest(); }
  function onPaste(ev) {
    var e = ev.target.closest && ev.target.closest('.ed'); if (!e) return; ev.preventDefault();
    var t = (ev.clipboardData || window.clipboardData).getData('text/plain').replace(/\r/g, ''); tl.buf = '';
    var lines = t.split('\n'); if (e.closest('#cover') || lines.length < 2 || e.dataset.f === 'x2') { document.execCommand('insertText', false, t.replace(/\n+/g, ' ')); return; }
    var w = e.closest('.b'), b = blockById(w.dataset.id), i = idxOf(b.id), pos = getCaret(e), rdp = readRich(e), txt = rdp.x, after = txt.slice(pos);
    b.x = txt.slice(0, pos) + lines[0]; setFm(b, 'x', sliceRuns(rdp.runs, 0, pos, 0)); drawBlockField(b, 'x'); var last = i, nbs = [];
    lines.slice(1).forEach(function (l) { nbs.push({ id: uid(), t: b.t === 'scene' ? 'action' : b.t, x: l }); });
    var ln = nbs[nbs.length - 1]; ln.x += after; setFm(ln, 'x', sliceRuns(rdp.runs, pos, txt.length, ln.x.length - after.length)); snap(); nbs.forEach(function (nb) { cur.blocks.splice(++last, 0, nb); }); renderAll(); snap(); dirty(); focusBlock(nbs[nbs.length - 1].id, nbs[nbs.length - 1].x.length - after.length);
  }
  function onFocus(ev) { var fe = ev.target.closest && ev.target.closest('.ed'); updateDock(fe); var w = ev.target.closest && ev.target.closest('#page .b'); if (w) setCur(w.dataset.id); else if (ev.target.closest && ev.target.closest('#cover')) { cb = null; $$('#page .b.cur').forEach(function (x) { x.classList.remove('cur'); }); } }
  /* Transition picker: txt = preset text, or null for "Custom" (opens the keyboard) */
  function applyTrans(txt) {
    if (!cb) return toast('Click on a line first');
    var b = cb, i = idxOf(b.id), t;
    if (txt == null) {
      if (b.t === 'trans' || !(b.x || '').trim()) { setType(b, 'trans'); return; }
      snap(); var nb = { id: uid(), t: 'trans', x: '' }; cur.blocks.splice(i + 1, 0, nb); blockEl(b.id).after(mkBlock(nb)); snap(); dirty(); refreshSide(); focusBlock(nb.id, 0); return;
    }
    snap();
    if (b.t === 'trans' || !(b.x || '').trim()) {
      var was = b.t; b.t = 'trans'; b.x = txt; if (b.fm) { delete b.fm.x; if (!Object.keys(b.fm).length) delete b.fm; } delete b.x2;
      var old = blockEl(b.id), nw = mkBlock(b); old.replaceWith(nw); t = b;
    } else { t = { id: uid(), t: 'trans', x: txt }; cur.blocks.splice(i + 1, 0, t); blockEl(b.id).after(mkBlock(t)); }
    if (idxOf(t.id) === cur.blocks.length - 1) { var ns = { id: uid(), t: 'scene', x: '', x2: '' }; cur.blocks.push(ns); $('#page').appendChild(mkBlock(ns)); }
    try { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); } catch (e) { }
    cb = null; setCur(t.id); snap(); dirty(); refreshSide(); updateElSel(); keepVisible(blockEl(t.id));
  }
  function setType(b, t) {
    snap(); b.t = t; if (t === 'scene' && b.x2 === undefined) b.x2 = ''; var old = blockEl(b.id), nw = mkBlock(b); old.replaceWith(nw); if (cb && cb.id === b.id) nw.classList.add('cur'); snap(); dirty(); refreshSide(); updateElSel(); if (t === 'paren') focusBlock(b.id, (b.x || '').length + 1); else focusBlock(b.id, null);
  }
  function setAlign(a) { if (!cb) return toast('Click on a line first'); snap(); cb.al = cb.al === a ? '' : a; var w = blockEl(cb.id); ['left', 'center', 'right', 'justify'].forEach(function (x) { w.classList.remove('al-' + x); }); if (cb.al) w.classList.add('al-' + cb.al); snap(); dirty(); }
  function nextPage() {
    if (!cb) cb = cur.blocks[cur.blocks.length - 1]; var i = idxOf(cb.id); snap();
    if (!(cb.x || '').trim() && !(cb.x2 || '').trim()) { cb.pb = !cb.pb; var w = blockEl(cb.id); w.classList.toggle('pb', cb.pb); if (cb.pb) w.dataset.pg = 'page break · next page'; focusBlock(cb.id, 0); toast(cb.pb ? 'New page started' : 'Page break removed'); snap(); dirty(); return; }
    var nb = { id: uid(), t: 'scene', x: '', x2: '', pb: true }; addAfter(i, nb, 0); toast('Next page started');
  }
  function jumpScene(d) {
    var i = cb ? idxOf(cb.id) : 0, j = i + d; while (j >= 0 && j < cur.blocks.length && cur.blocks[j].t !== 'scene') j += d; if (j >= 0 && j < cur.blocks.length) focusBlock(cur.blocks[j].id, null);
  }

  /* ------------------------------------------------------------------ character suggestions */
  function suggest() {
    var s = $('#sug'); if (!s) return; s.innerHTML = '';
    if (!cb || cb.t !== 'char') { s.hidden = true; return; }
    var q = (cb.x || '').trim(), seen = {}, names = [];
    cur.blocks.forEach(function (b) { if (b.t === 'char' && b !== cb) { var n = (b.x || '').trim(); if (n && !seen[n] && n !== q && (!q || n.indexOf(q) === 0)) { seen[n] = 1; names.push(n); } } });
    if (!names.length) { s.hidden = true; return; }
    names.slice(0, 8).forEach(function (n) { var b = el('button', 'btn sm', esc(n)); b.onmousedown = function (e) { e.preventDefault(); cb.x = n; delete cb.fm; drawBlockField(cb, 'x'); dirty(); var i = idxOf(cb.id); var nb = { id: uid(), t: cur.fmt === 'two' ? 'dial' : 'dial', x: '' }; addAfter(i, nb, 0); }; s.appendChild(b); });
    s.hidden = false;
  }

  /* ------------------------------------------------------------------ text formatting, cover title fonts, languages */
  var lastSel = null, SWATCH = ['#000000', '#ffffff', '#d32f2f', '#ef6c00', '#f9a825', '#2e7d32', '#1565c0', '#6a1b9a', '#ad1457', '#6d4c41'], SIZES = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 40, 48, 60, 72];
  function fmtTarget() {
    var a = document.activeElement; a = a && a.closest && a.closest('.ed'); if (a) return a;
    return lastSel && lastSel.e.isConnected ? lastSel.e : null;
  }
  function applyFmt(prop, val) {
    var e = fmtTarget(); if (!e) return toast('Click in the text first');
    var rd = readRich(e), L = rd.x.length; if (!L) return toast('Type something first');
    var sel = getSel(e); if (!sel && lastSel && lastSel.e === e) sel = { s: lastSel.s, e: lastSel.en };
    var whole = !sel || sel.s === sel.e; if (whole) sel = { s: 0, e: L };
    var arr = new Array(L), i; rd.runs.forEach(function (r) { for (var k = r.s; k < r.e && k < L; k++) arr[k] = attrsOf(r); });
    var on = true; if (prop === 'b' || prop === 'i' || prop === 'u') { on = false; for (i = sel.s; i < sel.e; i++) if (!(arr[i] && arr[i][prop])) { on = true; break; } }
    for (i = sel.s; i < sel.e; i++) {
      var a = Object.assign({}, arr[i] || {});
      if (prop === 'clear') a = {}; else if (prop === 'c' || prop === 'z') { if (val) a[prop] = val; else delete a[prop]; } else if (on) a[prop] = 1; else delete a[prop];
      arr[i] = a;
    }
    var runs = [], cur0 = null; for (i = 0; i < L; i++) { var a2 = arr[i] || {}, key = akey(a2); if (cur0 && cur0.k === key) cur0.e = i + 1; else { cur0 = { k: key, s: i, e: i + 1, a: a2 }; runs.push(cur0); } }
    runs = runs.map(function (r) { return Object.assign({}, r.a, { s: r.s, e: r.e }); });
    tl.buf = ''; tl.len = 0; drawRich(e, rd.x, mergeRuns(runs, L)); e.focus(); setCaret(e, sel.s, sel.e); lastSel = { e: e, s: sel.s, en: sel.e };
    syncField(e); snap(); if (whole) toast('Nothing selected – applied to the whole line'); updateDock(e);
  }
  function updateDock(e) {
    var d = $('#dock'); if (!d) return;
    var isT = !!(e && e.classList.contains('ct')); d.classList.toggle('showT', isT); var tf = $('#tfont'); if (tf) { tf.hidden = !isT; if (isT) markTitleFont(); }
    var rd = e && readRich(e), sel = e && getSel(e), st = {};
    if (rd && sel) {
      var a = sel.s === sel.e ? Math.max(0, sel.s - 1) : sel.s, z = sel.s === sel.e ? sel.s : sel.e;
      ['b', 'i', 'u'].forEach(function (k) { var all = z > a; for (var i = a; i < z; i++) { var r = rd.runs.filter(function (r) { return r.s <= i && i < r.e; })[0]; if (!(r && r[k])) { all = false; break; } } st[k] = all; });
    }
    ['b', 'i', 'u'].forEach(function (k) { var x = $('.fmtp [data-k="' + k + '"]'); if (x) x.classList.toggle('on', !!st[k]); });
  }
  function buildDock() {
    var D = $('#dock'); D.innerHTML = '';
    var sg = el('div', ''); sg.id = 'sug'; sg.hidden = true; D.appendChild(sg);
    var tf = el('div', 'strip'); tf.id = 'tfont'; tf.hidden = true; D.appendChild(tf);
  }
  /* Format drop-down: bold / italic / underline, size, colour (replaces the old always-visible strip) */
  function fmtMenu(anchor) {
    pop(anchor, function (m) {
      m.classList.add('fmtp'); var nb = function (e) { e.preventDefault(); };
      m.appendChild(el('div', 'hd', 'Style'));
      var r1 = el('div', 'frow'); [['Bold', 'b'], ['Italic', 'i'], ['Underline', 'u']].forEach(function (x) { var b = el('button', 'btn fb fb-' + x[1], x[0]); b.dataset.k = x[1]; b.onmousedown = nb; b.onclick = function () { applyFmt(x[1]); }; r1.appendChild(b); }); m.appendChild(r1);
      m.appendChild(el('div', 'hd', 'Text alignment'));
      var ra = el('div', 'frow wrap'); [['Left', 'left'], ['Centre', 'center'], ['Right', 'right'], ['Justify', 'justify']].forEach(function (x) {
        var b = el('button', 'btn fa', x[0]); b.dataset.a = x[1]; b.onmousedown = nb;
        b.onclick = function () { setAlign(x[1]); $$('.fmtp .fa').forEach(function (y) { y.classList.toggle('on', y.dataset.a === ((cb && cb.al) || 'left')); }); }; ra.appendChild(b);
      }); m.appendChild(ra); $$('.fa', ra).forEach(function (y) { y.classList.toggle('on', y.dataset.a === ((cb && cb.al) || 'left')); });
      m.appendChild(el('div', 'hd', 'Size'));
      var r2 = el('div', 'frow wrap'); SIZES.forEach(function (n) { var b = el('button', 'btn sm', String(n)); b.onmousedown = nb; b.onclick = function () { applyFmt('z', n); }; r2.appendChild(b); }); m.appendChild(r2);
      m.appendChild(el('div', 'hd', 'Colour'));
      var r3 = el('div', 'frow wrap'); SWATCH.forEach(function (c) { var b = el('button', 'sw'); b.style.background = c; b.title = c; b.onmousedown = nb; b.onclick = function () { applyFmt('c', c); }; r3.appendChild(b); });
      var ci = el('input'); ci.type = 'color'; ci.className = 'swc'; ci.value = '#d32f2f'; ci.onchange = function () { applyFmt('c', ci.value); }; r3.appendChild(ci); m.appendChild(r3);
      var r4 = el('div', 'frow'); [['Auto colour', function () { applyFmt('c', null); }], ['Plain text', function () { applyFmt('clear'); }]].forEach(function (x) { var b = el('button', 'btn', x[0]); b.onmousedown = nb; b.onclick = x[1]; r4.appendChild(b); }); m.appendChild(r4);
    }, { cls: 'wide' });
    if (lastSel) updateDock(lastSel.e);
  }
  function buildTitleStrip() {
    var tf = $('#tfont'); if (!tf) return; tf.innerHTML = ''; tf.appendChild(el('b', 'lbl', 'Title font'));
    var list = THK.fontsFor(S.lang, true); if (S.lang !== 'en') list = list.concat(THK.fontsFor('en', true).filter(function (f) { return f.type === 'd'; }));
    var def = btn('Same as script', function () { setTitleFont(''); }, 'sm', 'Use the script font for the title'); def.dataset.f = ''; tf.appendChild(def);
    list.forEach(function (f) { var b = btn(f.label, function () { setTitleFont(f.id); }, 'sm', f.label); b.dataset.f = f.id; b.style.fontFamily = f.stack; THK.loadFont(f.id); tf.appendChild(b); });
  }
  function markTitleFont() { $$('#tfont .btn').forEach(function (b) { b.classList.toggle('on', b.dataset.f === (cur.titleFont || '')); }); }
  function setTitleFont(id) { snap(); if (id) { cur.titleFont = id; THK.loadFont(id); } else delete cur.titleFont; applyLook(); markTitleFont(); snap(); dirty(); }
  function fillFonts() {
    var fs = R.font; if (!fs) return; fs.innerHTML = '';
    THK.fontsFor(S.lang, false).forEach(function (f) { var o = el('option', '', f.label); o.value = f.id; o.dataset.ff = f.stack; fs.appendChild(o); THK.loadFont(f.id); }); fs.value = cur.font;
  }
  function setLang(id, quiet) {
    var L = THK.lang(id); S.lang = L.id; S.ml = !!L.translit; saveS();
    if (cur) { cur.lang = L.id; if (!THK.fontsFor(L.id, false).some(function (f) { return f.id === cur.font; })) cur.font = L.def; THK.loadFont(cur.font); applyLook(); fillFonts(); buildTitleStrip(); dirty(); }
    refreshRibbon(); tl.buf = ''; if (window.THK && THK.notes && THK.notes.onLang) THK.notes.onLang();
    if (!quiet) toast(L.translit ? L.name + ' – phonetic typing ON (type in English letters)' : L.name + ' fonts – type with your ' + L.name + ' keyboard');
  }
  function langMenu(a) {
    var items = [{ hd: 'Writing language' }, { l: 'English', sel: S.lang === 'en', fn: function () { setLang('en'); } }];
    if (S.lang !== 'en') { var C = THK.lang(S.lang); items.push({ l: C.native, s: C.name, sel: true, fn: function () { setLang(C.id); } }); }
    items.push({ hr: 1 }, { hd: 'Choose by country' });
    THK.COUNTRIES.forEach(function (c) { items.push({ l: c[0], s: c[1].length > 1 ? c[1].length + ' languages' : THK.lang(c[1][0]).name, fn: function () { setTimeout(function () { langSub(a, c); }, 150); } }); });
    if (THK.lang(S.lang).translit) items.push({ hr: 1 }, { l: S.ml ? 'Turn phonetic typing off' : 'Turn phonetic typing on', fn: function () { S.ml = !S.ml; saveS(); refreshRibbon(); toast(S.ml ? 'Phonetic typing ON' : 'Phonetic typing OFF'); } });
    menu(a, items);
  }
  function langSub(a, c) {
    var items = [{ hd: c[0] }];
    c[1].forEach(function (id) { var L = THK.lang(id); items.push({ l: L.native, s: L.name !== L.native ? L.name : '', sel: S.lang === id, fn: function () { setLang(id); } }); });
    items.push({ hr: 1 }, { l: 'All countries', fn: function () { setTimeout(function () { langMenu(a); }, 150); } });
    menu(a, items);
  }
  document.addEventListener('selectionchange', function () {
    var s = getSelection(); if (!s.rangeCount) return; var n = s.anchorNode, e = n && (n.nodeType === 1 ? n : n.parentElement); e = e && e.closest && e.closest('.ed'); if (!e || !cur) return;
    var g = getSel(e); if (g) { lastSel = { e: e, s: g.s, en: g.e }; updateDock(e); }
  });

  /* ------------------------------------------------------------------ ribbon / top bar / accessory */
  var R = {};
  function btn(label, fn, cls, title) { var b = el('button', 'btn ' + (cls || ''), clean(label)); b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = fn; if (title && !mob()) b.title = title; return b; }
  function buildChrome() {
    var T = $('#top'); T.innerHTML = '';
    T.appendChild(btn('Home', goHome, '', 'Home'));
    var tt = el('div', 'ttl', ''); tt.id = 'ttl'; tt.appendChild(document.createTextNode(cur.title || 'Untitled')); var sd = el('small', '', ''); sd.id = 'svdot'; tt.appendChild(sd);
    tt.onclick = function () { ask('Script title', 'Title', cur.title || '', function (v) { snap(); cur.title = (v || '').trim(); if (cur.cfm) delete cur.cfm.title; renderAll(); snap(); dirty(); }, 'Save'); }; T.appendChild(tt);
    T.appendChild(btn('More', function (e) { moreMenu(e.currentTarget); }, '', 'More'));
    var Rb = $('#ribbon'); Rb.innerHTML = '';
    R.undo = btn('Undo', undo, '', 'Undo'); R.redo = btn('Redo', redo, '', 'Redo'); Rb.appendChild(R.undo); Rb.appendChild(R.redo); Rb.appendChild(el('i', 'sep'));
    var sel = el('select', 't'); sel.id = 'elsel'; ORDER.concat(['shot', 'note']).forEach(function (t) { var o = el('option', '', LAB[t]); o.value = t; sel.appendChild(o); });
    sel.title = 'Line type'; sel.onchange = function () { if (sel.value === '__cx') { sel.value = cb ? cb.t : 'action'; if (THK.el) THK.el.manage(); return; } if (cb) setType(cb, sel.value); }; Rb.appendChild(sel); upgradeSelect(sel); if (THK.el) { THK.el.reset(); THK.el.apply(cur); }
    Rb.appendChild(el('i', 'sep'));
    var fs = el('select', 't'); fs.title = 'Font'; fs.onchange = function () { cur.font = fs.value; THK.loadFont(cur.font); applyLook(); dirty(); }; R.font = fs; Rb.appendChild(fs); fillFonts(); upgradeSelect(fs);
    var sz = el('select', 't'); [10, 11, 12, 13, 14, 16, 18, 20].forEach(function (n) { var o = el('option', '', n + ' pt'); o.value = n; sz.appendChild(o); }); sz.value = cur.size; sz.title = 'Page text size'; sz.onchange = function () { cur.size = +sz.value; applyLook(); dirty(); }; R.size = sz; Rb.appendChild(sz); upgradeSelect(sz);
    Rb.appendChild(btn('Format', function (e) { fmtMenu(e.currentTarget); }, '', 'Bold, italic, alignment, size and colour'));
    Rb.appendChild(el('i', 'sep'));
    Rb.appendChild(btn('Colours', colourDlg, '', 'Page and text colour')); Rb.appendChild(btn('Reverse', reverseColours, '', 'Reverse page / text colours (click again to undo)'));
    Rb.appendChild(btn('Marker', function (e) { markerMenu(e.currentTarget); }, '', 'Mark a line with a colour'));
    Rb.appendChild(el('i', 'sep'));
        Rb.appendChild(btn('Save', save, '', 'Save (Ctrl+S)')); Rb.appendChild(btn('Export', exportDlg, 'pri', 'Export PDF / FDX / Fountain'));
    var A = $('#acc'); A.innerHTML = ''; buildDock(); buildTitleStrip();
    if (window.THK && THK.pro && THK.pro.speakBtn) A.appendChild(THK.pro.speakBtn());
    ORDER.forEach(function (t) { var b = btn(LAB[t].replace(' heading', ''), function (e) { if (!cb) return toast('Click on a line first'); if (t === 'trans' && THK.el) return THK.el.transPanel(e.currentTarget); setType(cb, t); }, '', LAB[t]); b.dataset.t = t; A.appendChild(b); });
    A.appendChild(btn('Next page', nextPage, 'pri np', 'Start the next page (Ctrl+Enter)'));
    R.ml = btn('', function (e) { langMenu(e.currentTarget); }, '', 'Writing language'); A.appendChild(R.ml);
    refreshRibbon();
  }
  function refreshRibbon() { if (R.ml) { R.ml.textContent = THK.lang(S.lang).native; R.ml.classList.toggle('on', !!S.ml); } if (R.font && cur) { R.font.value = cur.font; R.size.value = cur.size; } updateElSel(); if (window.THK && THK.notes && THK.notes.refresh) THK.notes.refresh(); if (window.THK && THK.cvEd && THK.cvEd.refresh) THK.cvEd.refresh(); }
  function updateElSel() { var s = $('#elsel'); if (s && cb) s.value = cb.t; $$('#acc .btn[data-t]').forEach(function (b) { b.classList.toggle('on', !!cb && b.dataset.t === cb.t); }); }
  function moreMenu(a) {
    var ae = document.activeElement; if (ae && ae.closest && ae.closest('.ed')) { ae.blur(); setTimeout(function () { moreMenu2(a); }, 160); return; } moreMenu2(a);
  }
  function moreMenu2(a) {
    var X = (window.THK && THK.x && THK.x.menu) ? THK.x.menu() : {}, P = (window.THK && THK.pro && THK.pro.menu) ? THK.pro.menu() : {};
    menu(a, [
      { hd: 'File' }, { l: 'Save', k: 'Ctrl+S', fn: save }, { l: 'Save As', k: 'Ctrl+Shift+S', fn: saveAs }, { l: 'Export', fn: exportDlg }, { l: 'Import file', fn: pickImport },
      { hr: 1 }, { hd: 'Script' }, { l: 'Edit cover page', fn: function () { $('#scroll').scrollTop = 0; var e = $('#cover .ed'); e.focus(); setCaret(e, 1e6); } },
      { l: 'Switch to ' + (cur.fmt === 'two' ? 'Standard' : 'Two Column') + ' layout', fn: switchFmt }, X.outline, X.history, P.production, P.design,
      { hr: 1 }, { hd: 'View' }, X.focus, P.cine, X.reading, X.read, { l: 'Scenes & markers panel', fn: function () { toggleSide(); } },
      { hr: 1 }, { hd: 'Tools' }, { l: 'Find & replace', k: 'Ctrl+F', fn: findDlg }, P.dictate, P.search, P.backup, mob() ? null : X.snips, X.custom, mob() ? null : { l: 'Command palette', k: 'Ctrl+K', fn: palette },
      { hr: 1 }, { l: mob() ? 'Help' : 'Help & shortcuts', fn: helpDlg }, { l: 'Theme', fn: themeDlg }, { l: 'About finnish', fn: about }
    ].filter(Boolean), true);
  }
  function switchFmt() {
    snap(); cur.fmt = cur.fmt === 'two' ? 'std' : 'two'; cur.blocks.forEach(function (b) { if (b.t === 'scene' && b.x2 === undefined) b.x2 = ''; }); renderAll(); dirty(); toast('Layout: ' + (cur.fmt === 'two' ? 'Two Column' : 'Standard'));
  }

  /* ------------------------------------------------------------------ colours, markers */
  function colourDlg() {
    var b = el('div', ''); b.appendChild(el('p', '', 'One tap changes the whole page and all the text. “Reverse” swaps them and swaps back on the next tap.'));
    var g = el('div', 'grid'); b.appendChild(g);
    var d;
    PRESETS.forEach(function (p) { var c = el('div', 'pc', THK.lang(cur.lang).sample || 'Aa'); c.style.background = p[1]; c.style.color = p[2]; c.title = p[0]; if (cur.pageColor.toLowerCase() === p[1] && cur.textColor.toLowerCase() === p[2]) c.classList.add('sel'); c.onclick = function () { setColours(p[1], p[2]); $$('.pc', g).forEach(function (x) { x.classList.remove('sel'); }); c.classList.add('sel'); cp.value = p[1]; ct.value = p[2]; }; g.appendChild(c); });
    var r = el('div', 'row'); r.style.margin = '10px 0 0';
    var cp = el('input'); cp.type = 'color'; cp.value = cur.pageColor; var ct = el('input'); ct.type = 'color'; ct.value = cur.textColor;
    cp.oninput = function () { setColours(cp.value, cur.textColor); }; ct.oninput = function () { setColours(cur.pageColor, ct.value); };
    r.appendChild(el('span', '', 'Page')); r.appendChild(cp); r.appendChild(el('span', '', 'Text')); r.appendChild(ct); b.appendChild(r);
    dlg('Page & text colour', b, [{ l: 'Reverse', fn: function () { reverseColours(); cp.value = cur.pageColor; ct.value = cur.textColor; return false; } }, { l: 'Reset', fn: function () { setColours('#ffffff', '#000000'); } }, { l: 'Done', cls: 'pri' }]);
  }
  function setColours(p, t) { cur.pageColor = p; cur.textColor = t; applyLook(); dirty(); }
  function reverseColours() { setColours(cur.textColor, cur.pageColor); toast('Colours reversed'); }
  function markerMenu(a) {
    var items = [{ hd: 'Mark current line' }]; MARKS.forEach(function (m) { items.push({ l: m[0], dot: m[1], fn: function () { mark(m[1], false); } }); });
    items.push({ hr: 1 }, { hd: 'Mark whole scene' }); MARKS.forEach(function (m) { items.push({ l: m[0] + ' – scene', dot: m[1], fn: function () { mark(m[1], true); } }); });
    items.push({ hr: 1 }, { l: 'Clear marker (line)', fn: function () { mark('', false); } }, { l: 'Clear all markers', fn: function () { snap(); cur.blocks.forEach(function (b) { delete b.mk; }); renderAll(); dirty(); } });
    menu(a, items);
  }
  function mark(c, scene) {
    if (!cb) return toast('Click on a line first'); snap(); var i = idxOf(cb.id), from = i, to = i;
    if (scene) { while (from > 0 && cur.blocks[from].t !== 'scene') from--; to = from + 1; while (to < cur.blocks.length && cur.blocks[to].t !== 'scene') to++; to--; }
    for (var j = from; j <= to; j++) { var b = cur.blocks[j]; if (c) b.mk = c; else delete b.mk; var w = blockEl(b.id); w.classList.toggle('mk', !!c); if (c) w.style.setProperty('--mk', c); else w.style.removeProperty('--mk'); }
    snap(); dirty(); refreshSide();
  }

  /* ------------------------------------------------------------------ side panel */
  var sideTab = 'scenes';
  function toggleSide(force) { var s = $('#side'); s.hidden = force === false ? true : !s.hidden; refreshSide(); }
  function sideClosesOnPhone() { if (innerWidth <= 900) toggleSide(false); }
  function refreshSide() {
    var s = $('#side'); if (!s || s.hidden) return; s.innerHTML = '';
    var t = el('div', 'tabs'); [['scenes', 'Scenes'], ['marks', 'Markers']].forEach(function (x) { var b = el('button', 'btn sm' + (sideTab === x[0] ? ' on' : ''), x[1]); b.onclick = function () { sideTab = x[0]; refreshSide(); }; t.appendChild(b); }); var cx = el('button', 'btn sm', 'Close'); cx.title = 'Close'; cx.onclick = function () { toggleSide(false); }; t.appendChild(cx); s.appendChild(t);
    var words = 0; cur.blocks.forEach(function (b) { words += ((b.x || '') + ' ' + (b.x2 || '')).trim().split(/\s+/).filter(Boolean).length; });
    s.appendChild(el('div', 'side-item', '<small>' + cur.blocks.filter(function (b) { return b.t === 'scene'; }).length + ' scenes · ' + words + ' words · ' + (cur.blocks.filter(function (b) { return b.pb; }).length + 1) + '+ pages</small>'));
    var n = 0;
    cur.blocks.forEach(function (b) {
      if (sideTab === 'scenes' && b.t === 'scene') { n++; var it = el('div', 'side-item', '<b>' + n + '</b><span>' + esc(((b.x || '') + ' ' + (b.x2 || '')).trim() || '(empty scene)') + '</span>'); it.onclick = function () { focusBlock(b.id, null); sideClosesOnPhone(); }; s.appendChild(it); }
      if (sideTab === 'marks' && b.mk) { var im = el('div', 'side-item', '<i class="dot" style="background:' + b.mk + '"></i><span>' + esc((b.x || '').slice(0, 60) || '(empty)') + '</span><small>' + LAB[b.t] + '</small>'); im.onclick = function () { focusBlock(b.id, null); sideClosesOnPhone(); }; s.appendChild(im); }
    });
    if (s.children.length < 3) s.appendChild(el('div', 'side-item', '<small>' + (sideTab === 'scenes' ? 'No scene headings yet.' : 'No marked lines. Use Marker.') + '</small>'));
  }

  /* ------------------------------------------------------------------ find & replace */
  function findDlg() {
    var b = el('div', ''), f = el('input', 't'), r = el('input', 't'); f.placeholder = 'Find'; r.placeholder = 'Replace with'; r.style.marginTop = '8px'; b.appendChild(f); b.appendChild(r);
    var pos = { i: cb ? idxOf(cb.id) : 0, off: 0 }, info = el('p', '', ''); b.appendChild(info);
    function all() { var res = []; var q = f.value.toLowerCase(); if (!q) return res; cur.blocks.forEach(function (bl, i) { ['x', 'x2'].forEach(function (fl) { var t = (bl[fl] || '').toLowerCase(), k = -1; while ((k = t.indexOf(q, k + 1)) >= 0) res.push([i, fl, k]); }); }); return res; }
    function next() {
      var a = all(); info.textContent = a.length + ' match(es)'; if (!a.length) return;
      var hit = a.filter(function (m) { return m[0] > pos.i || (m[0] === pos.i && m[2] >= pos.off); })[0] || a[0]; pos.i = hit[0]; pos.off = hit[2] + 1;
      var w = blockEl(cur.blocks[hit[0]].id), e = $('.ed[data-f=' + hit[1] + ']', w); e.focus(); setCaret(e, hit[2], hit[2] + f.value.length); keepVisible(e);
    }
    dlg('Find & replace', b, [{ l: 'Replace all', fn: function () { var q = f.value; if (!q) return false; snap(); var c = 0; var re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'); cur.blocks.forEach(function (bl) { ['x', 'x2'].forEach(function (fl) { if (bl[fl]) { var o = bl[fl]; bl[fl] = o.replace(re, function () { c++; return r.value; }); if (bl[fl] !== o) setFm(bl, fl, []); } }); }); renderAll(); snap(); dirty(); toast(c + ' replaced'); } }, { l: 'Find next', cls: 'pri', fn: function () { next(); return false; } }, { l: 'Close' }], { nofocus: false });
    f.addEventListener('keydown', function (e) { if (e.key === 'Enter') { next(); } });
  }

  /* ------------------------------------------------------------------ save / save as / files */
  function wrapFile() { return JSON.stringify({ app: 'finnish', v: 2, docs: [Object.assign({}, cur, { path: undefined })] }); }
  function fname() { return (cur.title || 'Untitled').replace(/[\\\/:*?"<>|\n]+/g, ' ').trim() || 'Untitled'; }
  function save() {
    persist().then(function () {
      if (isPhone() || (!N && !window.showSaveFilePicker)) return toast('Saved on this device ✓ (see “Saved” tab)');
      return saveFile(false);
    });
  }
  function saveAs() {
    if (isPhone()) { return ask('Save As', 'New name', fname(), function (n) { if (!n) return; var c = JSON.parse(JSON.stringify(cur)); c.id = uid(); c.title = n; cur = c; cb = null; persist().then(function () { renderAll(); toast('Saved as “' + n + '” – find it under Saved'); }); }, 'Save'); }
    persist().then(function () { saveFile(true); });
  }
  function saveFile(as) {
    var json = wrapFile();
    if (N && N.saveFile) return N.saveFile(fname() + '.finnish', json, as ? null : cur.path).then(function (p) { if (p) { cur.path = p; toast('Saved to ' + p); } });
    if (window.showSaveFilePicker) {
      var h = handles[cur.id], pr = (!as && h) ? Promise.resolve(h) : showSaveFilePicker({ suggestedName: fname() + '.finnish', types: [{ description: 'finnish script', accept: { 'application/json': ['.finnish'] } }] });
      return pr.then(function (hh) { handles[cur.id] = hh; return hh.createWritable().then(function (w) { return w.write(json).then(function () { return w.close(); }); }).then(function () { toast('Saved to ' + hh.name + ' ✓'); }); }).catch(function (e) { if (e && e.name !== 'AbortError') toast('Could not save file'); });
    }
    return deliver(fname() + '.finnish', 'application/json', json);
  }
  function deliver(name, mime, text) {
    if (N && N.saveText) return N.saveText(name, text);
    var FP = THK.fp();
    if (FP) return FP.saveFile({ name: name, mime: 'application/octet-stream', data: text }).then(function () { toast('Saved ✓ ' + name); }).catch(function (e) { if (!e || !/cancel/i.test(String(e.message || e))) toast('Could not save: ' + (e && e.message || e)); });
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: mime + ';charset=utf-8' })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); URL.revokeObjectURL(a.href); }, 1000); toast('Downloaded ' + name);
  }
  function deliverBin(name, mime, u8) { // binary files (e.g. Word)
    var b64 = ''; for (var i = 0; i < u8.length; i += 0x8000) b64 += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); b64 = btoa(b64);
    if (N && N.saveText) return N.saveText(name, b64, true);
    var FP = THK.fp();
    if (FP) return FP.saveFile({ name: name, mime: mime, data: b64, b64: true }).then(function () { toast('Saved ✓ ' + name); }).catch(function (e) { if (!e || !/cancel/i.test(String(e.message || e))) toast('Could not save: ' + (e && e.message || e)); });
    var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([u8], { type: mime })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { a.remove(); URL.revokeObjectURL(a.href); }, 1000); toast('Saved ✓ ' + name);
  }
  function exportDlg() {
    var b = el('div', ''); b.innerHTML = '<label style="display:flex;gap:8px;align-items:center;margin-bottom:8px"><input type="checkbox" id="xc" checked> Include cover page</label><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="xm"> Print marker colours</label><p>The export date on the cover is filled in automatically if you left it empty. The middle line of Two Column is never printed.</p>';
    var d = dlg('Export', b, [{ l: 'Close' }, { l: 'Word (.docx)', fn: function () { syncOut(); try { deliverBin(fname() + '.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', THK.x.docx(cur, { cover: $('#xc', d).checked })); } catch (e) { toast('Word export failed: ' + e.message); } } }, { l: 'E-book (.epub)', fn: function () { syncOut(); try { deliverBin(fname() + '.epub', 'application/epub+zip', THK.x.epub(cur, {})); } catch (e) { toast('E-book export failed: ' + e.message); } } }, { l: 'FDX (Final Draft)', fn: function () { syncOut(); deliver(fname() + '.fdx', 'application/xml', THK.toFDX(cur)); } }, { l: 'Fountain', fn: function () { syncOut(); deliver(fname() + '.fountain', 'text/plain', THK.toFountain(cur, true)); } }, { l: 'Backup (.finnish)', fn: function () { deliver(fname() + '.finnish', 'application/json', wrapFile()); } },
      { l: 'Presentation PDF', fn: function () { syncOut(); setTimeout(function () { persist(); THK.pro.present(); }, 60); } }, { l: 'PDF', cls: 'pri', fn: function () { var o = { cover: $('#xc', d).checked, marks: $('#xm', d).checked }; setTimeout(function () { persist(); THK.printScript(cur, o); }, 60); } }]);
  }
  function syncOut() { cur.author = cur.writer; }

  /* ------------------------------------------------------------------ import */
  function pickImport() {
    if (window.showOpenFilePicker && !isPhone()) {
      showOpenFilePicker({ multiple: false, types: [{ description: 'Scripts', accept: { 'text/plain': ['.docx', '.fdx', '.screenplay', '.fountain', '.txt', '.finnish', '.json', '.pdf'] } }] }).then(function (hs) { return hs[0].getFile().then(function (f) { importFile(f, hs[0]); }); }).catch(function () { });
      return;
    }
    var i = $('#fileIn'); i.value = ''; i.onchange = function () { if (i.files[0]) importFile(i.files[0]); }; i.click();
  }
  function importFile(f, handle) {
    var name = f.name, ext = (name.split('.').pop() || '').toLowerCase();
    if (ext === 'pdf') { toast('Reading PDF…'); return f.arrayBuffer().then(function (ab) { return THK.parsePdf(ab, name); }).then(function (d) { return THK.pdfReview(d).then(function (ok) { if (ok) finishImport([d], name, handle); }); }).catch(function (e) { dlg('Could not read this PDF', '<p>' + esc((e && e.message) || 'Unknown error') + '</p><p>PDFs made by finnish, Final Draft, Word, Scriptty, Fountain tools and most screenplay apps contain real text and open here. Scanned PDFs (photos of pages) cannot be read. In that case export from the original app as .fdx, .docx or Fountain and open that.</p>', [{ l: 'Close', cls: 'pri' }]); }); }
    if (ext === 'docx' || ext === 'dotx') { toast('Reading Word file…'); return f.arrayBuffer().then(function (ab) { return THK.parseDocx(ab, name); }).then(function (d) { finishImport([d], name, handle); }).catch(function (e) { dlg('Could not open Word file', '<p>' + esc(e.message || 'Unknown error') + '</p><p>Old .doc files are not supported – in Word use Save As ▸ .docx.</p>', [{ l: 'Close', cls: 'pri' }]); }); }
    var rd = new FileReader(); rd.onerror = function () { toast('Could not read file'); };
    rd.onload = function () {
      var text = String(rd.result), docs;
      try {
        if (ext === 'fdx' || THK.isFDX(text)) docs = [THK.parseFDX(text)];
        else if (/^\s*[\[{]/.test(text)) { var o = JSON.parse(text); if (o && o.app === 'finnish') { docs = o.docs; if (handle && docs.length === 1) { docs[0]._h = handle; } } else if (THK.isScriptty(o) || ext === 'screenplay') docs = THK.parseScriptty(o); else throw new Error('Unknown JSON file'); }
        else { var d = norm({ title: name.replace(/\.[^.]+$/, ''), blocks: THK.parseFountain(text) }); if (!d.blocks.length) throw new Error('Empty'); docs = [d]; }
      } catch (e) { return dlg('Could not open file', '<p>' + esc(e.message || 'Unknown file') + '</p><p>Supported: PDF, Word .docx, Final Draft .fdx, Scriptty .screenplay, Fountain / text, and finnish .finnish. If a Scriptty file will not open, export it from Scriptty as Fountain or FDX and open that.</p>', [{ l: 'OK', cls: 'pri' }]); }
      finishImport(docs, name, handle);
    };
    rd.readAsText(f);
  }
  function finishImport(docs, name, handle) {
    {
      var isNative = docs[0].app === undefined && !(docs[0].fmt);
      var go = function (fmt) {
        docs = docs.map(function (d) { var h = d._h; delete d._h; if (!d.fmt || isNative) d.fmt = fmt; if (!d.paper) d.paper = 'a4'; d = norm(d); if (h) handles[d.id] = h; return d; });
        Promise.all(docs.map(function (d) { return DB.put(d); })).then(function () { toast(docs.length > 1 ? docs.length + ' scripts imported – see Saved' : 'Imported ✓'); openDoc(docs[0]); });
      };
      if (isNative) dlg('Open as…', '<p>“' + esc(docs[0].title || name) + '” – ' + docs.reduce(function (n, d) { return n + d.blocks.length; }, 0) + ' lines. Which layout do you want?</p>', [{ l: 'Standard', cls: 'pri', fn: function () { go('std'); } }, { l: 'Two Column', cls: 'pri', fn: function () { go('two'); } }]); else go('std');
    }
  }

  /* ------------------------------------------------------------------ dialogs: help, about, palette */
  function about() {
    dlg('', '<div class="about"><div class="wm" role="img" aria-label="finnish" style="width:190px"></div><p class="ab-tag">Mobile screenplay writer</p><p class="ab-by"><span>Creator</span>Nishan</p><p class="ab-mail"><a href="mailto:mailstonishan@gmail.com">mailstonishan@gmail.com</a></p><p class="ab-v">Version ' + VERSION + '</p></div>', [{ l: 'Close', cls: 'pri' }]);
  }
  function helpDlg() {
    if (mob()) { dlg('Help', '<p><b>Enter</b> starts a new line and the type follows the flow: scene, action, character, dialogue.<br>Use the buttons above the keyboard to change the type of a line, and the language button at the bottom right to change the writing language.<br><b>Format</b> in the top bar gives bold, italic, underline, size and colour.<br><b>More</b> holds save, export, import, find, outline, backup and the rest.</p><p>Other languages: pick one with the language button (by country), then use that language’s keyboard on your phone. Indian languages can also be typed in English letters with phonetic typing on. Or tap <b>Speak</b> to dictate.</p><p>Two Column: the scene heading has two boxes (place and time). Transition is centred and bold.</p>', [{ l: 'Close', cls: 'pri' }]); return; }
    dlg('Help & shortcuts', '<p><b>Enter</b> new line (type follows the flow: scene → action → character → dialogue)<br><b>Tab / Shift+Tab</b> change element · <b>Shift+Enter</b> line break<br><b>Ctrl+Enter</b> next page · <b>Ctrl+S</b> save · <b>Ctrl+Shift+S</b> save as<br><b>Ctrl+Space</b> Malayalam / English typing · <b>Ctrl+K</b> command palette<br><b>Ctrl+↑/↓</b> jump scene · <b>Ctrl+F</b> find &amp; replace</p><p>Phonetic typing (Indian languages): type <i>“namaskaaram”</i> and it becomes Malayalam.</p><p>Two Column: scene heading has two boxes (place | time) and may cross the middle line; Enter in the left box jumps to the right one. Transition is centred and bold. The line is never printed.</p>', [{ l: 'Close', cls: 'pri' }]);
  }
  function palette() {
    var cmds = [['Next page', nextPage], ['Save', save], ['Save As…', saveAs], ['Export…', exportDlg], ['Import file…', pickImport], ['Page & text colour…', colourDlg], ['Reverse colours', reverseColours], ['Find & replace…', findDlg], ['Scenes & markers panel', function () { toggleSide(); }], ['Switch layout (Standard / Two Column)', switchFmt], ['Undo', undo], ['Redo', redo], ['Help', helpDlg], ['About', about], ['Home', goHome]];
    if (window.THK && THK.x && THK.x.cmds) cmds = cmds.concat(THK.x.cmds().filter(function (c) { return !(mob() && c[0] === 'Quick phrases'); }));
    if (window.THK && THK.pro && THK.pro.cmds) cmds = cmds.concat(THK.pro.cmds());
    var b = el('div', ''), i = el('input', 't'), l = el('div', 'saved-list'); i.placeholder = 'Type a command…'; b.appendChild(i); l.style.marginTop = '8px'; b.appendChild(l);
    var d = dlg('', b, null);
    function draw() { l.innerHTML = ''; cmds.filter(function (c) { return c[0].toLowerCase().indexOf(i.value.toLowerCase()) >= 0; }).forEach(function (c) { var r = el('div', 'sv', esc(clean(c[0]))); r.onclick = function () { d.close(); c[1](); }; l.appendChild(r); }); }
    i.oninput = draw; i.onkeydown = function (e) { if (e.key === 'Enter') { var r = $('.sv', l); if (r) r.click(); } }; draw();
  }

  /* ------------------------------------------------------------------ open / navigation */
  /* ------------------------------------------------------------------ back (swipe / system back) */
  function clickIn(root, text) { var b = $$('button', root).filter(function (x) { return x.textContent.trim() === text; }).pop(); if (b) { b.click(); return true; } return false; }
  function goBack() {
    if ($('#lock')) return true;
    var m = $$('.menuscrim').pop(); if (m) { m.dispatchEvent(new Event('pointerdown')); return true; }
    var sc = $$('#layer .scrim').pop(); if (sc) { sc.dispatchEvent(new Event('mousedown')); return true; }
    var o;
    if ((o = $('#srch'))) { clickIn(o, 'Close'); return true; }
    if ((o = $('#gc'))) { if ($('.gplay', o)) { var hb = $('.hud button', o); if (hb) hb.click(); } else clickIn(o, 'Close'); return true; }
    if ((o = $('#cine'))) { clickIn(o, 'Close'); return true; }
    if ((o = $('#ol'))) { clickIn(o, 'Done'); return true; }
    if ((o = $('#rdbar')) && o.style.display !== 'none' && getComputedStyle(o).display !== 'none') { clickIn(o, 'Exit reading'); return true; }
    if (document.documentElement.classList.contains('focus')) { var fx = $('#fxExit'); if (fx) fx.click(); return true; }
    var sd = $('#side'); if (sd && !sd.hidden && cur) { toggleSide(false); return true; }
    var scr = document.documentElement.dataset.scr;
    if (scr === 'app' && cur) { goHome(); return true; }
    if (scr === 'wiz') { renderHome(); return true; }
    if (scr === 'home' && homeTab !== 'start') { homeTab = 'start'; renderHome(); return true; }
    return false;
  }
  var exitArm = 0;
  function exitFlow() {
    var fp = THK.fp && THK.fp();
    if (fp && fp.exitApp) { if (Date.now() - exitArm < 2200) { fp.exitApp(); } else { exitArm = Date.now(); toast('Swipe back again to exit'); } return true; }
    return false;
  }
  /* called by the native Android back callback (system swipe from either edge / back button) */
  function backNative() { try { if (goBack()) return true; return exitFlow(); } catch (e) { return false; } }
  THK.backNative = backNative;
  function initBack() {
    try { history.replaceState({ f: 0 }, ''); history.pushState({ f: 1 }, ''); } catch (e) { }
    window.addEventListener('popstate', function () {
      if (goBack()) { try { history.pushState({ f: 1 }, ''); } catch (e) { } return; }
      if (exitFlow()) { try { history.pushState({ f: 1 }, ''); } catch (e) { } }
    });
    /* in-app edge swipe from the LEFT or the RIGHT edge, with a glass hint that follows the finger */
    var hl = el('div', 'swb'), hr = el('div', 'swb r'); document.body.appendChild(hl); document.body.appendChild(hr);
    var sx = 0, sy = 0, side = 0, dx = 0, hint = null, EDGE = 30, GO = 64;
    function reset() { side = 0; dx = 0; [hl, hr].forEach(function (h) { h.style.opacity = 0; h.style.transform = ''; h.classList.remove('go'); }); }
    function blocked(t) { /* let horizontally scrolling strips and sliders keep their own swipe */
      var n = t; while (n && n !== document.body) { if (n.nodeType === 1 && (n.dataset && n.dataset.noswipe != null || (n.tagName === 'INPUT' && n.type === 'range'))) return true; n = n.parentNode; } return false;
    }
    document.addEventListener('touchstart', function (e) {
      reset(); if (e.touches.length !== 1) return; var t = e.touches[0];
      if (blocked(e.target)) return;
      if (t.clientX < EDGE) side = 1; else if (t.clientX > innerWidth - EDGE) side = -1; else return;
      sx = t.clientX; sy = t.clientY; hint = side === 1 ? hl : hr; hint.style.top = Math.max(60, Math.min(innerHeight - 160, t.clientY - 60)) + 'px';
    }, { passive: true });
    document.addEventListener('touchmove', function (e) {
      if (!side) return; var t = e.touches[0]; dx = (t.clientX - sx) * side;
      if (Math.abs(t.clientY - sy) > 80 && dx < 40) { reset(); return; }
      var p = Math.max(0, Math.min(dx, 110)); hint.style.opacity = Math.min(1, p / 40); hint.style.transform = 'translateX(' + (side * (p * 0.5 - 30)) + 'px)'; hint.classList.toggle('go', dx > GO);
    }, { passive: true });
    document.addEventListener('touchend', function () { var go = side && dx > GO; reset(); if (go) goBack() || exitFlow(); }, { passive: true });
    document.addEventListener('touchcancel', reset, { passive: true });
  }
  function openDoc(d, fresh) {
    persistSafe(); cur = norm(d); cb = null; lastSel = null; hist = { st: [], re: [], t: 0 }; tl.buf = ''; S.lang = cur.lang; S.ml = !!THK.lang(cur.lang).translit; THK.loadFont(cur.font); if (cur.titleFont) THK.loadFont(cur.titleFont);
    if (window.THK && THK.pro) THK.pro.opened(cur); show('app'); buildChrome(); renderAll(); snap(); setStatus('saved'); if (fresh) persist();
    S.lastId = cur.id; saveS(); $('#scroll').scrollTop = 0; if (window.THK && THK.x && THK.x.opened) THK.x.opened(cur);
    setTimeout(function () { if (!cur) return; try { if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); } catch (e) { } if (cur.blocks[0]) setCur(cur.blocks[0].id); $('#scroll').scrollTop = fresh ? $('#cover').offsetHeight : 0; }, 80);
  }
  function persistSafe() { if (cur) { try { persist(); } catch (e) { } } }
  function goHome() { persistSafe(); cur = null; cb = null; lastSel = null; homeTab = 'start'; renderHome(); }

  /* ------------------------------------------------------------------ boot */
  var EXTRA_CSS = '#page.std .b.char,#page.std .b.paren{margin-left:15%;margin-right:15%;text-align:center}#page.std .b.dial{margin-left:16%;margin-right:16%}#page.two .b.action,#page.two .b.shot,#page.two .b.scene,#page.two .b.trans,#page.two .b.note{clear:both}#page.two .b.char{float:left;clear:both;width:50%;margin:0 0 .7em 0;padding-right:.35em;text-align:right}#page.two .b.char .ed::after{content:" :"}#page.two .b.paren,#page.two .b.dial{margin-left:calc(50% + .8em);margin-right:0;text-align:left;clear:none}';
  function bind() {
    var st = document.createElement('style'); st.textContent = THK.fontFaceCSS('') + EXTRA_CSS; document.head.appendChild(st);
    document.addEventListener('pointerdown', function (e) { var s = $('#side'); if (s && !s.hidden && !e.target.closest('#side') && !e.target.closest('[data-side]') && !e.target.closest('.menu') && !e.target.closest('.dlg')) toggleSide(false); }, true);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { var s = $('#side'); if (s && !s.hidden) toggleSide(false); } });
    var pg = $('#page'), cv = $('#cover');
    [pg, cv].forEach(function (r) { r.addEventListener('keydown', onKey); r.addEventListener('input', onInput); r.addEventListener('paste', onPaste); r.addEventListener('focusin', onFocus); r.addEventListener('mousedown', function () { tl.buf = ''; }); });
    [pg, cv].forEach(function (r) { var f = function (ev) { var ed = ev.target.closest && ev.target.closest('.ed'); if (window.THK && THK.x && THK.x.caret) THK.x.caret(ed); }; r.addEventListener('keyup', f); r.addEventListener('input', f); r.addEventListener('focusin', f); });
    pg.addEventListener('click', function (e) { if (e.target === pg && cur) { var l = cur.blocks[cur.blocks.length - 1]; focusBlock(l.id, null); } });
    (function () { var ap = $('#app'), vv = window.visualViewport;
      var fit = function () { if (vv) { ap.style.height = vv.height + 'px'; ap.style.top = (vv.offsetTop || 0) + 'px'; ap.style.bottom = 'auto'; } window.scrollTo(0, 0); if (ap.scrollTop) ap.scrollTop = 0; if (ap.scrollLeft) ap.scrollLeft = 0; document.documentElement.scrollTop = 0; document.body.scrollTop = 0; };
      if (vv) { vv.addEventListener('resize', fit); vv.addEventListener('scroll', fit); }
      window.addEventListener('scroll', fit); window.addEventListener('resize', fit); ap.addEventListener('scroll', fit);
      document.addEventListener('focusin', function () { setTimeout(fit, 0); setTimeout(fit, 250); }); fit(); })();
    document.addEventListener('keydown', function (e) { if (cur && (e.ctrlKey || e.metaKey) && !e.target.closest('.ed') && /^[sk]$/i.test(e.key)) { e.preventDefault(); e.key.toLowerCase() === 's' ? save() : palette(); } });
    if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener && matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);
    document.addEventListener('dragover', function (e) { e.preventDefault(); }); document.addEventListener('drop', function (e) { e.preventDefault(); if (e.dataTransfer.files[0]) importFile(e.dataTransfer.files[0]); });
  }
  function checkPending() { // a file opened from another app ("Open with finnish")
    var FP = THK.fp(); if (!FP || !FP.getPending) return;
    FP.getPending({}).then(function (r) { if (r && r.text) { try { importFile(new File([r.text], r.name || 'script.finnish')); } catch (e) { toast('Could not open file'); } } }).catch(function () { });
  }
  function boot() {
    try { initBack(); } catch (e) { }
    applyTheme(); applyWall(); bind();
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(function () { });
    if ('serviceWorker' in navigator && /^https?:/.test(location.protocol)) navigator.serviceWorker.register('sw.js').catch(function () { });
    var t0 = Date.now();
    DB.init().then(function () {
      var rec = null; try { rec = JSON.parse(localStorage.getItem('finnish.recover') || 'null'); } catch (e) { }
      return DB.all().then(function (ds) {
        if (rec && rec.id) { var saved = ds.filter(function (d) { return d.id === rec.id; })[0]; if (!saved || saved.updated < rec.updated) { return DB.put(rec).then(function () { toast('Recovered unsaved work ✓'); }); } }
      });
    }).then(function () {
      setTimeout(function () { renderHome(); checkPending(); if (window.THK && THK.pro) THK.pro.boot(); $('#splash').classList.add('out'); setTimeout(function () { $('#splash').remove(); }, 800); }, Math.max(0, 2400 - (Date.now() - t0)));
    });
  }
  THK.app = { $: $, $$: $$, el: el, esc: esc, dlg: dlg, menu: menu, toast: toast, btn: btn, S: S, saveS: saveS, dirty: dirty, snap: snap, renderAll: renderAll, applyLook: applyLook, applyTheme: applyTheme, focusBlock: focusBlock, setCaret: setCaret, getCaret: getCaret,
    blockEl: blockEl, setType: setType, refreshSide: refreshSide, persist: persist, openDoc: openDoc, goHome: goHome, uid: uid, readRich: readRich, drawRich: drawRich, tl: tl, PT: PT, ORDER: ORDER, LAB: LAB, PH: PH, NEXT: NEXT, confirmD: confirmD, show: show, langMenu: langMenu, trFn: trFn, ask: ask,  applyTrans: applyTrans,  isPhone: isPhone, fname: fname, themeDlg: themeDlg, idxOf: function (id) { return idxOf(id); }, DB: DB, deliver: deliver, deliverBin: deliverBin, DB: DB, pickImport: pickImport, importFile: importFile, norm: norm, newDoc: newDoc, renderHome: renderHome, get cb() { return cb; }, refreshRibbon: refreshRibbon, get cur() { return cur; }, toastIn: toast, pop: pop, menu: menu, upgradeSelect: upgradeSelect, clean: clean };
  THK._checkPending = checkPending;
  THK._t = { norm: norm, newDoc: newDoc, get cur() { return cur; } };
  boot();
})();
