/* finnish extras: focus mode, typewriter scrolling, quick phrases, outline cards, accent colour, paper sizes, watermark/header,
   cover styles, version history, app lock, reading mode + read aloud, Word export, customise sheet. */
(function () {
  var THK = window.THK, A = THK.app, $ = A.$, $$ = A.$$, el = A.el, esc = A.esc, S = A.S, toast = A.toast, dlg = A.dlg, btn = A.btn, X = THK.x = {};
  function cur() { return A.cur; }
  function root() { return document.documentElement; }
  function pill(label, on, fn, cls) { var b = el('button', 'btn' + (on ? ' on' : '') + (cls ? ' ' + cls : ''), A.clean(label)); b.onclick = fn; return b; }
  function rowOf(parent) { var r = el('div', 'xrow'); parent.appendChild(r); return r; }
  function head(parent, t, sub) { var h = el('div', 'xhd', esc(t)); parent.appendChild(h); if (sub) { var p = el('div', 'xsub', esc(sub)); parent.appendChild(p); } }

  /* ============================================================ CSS */
  var css = '' +
    '.xrow{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:6px 0}.xhd{font-weight:700;margin:14px 0 4px;text-align:center}.xsub{font-size:12.5px;opacity:.75;text-align:center;margin-bottom:6px}' +
    '.xrow .btn{display:inline-flex;align-items:center;gap:8px}.xrow .dot{width:16px;height:16px;border-radius:50%;border:1px solid rgba(255,255,255,.55)}' +
    '.xin{width:100%;box-sizing:border-box;padding:10px 14px;border-radius:16px;border:1px solid var(--edge);background:var(--glass);color:var(--ink);font:inherit;margin:4px 0}textarea.xin{min-height:170px;resize:vertical;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px}' +
    /* focus + typewriter */
    'html.focus #top,html.focus #ribbon,html.focus #dock,html.focus #acc,html.focus #side{display:none!important}' +
    'html.focus.fdim #page .b:not(.cur){opacity:.4;transition:opacity .25s}html.focus #page .b{transition:opacity .25s}' +
    'html.focus #cover .edh,html.focus #page .b::before{opacity:0}' +
    '#fxExit{position:fixed;top:calc(max(8px,env(safe-area-inset-top)) + 8px);right:14px;z-index:60;display:none;background:rgba(20,18,40,.82)!important;color:#fff!important;border:1px solid rgba(255,255,255,.35)!important;-webkit-backdrop-filter:blur(16px);backdrop-filter:blur(16px);box-shadow:0 6px 20px rgba(0,0,0,.3)}html.focus #fxExit{display:inline-flex}' +
    'html.focus #page,#app.tw #page{padding-bottom:46vh}html.focus #app{padding-top:0}' +
    /* outline */
    '#ol{position:fixed;inset:0;padding-top:calc(max(8px,env(safe-area-inset-top)) + 6px);z-index:70;display:flex;flex-direction:column;background:rgba(10,10,24,.55);-webkit-backdrop-filter:blur(26px);backdrop-filter:blur(26px);color:#fff}' +
    '#ol .oh{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:14px 16px;flex-wrap:wrap}#ol .oh b{font-size:19px}#ol .og{flex:1;overflow:auto;padding:4px 16px 90px;display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:14px;align-content:start}' +
    '#ol .oc{position:relative;border-radius:30px;padding:16px 18px 14px;border:1px solid rgba(255,255,255,.34);background:radial-gradient(120% 62% at 50% -8%,rgba(255,255,255,.3),transparent 58%),linear-gradient(165deg,rgba(60,52,120,.55),rgba(24,20,70,.7));box-shadow:inset 0 1.5px 1px rgba(255,255,255,.55),0 16px 36px rgba(0,0,0,.35);-webkit-user-select:none;user-select:none;touch-action:pan-y;transition:transform .15s}' +
    '#ol .oc.drag{transform:scale(1.04) rotate(-1deg);z-index:3;outline:2px solid var(--acc)}#ol .on{font-size:12px;letter-spacing:.1em;opacity:.7}#ol .ot{font-weight:700;margin:4px 0 6px;line-height:1.3;word-break:break-word}#ol .op{font-size:13px;opacity:.78;line-height:1.35;max-height:3.9em;overflow:hidden}' +
    '#ol .om{display:flex;gap:6px;margin-top:10px;align-items:center;flex-wrap:wrap}#ol .om small{opacity:.7;margin-right:auto}#ol .btn{color:#fff!important;background:rgba(255,255,255,.14)!important;border:1px solid rgba(255,255,255,.34)!important;padding:6px 12px;font-size:13px}#ol .btn.pri{background:var(--grad)!important}' +
    '#ol .hint{padding:0 16px 8px;font-size:12.5px;opacity:.75}' +
    /* reading bar */
    '#rdbar{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(max(10px,env(safe-area-inset-bottom)) + 8px);z-index:60;display:none;gap:8px;align-items:center;flex-wrap:wrap;justify-content:center;padding:9px 12px;border-radius:30px;background:rgba(20,18,40,.72);border:1px solid rgba(255,255,255,.3);-webkit-backdrop-filter:blur(22px);backdrop-filter:blur(22px);max-width:94vw}' +
    'html.reading #rdbar{display:flex}#rdbar .btn{color:#fff!important;background:rgba(255,255,255,.14)!important;border:1px solid rgba(255,255,255,.3)!important;padding:7px 14px}#rdbar .btn.pri{background:var(--grad)!important}' +
    'html.reading #top,html.reading #ribbon,html.reading #dock,html.reading #acc,html.reading #side{display:none!important}' +
    'html.reading #page .b::before,html.reading #cover .edh{display:none!important}html.reading .ed{caret-color:transparent;cursor:default}html.reading #page{padding-bottom:30vh}' +
    '#page .b.speaking{background:rgba(255,200,60,.22);border-radius:10px;box-shadow:0 0 0 6px rgba(255,200,60,.22)}' +
    /* lock */
    '#lock{position:fixed;inset:0;z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px;background:#000;color:#fff;padding:24px;text-align:center}' +
    '#lock .wm{width:min(70vw,300px);background:#fff!important}#lock input{width:min(80vw,320px);padding:13px 18px;border-radius:26px;border:1px solid rgba(255,255,255,.4);background:rgba(255,255,255,.1);color:#fff;font:inherit;font-size:17px;text-align:center;outline:none}' +
    '#lock .btn{color:#fff!important;background:rgba(255,255,255,.14)!important;border:1px solid rgba(255,255,255,.34)!important}#lock .btn.pri{background:var(--grad)!important}#lock .msg{min-height:1.4em;font-size:14px;opacity:.85}#lock.shake input{animation:shk .35s}' +
    '@keyframes shk{20%{transform:translateX(-9px)}40%{transform:translateX(9px)}60%{transform:translateX(-6px)}80%{transform:translateX(6px)}}' +
    /* watermark in editor, cover styles */
    '#wmk{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;pointer-events:none;overflow:hidden;z-index:0}#wmk span{transform:rotate(-35deg);font:700 clamp(38px,10vw,96px) Arial,sans-serif;color:rgba(128,128,128,.16);white-space:nowrap}' +
    '#sheet{position:relative}#cover,#page{position:relative;z-index:1}' +
    '#cover .clogo{display:block;max-width:230px;max-height:150px;object-fit:contain;margin:0 auto 18px;pointer-events:none}' +
    '#cover.cv-left{text-align:left}#cover.cv-left .clogo{margin-left:0}#cover.cv-left .cl{justify-content:flex-start}' +
    '#cover.cv-bold .ct{text-transform:uppercase;letter-spacing:.05em;border-bottom:3px solid currentColor;padding-bottom:12px}' +
    '#cover.cv-minimal{text-align:left}#cover.cv-minimal .ct{font-size:1.5em}#cover.cv-minimal .clogo{margin-left:0}' +
    '#cover.cv-framed{outline:1.5px solid currentColor;outline-offset:-22px}#cover.cv-framed .ct{border-bottom:1px solid currentColor;padding-bottom:10px}' +
    'html.accent-on .btn.pri,html.accent-on .btn.on{color:var(--onacc,#fff)!important}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  /* ============================================================ focus mode + typewriter scrolling */
  function isFocus() { return root().classList.contains('focus'); }
  function applyTw() { var a = $('#app'); if (a) a.classList.toggle('tw', !!S.tw); root().classList.toggle('fdim', S.fdim !== false); }
  X.focus = function (on) {
    if (on === undefined) on = !isFocus(); if (on && !cur()) return;
    root().classList.toggle('focus', !!on); applyTw();
    if (on) { toast(A.isPhone() ? 'Focus mode – tap “Exit focus” to return' : 'Focus mode – press Esc or tap “Exit focus” to return'); var e = document.activeElement; setTimeout(function () { X.caret(e && e.closest && e.closest('.ed')); }, 120); }
  };
  var fx = btn('Exit focus', function () { X.focus(false); }, 'sm'); fx.id = 'fxExit'; document.body.appendChild(fx);
  var twRaf = 0;
  X.caret = function (e) {
    if (!e || !(S.tw || isFocus()) || !e.closest('#page')) return;
    cancelAnimationFrame(twRaf); twRaf = requestAnimationFrame(function () {
      var sc = $('#scroll'), s = getSelection(); if (!s.rangeCount) return; var r = s.getRangeAt(0).cloneRange(); r.collapse(false);
      var rc = r.getClientRects()[0] || e.getBoundingClientRect(), sr = sc.getBoundingClientRect(), d = rc.top - (sr.top + sc.clientHeight * 0.4);
      if (Math.abs(d) > 6) sc.scrollTop += d;
    });
  };
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') { if (isFocus()) X.focus(false); else if (root().classList.contains('reading')) X.reading(false); }
    else if ((ev.ctrlKey || ev.metaKey) && ev.shiftKey && ev.key.toLowerCase() === 'd') { ev.preventDefault(); X.focus(); }
  });

  /* ============================================================ quick phrases */
  var DEF = { sc: 'INT. ___ – DAY', se: 'EXT. ___ – DAY', sn: 'INT. ___ – NIGHT', sen: 'EXT. ___ – NIGHT', ct: 'CUT TO:', fi: 'FADE IN:', fo: 'FADE OUT.', dt: 'DISSOLVE TO:' };
  function snips() { return S.snips && Object.keys(S.snips).length ? S.snips : DEF; }
  X.snippet = function (e, b) {
    var pos = A.getCaret(e), tl = A.tl, map = snips(), code, start;
    if (S.ml && tl.buf && tl.el === e && tl.pos === pos) { code = tl.buf; start = pos - tl.len; }
    else { var m = A.readRich(e).x.slice(0, pos).match(/(\S+)$/); if (!m) return false; code = m[1]; start = pos - code.length; }
    var key = Object.keys(map).filter(function (k) { return k.toLowerCase() === code.toLowerCase(); })[0]; if (!key) return false;
    var text = map[key]; A.setCaret(e, start, pos); document.execCommand('insertText', false, text); tl.buf = ''; tl.len = 0;
    var c = cur(), blk = c.blocks.filter(function (x) { return x.id === b.id; })[0] || b, whole = (blk.x || '').trim() === text.trim();
    var type = whole ? (/^(INT|EXT|I\/E|INT\.?\/EXT)/i.test(text) ? 'scene' : (/(TO:|FADE (IN|OUT)[:.]?)\s*$/i.test(text) && text.length < 30 ? 'trans' : null)) : null;
    if (type && blk.t !== type) A.setType(blk, type);
    setTimeout(function () { var e2 = A.blockEl(blk.id); e2 = e2 && $('.ed[data-f="x"]', e2); if (!e2) return; e2.focus(); var i = (blk.x || '').indexOf('___'); if (i >= 0) A.setCaret(e2, i, i + 3); else A.setCaret(e2, 1e6); }, 30);
    return true;
  };
  X.snipsDlg = function () {
    var b = el('div', ''), map = snips(), lines = Object.keys(map).map(function (k) { return k + ' = ' + map[k]; }).join('\n');
    b.appendChild(el('p', '', 'Type the short code, then press <b>Tab</b> – it turns into the full phrase. In Malayalam typing mode the code is matched in English letters, so it works there too. One per line: <code>code = phrase</code>. Use ___ where you want the cursor to jump.'));
    var ta = el('textarea', 'xin'); ta.value = lines; ta.spellcheck = false; b.appendChild(ta);
    dlg('Quick phrases', b, [{ l: 'Reset to defaults', fn: function () { delete S.snips; A.saveS(); toast('Default phrases restored'); } }, { l: 'Close' }, { l: 'Save', cls: 'pri', fn: function () {
      var o = {}; ta.value.split('\n').forEach(function (l) { var i = l.indexOf('='); if (i > 0) { var k = l.slice(0, i).trim(), v = l.slice(i + 1).trim(); if (k && v && !/\s/.test(k)) o[k] = v; } });
      S.snips = Object.keys(o).length ? o : undefined; if (!S.snips) delete S.snips; A.saveS(); toast('Quick phrases saved');
    } }]);
  };

  /* ============================================================ outline / scene cards */
  X.outline = function () {
    var c = cur(); if (!c) return; if (c.blocks.some(function (b) { return !b.id; })) return;
    A.persist && 0; var pre = [], segs = [];
    c.blocks.forEach(function (b) { if (b.t === 'scene') segs.push({ head: b, blocks: [b] }); else if (segs.length) segs[segs.length - 1].blocks.push(b); else pre.push(b); });
    var o = el('div', ''); o.id = 'ol'; document.body.appendChild(o);
    var hd = el('div', 'oh'); hd.appendChild(el('b', '', 'Outline'));
    var hb = el('div', 'xrow'); hb.style.margin = 0;
    hb.appendChild(pill('Add scene', false, function () { var nb = { id: A.uid(), t: 'scene', x: '', x2: '' }; segs.push({ head: nb, blocks: [nb] }); draw(); apply(); setTimeout(function () { var g = $('#ol .og'); g.scrollTop = g.scrollHeight; }, 30); }));
    hb.appendChild(pill('Done', true, close, 'pri')); hd.appendChild(hb); o.appendChild(hd);
    o.appendChild(el('div', 'hint', 'Press and hold a card, then drag it to a new place. Tap “Go to” to jump to that scene.'));
    var g = el('div', 'og'); o.appendChild(g);
    function close() { o.remove(); document.removeEventListener('keydown', esc2); }
    function esc2(e) { if (e.key === 'Escape') close(); } document.addEventListener('keydown', esc2);
    function apply() { A.snap(); var all = pre.slice(); segs.forEach(function (s) { all = all.concat(s.blocks); }); c.blocks.length = 0; all.forEach(function (b) { c.blocks.push(b); }); A.renderAll(); A.dirty(); }
    function words(s) { return s.blocks.reduce(function (n, b) { return n + ((b.x || '').trim() ? (b.x || '').trim().split(/\s+/).length : 0); }, 0); }
    function draw() {
      g.innerHTML = '';
      segs.forEach(function (s, i) {
        var h = s.head, title = ((h.x || '') + (h.x2 ? ' · ' + h.x2 : '')).trim() || '(scene heading empty)';
        var nx = s.blocks.filter(function (b, j) { return j > 0 && (b.x || '').trim(); })[0], card = el('div', 'oc'); card.__s = s;
        card.appendChild(el('div', 'on', 'SCENE ' + (i + 1))); card.appendChild(el('div', 'ot', esc(title))); card.appendChild(el('div', 'op', esc(nx ? (nx.x || '').slice(0, 130) : 'No lines yet')));
        var m = el('div', 'om'); m.appendChild(el('small', '', (s.blocks.length - 1) + ' lines · ' + words(s) + ' words'));
        m.appendChild(pill('Up', false, function () { if (i > 0) { segs.splice(i - 1, 0, segs.splice(i, 1)[0]); draw(); apply(); } }));
        m.appendChild(pill('Down', false, function () { if (i < segs.length - 1) { segs.splice(i + 1, 0, segs.splice(i, 1)[0]); draw(); apply(); } }));
        m.appendChild(pill('Go to', false, function () { close(); setTimeout(function () { A.focusBlock(h.id, 0); }, 60); }, 'pri'));
        card.appendChild(m); g.appendChild(card); hold(card);
      });
      if (!segs.length) g.appendChild(el('div', 'hint', 'No scenes yet – add a scene heading (INT. / EXT.) to see cards here.'));
    }
    function hold(card) {
      var t = 0, active = false, px = 0, py = 0;
      card.addEventListener('pointerdown', function (e) { if (e.target.closest('button')) return; px = e.clientX; py = e.clientY; clearTimeout(t); t = setTimeout(function () { active = true; card.classList.add('drag'); try { card.setPointerCapture(e.pointerId); } catch (x) { } if (navigator.vibrate) navigator.vibrate(12); }, 280); });
      card.addEventListener('pointermove', function (e) {
        if (!active) { if (Math.abs(e.clientX - px) > 8 || Math.abs(e.clientY - py) > 8) clearTimeout(t); return; }
        card.style.pointerEvents = 'none'; var u = document.elementFromPoint(e.clientX, e.clientY); card.style.pointerEvents = '';
        var tgt = u && u.closest && u.closest('.oc'); if (tgt && tgt !== card) { var r = tgt.getBoundingClientRect(), after = e.clientY > r.top + r.height / 2 && Math.abs(e.clientX - (r.left + r.width / 2)) < r.width; g.insertBefore(card, after ? tgt.nextSibling : tgt); }
        var gr = g.getBoundingClientRect(); if (e.clientY > gr.bottom - 60) g.scrollTop += 14; else if (e.clientY < gr.top + 60) g.scrollTop -= 14;
      });
      function end() { clearTimeout(t); if (!active) return; active = false; card.classList.remove('drag'); segs = $$('.oc', g).map(function (c2) { return c2.__s; }); draw(); apply(); }
      card.addEventListener('pointerup', end); card.addEventListener('pointercancel', end);
      card.addEventListener('touchmove', function (e) { if (active) e.preventDefault(); }, { passive: false });
      card.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    }
    draw();
  };

  /* ============================================================ accent colour */
  function hex(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/(.)/g, '$1$1'); return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]; }
  function mix(a, b, t) { var x = hex(a), y = hex(b); return '#' + [0, 1, 2].map(function (i) { return ('0' + Math.round(x[i] + (y[i] - x[i]) * t).toString(16)).slice(-2); }).join(''); }
  X.accent = function () {
    var r = root();
    if (S.accent && !r.dataset.dyn) {
      var c = S.accent, l = mix(c, '#ffffff', .4), h = hex(c), lum = (0.299 * h[0] + 0.587 * h[1] + 0.114 * h[2]);
      r.style.setProperty('--acc', c); r.style.setProperty('--acc2', l); r.style.setProperty('--grad', 'linear-gradient(100deg,' + c + ',' + l + ')'); r.style.setProperty('--onacc', lum > 170 ? '#14141c' : '#fff'); r.classList.add('accent-on');
    } else { ['--acc', '--acc2', '--grad', '--onacc'].forEach(function (p) { r.style.removeProperty(p); }); r.classList.remove('accent-on'); }
  };
  X.accentUI = function (box) {
    var hd = el('p', '', 'Accent colour – buttons and highlights on top of any theme'); hd.style.cssText = 'margin:16px 0 8px;font-size:13px;color:var(--ink2);text-align:center'; box.appendChild(hd);
    var r = el('div', ''); r.id = 'themeRow'; box.appendChild(r);
    var cols = [['#7c6cff', 'Violet'], ['#ff4d6d', 'Rose'], ['#ff9f1c', 'Amber'], ['#f5c400', 'Gold'], ['#2ec4b6', 'Teal'], ['#34c759', 'Green'], ['#3a86ff', 'Blue'], ['#c77dff', 'Orchid'], ['#ff7aa2', 'Pink']];
    var ci = el('input'); ci.type = 'color'; ci.style.cssText = 'position:absolute;opacity:0;pointer-events:none;width:1px;height:1px'; box.appendChild(ci);
    function draw() {
      r.innerHTML = '';
      var d0 = el('button', 'btn' + (!S.accent ? ' on' : ''), '<i class="dot" style="background:linear-gradient(135deg,#fff 45%,#999 45% 55%,#fff 55%)"></i>Theme default'); d0.onclick = function () { delete S.accent; A.saveS(); X.accent(); draw(); }; r.appendChild(d0);
      cols.forEach(function (c) { var b = el('button', 'btn' + (S.accent === c[0] ? ' on' : ''), '<i class="dot" style="background:' + c[0] + '"></i>' + c[1]); b.onclick = function () { S.accent = c[0]; A.saveS(); X.accent(); draw(); }; r.appendChild(b); });
      var known = cols.some(function (c) { return c[0] === S.accent; }), cu = el('button', 'btn' + (S.accent && !known ? ' on' : ''), (S.accent && !known ? '<i class="dot" style="background:' + S.accent + '"></i>' : '') + 'Any colour'); cu.onclick = function () { ci.value = S.accent || '#7c6cff'; ci.click(); }; r.appendChild(cu);
    }
    ci.onchange = ci.oninput = function () { S.accent = ci.value; A.saveS(); X.accent(); draw(); };
    draw();
  };

  /* ============================================================ paper sizes */
  X.paperDlg = function () {
    var c = cur(), b = el('div', ''), row = rowOf(b), box = el('div', ''), P = [['a4', 'A4  210 × 297 mm'], ['letter', 'Letter  8.5 × 11 in'], ['legal', 'Legal  8.5 × 14 in'], ['a5', 'A5  148 × 210 mm'], ['custom', 'Custom size']];
    var w = el('input', 'xin'), h = el('input', 'xin'); w.type = h.type = 'number'; w.min = '60'; h.min = '80'; w.placeholder = 'Width (mm)'; h.placeholder = 'Height (mm)'; w.value = c.pw || 210; h.value = c.ph || 297;
    var note = el('div', 'xsub', 'Custom size in millimetres (1 inch = 25.4 mm). Width 60–600, height 80–900. The page margins scale down for small papers.');
    function set(id) { c.paper = id; if (id === 'custom') { c.pw = Math.min(600, Math.max(60, +w.value || 210)); c.ph = Math.min(900, Math.max(80, +h.value || 297)); } A.applyLook(); A.dirty(); draw(); }
    function draw() { row.innerHTML = ''; P.forEach(function (p) { row.appendChild(pill(p[1], c.paper === p[0], function () { set(p[0]); })); }); box.style.display = c.paper === 'custom' ? '' : 'none'; }
    [w, h].forEach(function (i) { i.onchange = function () { if (c.paper === 'custom') set('custom'); }; });
    var two = el('div', 'xrow'); two.appendChild(w); two.appendChild(h); box.appendChild(two); box.appendChild(note); b.appendChild(box); draw();
    dlg('Paper size', b, [{ l: 'Done', cls: 'pri', fn: function () { if (c.paper === 'custom') set('custom'); } }]);
  };

  /* ============================================================ watermark + header */
  X.wmRefresh = function () {
    var c = cur(), sh = $('#sheet'); if (!sh) return; var o = $('#wmk'); if (o) o.remove();
    if (c && c.wm && S.wmShow !== false) { o = el('div', ''); o.id = 'wmk'; o.appendChild(el('span', '', esc(c.wm))); sh.insertBefore(o, sh.firstChild); }
  };
  X.wmDlg = function () {
    var c = cur(), b = el('div', '');
    head(b, 'Watermark', 'Printed faintly across every page – good for scripts you share');
    var wi = el('input', 'xin'); wi.value = c.wm || ''; wi.placeholder = 'e.g. DRAFT'; b.appendChild(wi);
    var r = rowOf(b); ['DRAFT', 'CONFIDENTIAL', 'COPY', 'PRIVATE'].forEach(function (t) { r.appendChild(pill(t, false, function () { wi.value = t; })); });
    head(b, 'Page header text', 'Printed small at the top right of every page, e.g. the production name');
    var hi = el('input', 'xin'); hi.value = c.hdr || ''; hi.placeholder = 'e.g. Production No. 1 – Draft 3'; b.appendChild(hi);
    var sw = el('label', ''); sw.style.cssText = 'display:flex;gap:8px;align-items:center;margin-top:10px;justify-content:center'; var ck = el('input'); ck.type = 'checkbox'; ck.checked = S.wmShow !== false; sw.appendChild(ck); sw.appendChild(document.createTextNode(' Also show the watermark faintly while writing')); b.appendChild(sw);
    dlg('Watermark & header', b, [{ l: 'Clear both', fn: function () { delete c.wm; delete c.hdr; A.dirty(); X.wmRefresh(); toast('Removed'); } }, { l: 'Cancel' }, { l: 'Apply', cls: 'pri', fn: function () {
      var a = wi.value.trim(), h = hi.value.trim(); if (a) c.wm = a; else delete c.wm; if (h) c.hdr = h; else delete c.hdr; S.wmShow = ck.checked; A.saveS(); A.dirty(); X.wmRefresh(); toast('Applied – it appears on the exported PDF');
    } }]);
  };

  /* ============================================================ cover styles + logo */
  X.coverDlg = function () {
    var c = cur(), b = el('div', ''), S1 = [['classic', 'Classic'], ['left', 'Left aligned'], ['bold', 'Bold title'], ['minimal', 'Minimal'], ['framed', 'Framed']];
    head(b, 'Cover style', 'Shown in the editor and on the exported PDF'); var r = rowOf(b);
    function draw() { r.innerHTML = ''; S1.forEach(function (s) { r.appendChild(pill(s[1], (c.cv || 'classic') === s[0], function () { c.cv = s[0]; A.renderAll(); A.dirty(); draw(); })); }); }
    draw(); head(b, 'Logo or image', 'Optional – appears above the title (small pictures work best)');
    var lr = rowOf(b);
    lr.appendChild(pill(c.logo ? 'Change image…' : 'Add image…', false, function () {
      var f = el('input'); f.type = 'file'; f.accept = 'image/*';
      f.onchange = function () {
        var file = f.files[0]; if (!file) return; var img = new Image(), u = URL.createObjectURL(file);
        img.onload = function () {
          var k = Math.min(1, 520 / Math.max(img.width, img.height)), cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
          var d = cv.toDataURL('image/png'); if (d.length > 450000) d = cv.toDataURL('image/jpeg', .85); c.logo = d; URL.revokeObjectURL(u); A.renderAll(); A.dirty(); toast('Image added'); };
        img.onerror = function () { toast('Could not read that image'); }; img.src = u;
      }; f.click();
    }));
    if (c.logo) lr.appendChild(pill('Remove image', false, function () { delete c.logo; A.renderAll(); A.dirty(); toast('Image removed'); }));
    dlg('Cover', b, [{ l: 'Done', cls: 'pri' }]);
  };

  /* ============================================================ version history (separate small database) */
  var HDB = null, lastTs = {}, lastSig = {};
  function hopen() { return HDB || (HDB = new Promise(function (res, rej) { var r = indexedDB.open('finnish-hist', 1); r.onupgradeneeded = function () { var s = r.result.createObjectStore('v', { keyPath: 'k' }); s.createIndex('id', 'id'); }; r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; })); }
  function hlist(id) { return hopen().then(function (db) { return new Promise(function (res) { var q = db.transaction('v').objectStore('v').index('id').getAll(id); q.onsuccess = function () { res((q.result || []).sort(function (a, b) { return b.ts - a.ts; })); }; q.onerror = function () { res([]); }; }); }).catch(function () { return []; }); }
  function hdel(keys) { return hopen().then(function (db) { var t = db.transaction('v', 'readwrite'), s = t.objectStore('v'); keys.forEach(function (k) { s.delete(k); }); }); }
  function snapOf(c) { var o = JSON.parse(JSON.stringify(c)); delete o.logo; delete o._tmp; delete o._h; return JSON.stringify(o); }
  function wordsOf(c) { return c.blocks.reduce(function (n, b) { var t = ((b.x || '') + ' ' + (b.x2 || '')).trim(); return n + (t ? t.split(/\s+/).length : 0); }, 0); }
  function prune(id) {
    hlist(id).then(function (l) {
      var keep = {}, days = {}; l.slice(0, 14).forEach(function (v) { keep[v.k] = 1; });
      l.slice(14).forEach(function (v) { var d = new Date(v.ts).toDateString(); if (!days[d] && Object.keys(days).length < 10) { days[d] = 1; keep[v.k] = 1; } });
      var del = l.filter(function (v) { return !keep[v.k] && !v.pin; }).map(function (v) { return v.k; }); if (del.length) hdel(del);
    });
  }
  function addVersion(c, label, force) {
    var sig = snapOf(c), now = Date.now(); if (!force && sig === lastSig[c.id]) return Promise.resolve(false);
    lastSig[c.id] = sig; lastTs[c.id] = now;
    return hopen().then(function (db) { return new Promise(function (res) { var t = db.transaction('v', 'readwrite'); t.objectStore('v').put({ k: c.id + '|' + now, id: c.id, ts: now, n: c.blocks.length, w: wordsOf(c), title: c.title || '', label: label || '', doc: sig }); t.oncomplete = function () { prune(c.id); res(true); }; t.onerror = function () { res(false); }; }); }).catch(function () { return false; });
  }
  X.version = function (c) { if (!c || !c.blocks) return; var last = lastTs[c.id] || 0; if (Date.now() - last < 10 * 60 * 1000) return; addVersion(c); };
  X.opened = function (c) { // baseline of the script as it was when opened
    if (!c) return; lastSig[c.id] = snapOf(c); hlist(c.id).then(function (l) { lastTs[c.id] = l.length ? l[0].ts : 0; if (!l.length || Date.now() - l[0].ts > 6 * 3600 * 1000) addVersion(c, 'Opened', true); });
  };
  function when(ts) { var d = new Date(ts), t = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), n = new Date(), y = new Date(Date.now() - 864e5); return (d.toDateString() === n.toDateString() ? 'Today' : d.toDateString() === y.toDateString() ? 'Yesterday' : d.toLocaleDateString([], { day: 'numeric', month: 'short' })) + ', ' + t; }
  X.historyDlg = function () {
    var c = cur(), b = el('div', ''), l = el('div', 'saved-list'); b.appendChild(el('p', '', 'Older copies of this script are kept automatically while you write. Restoring one first saves your current version, so nothing is lost.')); b.appendChild(l);
    var d = dlg('Version history', b, [{ l: 'Save a version now', fn: function () { A.persist(); addVersion(c, 'Saved by you', true).then(function () { toast('Version saved'); }); } }, { l: 'Close', cls: 'pri' }]);
    hlist(c.id).then(function (list) {
      if (!list.length) l.appendChild(el('div', 'sv', 'No older versions yet – they appear as you write.'));
      list.forEach(function (v) {
        var r = el('div', 'sv'); r.innerHTML = '<b>' + esc(when(v.ts)) + '</b><br><small>' + v.n + ' lines · ' + v.w + ' words' + (v.label ? ' · ' + esc(v.label) : '') + '</small>';
        r.onclick = function () {
          d.close(); dlg('Restore this version?', '<p>' + esc(when(v.ts)) + ' – ' + v.n + ' lines, ' + v.w + ' words. Your current script is saved to the history first.</p>', [{ l: 'Cancel' }, { l: 'Restore', cls: 'pri', fn: function () {
            addVersion(c, 'Before restore', true).then(function () {
              var o = JSON.parse(v.doc), keepId = c.id; ['blocks', 'title', 'writer', 'director', 'date', 'cfm', 'titleFont', 'font', 'size', 'pageColor', 'textColor', 'fmt', 'paper', 'pw', 'ph', 'wm', 'hdr', 'cv', 'lang'].forEach(function (k) { if (o[k] === undefined) delete c[k]; else c[k] = o[k]; });
              c.id = keepId; A.snap(); A.renderAll(); A.dirty(); A.persist(); toast('Version restored');
            });
          } }]);
        };
        l.appendChild(r);
      });
    });
  };

  /* ============================================================ app lock (password / PIN and / or fingerprint) */
  function rnd(n) { var a = new Uint8Array(n); (window.crypto || {}).getRandomValues ? crypto.getRandomValues(a) : a.forEach(function (_, i) { a[i] = Math.random() * 256; }); return Array.prototype.map.call(a, function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); }
  function hash(pw, salt) {
    var enc = new TextEncoder().encode(pw);
    if (window.crypto && crypto.subtle) return crypto.subtle.importKey('raw', enc, 'PBKDF2', false, ['deriveBits']).then(function (k) { return crypto.subtle.deriveBits({ name: 'PBKDF2', salt: new TextEncoder().encode(salt), iterations: 60000, hash: 'SHA-256' }, k, 256); }).then(function (b) { return Array.prototype.map.call(new Uint8Array(b), function (x) { return ('0' + x.toString(16)).slice(-2); }).join(''); });
    var h = 5381, s = salt + pw; for (var r = 0; r < 4000; r++) for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return Promise.resolve('w' + (h >>> 0).toString(16));
  }
  function recCode() { var al = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789', a = new Uint8Array(12); crypto.getRandomValues(a); var s = ''; for (var i = 0; i < 12; i++) { s += al[a[i] % al.length]; if (i % 4 === 3 && i < 11) s += '-'; } return s; }
  var locked = false, fails = 0, waitUntil = 0, bioBusy = false, hiddenAt = 0, unlockedAt = 0, lockView = '';
  function FPn() { var f = THK.fp && THK.fp(); return f && f.bioAuth ? f : null; }
  function afterMs() { return S.lock && S.lock.afterSet ? (S.lock.after | 0) * 1000 : 0; }
  function finish() { $$('#lock').forEach(function (n) { n.remove(); }); locked = false; fails = 0; bioBusy = false; hiddenAt = 0; unlockedAt = Date.now(); }
  function tryBio() {
    var f = FPn(); if (!S.lock || !S.lock.bio || !f || bioBusy || !$('#lock')) return; bioBusy = true;
    f.bioAuth({ title: 'Unlock finnish', cancel: S.lock.hash ? 'Use password' : 'Cancel' }).then(function (r) { bioBusy = false; if (r && r.ok) finish(); }).catch(function () { bioBusy = false; if (S.lock && S.lock.hash && $('#lock') && lockView === 'bio') lockShow('pw'); });
  }
  var lockBody = null;
  function lockShow(v) {
    var o = $('#lock'); if (!o || !S.lock) return; lockView = v; lockBody.innerHTML = '';
    var msg = el('div', 'msg'), row = el('div', 'xrow');
    if (v === 'bio') {
      lockBody.appendChild(el('div', 'msg', 'Touch the fingerprint sensor to unlock')); lockBody.appendChild(row);
      row.appendChild(pill('Use fingerprint', true, tryBio, 'pri'));
      row.appendChild(pill(S.lock.hash ? 'Use password instead' : 'Use recovery code', false, function () { lockShow(S.lock.hash ? 'pw' : 'rec'); }));
    } else if (v === 'pw') {
      var pw = el('input'); pw.type = 'password'; pw.placeholder = 'Password or PIN'; pw.autocomplete = 'current-password'; lockBody.appendChild(pw); lockBody.appendChild(msg); lockBody.appendChild(row);
      var go = function () {
        if (Date.now() < waitUntil) { msg.textContent = 'Too many tries – wait ' + Math.ceil((waitUntil - Date.now()) / 1000) + ' s'; return; }
        hash(pw.value, S.lock.salt).then(function (h) { if (h === S.lock.hash) finish(); else { fails++; pw.value = ''; msg.textContent = 'Wrong password'; o.classList.remove('shake'); void o.offsetWidth; o.classList.add('shake'); if (fails >= 5) { waitUntil = Date.now() + 30000; fails = 0; } } });
      };
      row.appendChild(pill('Unlock', true, go, 'pri'));
      if (S.lock.bio && FPn()) row.appendChild(pill('Use fingerprint instead', false, function () { lockShow('bio'); tryBio(); }));
      row.appendChild(pill('Forgot password', false, function () { lockShow('rec'); }));
      pw.onkeydown = function (e) { if (e.key === 'Enter') go(); }; setTimeout(function () { pw.focus(); }, 150);
    } else {
      var i = el('input'); i.placeholder = 'Recovery code (XXXX-XXXX-XXXX)'; i.style.textTransform = 'uppercase'; lockBody.appendChild(el('div', 'msg', 'Enter the recovery code shown when the lock was set up')); lockBody.appendChild(i); lockBody.appendChild(msg); lockBody.appendChild(row);
      var rc = function () { hash(i.value.trim().toUpperCase(), S.lock.salt + 'r').then(function (h) { if (h === S.lock.rec) { delete S.lock; A.saveS(); finish(); toast('Lock removed – set it up again in Customise'); } else msg.textContent = 'That code is not right'; }); };
      row.appendChild(pill('Remove lock', true, rc, 'pri')); i.onkeydown = function (e) { if (e.key === 'Enter') rc(); };
      var back = S.lock.bio && FPn() ? 'bio' : (S.lock.hash ? 'pw' : ''); if (back) row.appendChild(pill('Back', false, function () { lockShow(back); if (back === 'bio') tryBio(); }));
    }
  }
  function lockScreen() {
    if (!S.lock || $('#lock')) return; locked = true; var o = el('div', ''); o.id = 'lock';
    var w = el('div', 'wm'); w.setAttribute('role', 'img'); o.appendChild(w); lockBody = el('div', ''); lockBody.style.cssText = 'display:flex;flex-direction:column;align-items:center;gap:14px;width:100%'; o.appendChild(lockBody); document.body.appendChild(o);
    var v = S.lock.bio && FPn() ? 'bio' : (S.lock.hash ? 'pw' : 'rec'); lockShow(v); if (v === 'bio' && !document.hidden) setTimeout(tryBio, 300);
  }
  function away() { if (!S.lock || bioBusy || Date.now() - unlockedAt < 1500) return; if (!hiddenAt) hiddenAt = Date.now(); if (afterMs() === 0) lockScreen(); }
  function back() {
    if (!S.lock || bioBusy) return; var h = hiddenAt; hiddenAt = 0;
    if (h && Date.now() - h >= afterMs()) lockScreen();
    if ($('#lock') && lockView === 'bio') setTimeout(tryBio, 250);
  }
  document.addEventListener('visibilitychange', function () { if (document.hidden) away(); else back(); });
  document.addEventListener('pause', away); document.addEventListener('resume', back);
  (function () { var f = THK.fp && THK.fp(); if (f && f.addListener) try { f.addListener('appState', function (e) { if (e && e.active) back(); else away(); }); } catch (er) { } })();
  X.lockNow = function () { if (!S.lock) return toast('Set an app lock first (Customise)'); lockScreen(); };
  function recoveryNotice(code) { dlg('Save your recovery code', '<p>If you ever cannot unlock the app, this code is the only way back in. Write it down somewhere safe – it is shown only once.</p><p style="font:700 22px ui-monospace,Menlo,monospace;text-align:center;letter-spacing:2px;user-select:all">' + code + '</p>', [{ l: 'I saved it', cls: 'pri' }]); }
  function setPassword(onDone) {
    var change = !!(S.lock && S.lock.hash), p1 = el('input', 'xin'), p2 = el('input', 'xin'); p1.type = p2.type = 'password'; p1.placeholder = 'New password or PIN (4+ characters)'; p2.placeholder = 'Repeat it';
    var bb = el('div', ''); bb.appendChild(p1); bb.appendChild(p2);
    dlg(change ? 'Change password' : 'Set password or PIN', bb, [{ l: 'Cancel' }, { l: 'Save', cls: 'pri', fn: function () {
      if (p1.value.length < 4) { toast('Use at least 4 characters'); return false; } if (p1.value !== p2.value) { toast('The two do not match'); return false; }
      var fresh = !S.lock, salt = fresh ? rnd(8) : S.lock.salt, code = fresh ? recCode() : null;
      Promise.all([hash(p1.value, salt), fresh ? hash(code, salt + 'r') : Promise.resolve(S.lock.rec)]).then(function (h) {
        if (fresh) S.lock = { salt: salt, hash: h[0], rec: h[1], after: 0, afterSet: false, bio: false }; else S.lock.hash = h[0];
        A.saveS(); if (fresh) recoveryNotice(code); else toast('Password changed'); if (onDone) onDone();
      });
    } }]);
  }
  function enableBio(onDone) {
    var f = FPn(); if (!f) return toast('Fingerprint unlock works in the Android app');
    f.bioAvailable().then(function (r) {
      if (!r || !r.ok) return toast('No fingerprint is set up on this device – add one in the device settings first');
      return f.bioAuth({ title: 'Confirm your fingerprint', cancel: 'Cancel' }).then(function (q) {
        if (!q || !q.ok) return; var fresh = !S.lock, code = null;
        var fin = function () { S.lock.bio = true; A.saveS(); toast('Fingerprint unlock is on'); if (fresh && code) recoveryNotice(code); if (onDone) onDone(); };
        if (fresh) { var salt = rnd(8); code = recCode(); hash(code, salt + 'r').then(function (h) { S.lock = { salt: salt, hash: null, rec: h, after: 0, afterSet: false, bio: false }; fin(); }); } else fin();
      });
    }).catch(function () { toast('Fingerprint was not confirmed'); });
  }
  X.lockDlg = function () {
    var holder = el('div', ''), d = dlg('App lock', holder, [{ l: 'Close', cls: 'pri' }]);
    function draw() {
      holder.innerHTML = ''; var has = !!S.lock;
      holder.appendChild(el('p', '', has ? 'The app asks to be unlocked when you open it and when you come back to it. Only one unlock option is shown at a time.' : 'Keep your scripts private. Choose how to unlock – you can use either, or both.'));
      head(holder, 'Password or PIN'); var r1 = rowOf(holder);
      if (!has || !S.lock.hash) r1.appendChild(pill('Set password or PIN', false, function () { setPassword(draw); }, 'pri'));
      else { r1.appendChild(pill('Change', false, function () { setPassword(draw); })); if (S.lock.bio) r1.appendChild(pill('Remove', false, function () { delete S.lock.hash; S.lock.hash = null; A.saveS(); draw(); toast('Password removed – fingerprint only'); })); }
      head(holder, 'Fingerprint'); var r2 = rowOf(holder);
      if (!FPn()) { r2.appendChild(pill('Use fingerprint', false, function () { toast('Fingerprint unlock works in the Android app'); })); }
      else if (has && S.lock.bio) { r2.appendChild(pill('Fingerprint: On', true, function () { }, 'pri')); if (S.lock.hash) r2.appendChild(pill('Turn off', false, function () { S.lock.bio = false; A.saveS(); draw(); })); }
      else r2.appendChild(pill('Use fingerprint', false, function () { enableBio(draw); }));
      if (has) {
        head(holder, 'Lock after leaving the app'); var ar = rowOf(holder), cur2 = S.lock.afterSet ? (S.lock.after | 0) : 0;
        [[0, 'Right away'], [30, '30 seconds'], [300, '5 minutes']].forEach(function (a) { ar.appendChild(pill(a[1], cur2 === a[0], function () { S.lock.after = a[0]; S.lock.afterSet = true; A.saveS(); draw(); })); });
        head(holder, ''); var r3 = rowOf(holder); r3.appendChild(pill('Lock now', false, function () { d.close(); lockScreen(); }));
        r3.appendChild(pill('Turn off lock', false, function () { delete S.lock; A.saveS(); draw(); toast('App lock is off'); }));
      }
      holder.appendChild(el('div', 'xsub', 'This locks the app screen. Files you export or share are not encrypted.'));
    }
    draw();
  };
  if (S.lock) lockScreen();

  /* ============================================================ reading mode + read aloud */
  var RD = { on: false, i: 0, playing: false, rate: 1, voice: '', multi: true, voices: [] };
  var BCP = { ml: 'ml', en: 'en', ta: 'ta', te: 'te', kn: 'kn', hi: 'hi', mr: 'mr', bn: 'bn' };
  function loadVoices() { RD.voices = (window.speechSynthesis && speechSynthesis.getVoices()) || []; }
  if (window.speechSynthesis) { loadVoices(); speechSynthesis.onvoiceschanged = loadVoices; }
  function voicesFor(lang) { var p = ((window.THK && THK.lang && THK.lang(lang).bcp) || BCP[lang] || 'en').toLowerCase().split('-')[0]; return RD.voices.filter(function (v) { return (v.lang || '').toLowerCase().replace('_', '-').indexOf(p) === 0; }); }
  var bar = el('div', ''); bar.id = 'rdbar'; document.body.appendChild(bar);
  function items() { // what gets spoken, in order
    var out = [], c = cur(), lastChar = '';
    c.blocks.forEach(function (b) {
      var t = (b.x || '').replace(/\s+/g, ' ').trim(); if (!t || b.t === 'note') return;
      if (b.t === 'char') { lastChar = t; return; }
      if (b.t === 'paren') return;
      if (b.t === 'dial') out.push({ id: b.id, text: t, who: lastChar }); else if (b.t === 'trans') return; else out.push({ id: b.id, text: (b.t === 'scene' ? ((b.x2 ? t + ', ' + b.x2 : t)) : t), who: '' });
    }); return out;
  }
  function hue(s) { var h = 0; for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; return Math.abs(h); }
  var LT = THK.LOC, uidN = 0, curId = '';
  function nat() { var f = THK.fp && THK.fp(); return f && f.ttsSpeak ? f : null; }
  (function () { var f = nat(); if (f && f.addListener) try { f.addListener('ttsEnd', function (e) { if (e && e.id === curId && RD.playing) { if (e.ok) speakAt(RD.i + 1); else { RD.playing = false; drawBar(); toast('Could not read that line'); } } }); } catch (er) { } })();
  function stopSpeak() { RD.playing = false; curId = ''; try { var f = nat(); if (f) f.ttsStop(); else speechSynthesis.cancel(); } catch (e) { } $$('#page .b.speaking').forEach(function (x) { x.classList.remove('speaking'); }); drawBar(); }
  function voiceHelp(why) {
    var f = nat(), nm = THK.lang(cur().lang).name, b = el('div', '');
    b.appendChild(el('p', '', why === 'engine' ? 'This device has no text-to-speech engine. Install <b>Speech Services by Google</b> from the Play Store, then try again.' : 'The <b>' + esc(nm) + '</b> voice is not installed on this device yet. Open the voice settings, choose <b>Speech Services by Google</b> → <b>Install voice data</b>, and download <b>' + esc(nm) + '</b>. This is a one-time download.'));
    dlg('Voice needed', b, [{ l: 'Close' }, { l: 'Open voice settings', cls: 'pri', fn: function () { if (f && f.ttsSettings) f.ttsSettings(); } }]);
  }
  function speakAt(i) {
    var list = items(); if (i < 0) i = 0; if (i >= list.length) { stopSpeak(); RD.i = 0; return toast('Finished reading'); }
    RD.i = i; RD.playing = true; var it = list[i], c = cur();
    $$('#page .b.speaking').forEach(function (x) { x.classList.remove('speaking'); }); var w = A.blockEl(it.id); if (w) { w.classList.add('speaking'); w.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    var pitch = it.who && RD.multi ? 0.8 + (hue(it.who) % 9) * 0.06 : 1, f = nat();
    if (f) {
      curId = 'u' + (++uidN); var id = curId;
      f.ttsSpeak({ text: it.text, lang: LT[c.lang] || 'en-IN', rate: RD.rate, pitch: pitch, id: id, voice: (S.ttsVoice || {})[c.lang] || '' }).then(function (r) { if (r && !r.ok && curId === id) { RD.playing = false; curId = ''; drawBar(); voiceHelp(r.why); } }).catch(function () { RD.playing = false; drawBar(); toast('Read aloud failed'); });
      drawBar(); return;
    }
    var vs = voicesFor(c.lang), u = new SpeechSynthesisUtterance(it.text); u.lang = LT[c.lang] || 'en-IN'; u.rate = RD.rate;
    var v = null; if (vs.length) { v = RD.voice && vs.filter(function (x) { return x.name === RD.voice; })[0]; if (!v) v = vs[0]; if (RD.multi && it.who && !RD.voice && vs.length > 1) v = vs[hue(it.who) % vs.length]; }
    if (v) { u.voice = v; u.lang = v.lang; } u.pitch = pitch;
    u.onend = function () { if (RD.playing && RD.i === i) speakAt(i + 1); }; u.onerror = function () { if (RD.playing && RD.i === i) { RD.playing = false; drawBar(); } };
    try { if (speechSynthesis.speaking || speechSynthesis.pending) speechSynthesis.cancel(); speechSynthesis.resume(); speechSynthesis.speak(u); } catch (e) { toast('This device cannot read aloud'); RD.playing = false; } drawBar();
  }
  function canSpeak() { return !!(nat() || window.speechSynthesis); }
  function drawBar() {
    bar.innerHTML = '';
    bar.appendChild(pill(RD.playing ? 'Pause' : 'Read aloud', true, function () { if (RD.playing) stopSpeak(); else { if (!canSpeak()) return toast('Read aloud is not available on this device'); if (!nat() && !voicesFor(cur().lang).length) toast('No ' + THK.lang(cur().lang).name + ' voice found – install one in your device’s text-to-speech settings'); speakAt(RD.i); } }, 'pri'));
    bar.appendChild(pill('Back', false, function () { var p = RD.playing; stopSpeak(); RD.i = Math.max(0, RD.i - 1); if (p) speakAt(RD.i); }));
    bar.appendChild(pill('Next', false, function () { var p = RD.playing; stopSpeak(); RD.i = RD.i + 1; if (p) speakAt(RD.i); }));
    bar.appendChild(pill(RD.rate + '×', false, function () { var r = [0.8, 1, 1.25, 1.5]; RD.rate = r[(r.indexOf(RD.rate) + 1) % r.length]; if (RD.playing) { var i = RD.i; stopSpeak(); speakAt(i); } else drawBar(); }));
    bar.appendChild(pill('Voices', false, function () {
      var f = nat(), b = el('div', 'xrow'); b.style.flexDirection = 'column'; b.style.alignItems = 'stretch'; var d;
      function row(label, on, fn, keep) { var p = pill(label, on, function () { fn(); if (!keep) d.close(); }); b.appendChild(p); return p; }
      if (f) {
        b.appendChild(el('div', 'xsub', 'Languages this device can read aloud:'));
        var tags = Object.keys(LT).map(function (k) { return LT[k]; }), box = el('div', 'xrow'); b.appendChild(box);
        f.ttsLangs({ tags: tags }).then(function (r) { box.innerHTML = ''; if (!r.engine) { box.appendChild(el('div', 'xsub', 'No text-to-speech engine found. Install Speech Services by Google from the Play Store.')); return; } Object.keys(LT).forEach(function (k) { box.appendChild(pill(THK.lang(k).name + (r.langs[LT[k]] ? ' – ready' : ' – not installed'), !!r.langs[LT[k]], function () { if (!r.langs[LT[k]]) { var cl = cur().lang; cur().lang = k; voiceHelp('lang'); cur().lang = cl; } })); }); });
        if (f.ttsVoices) {
          var vb = el('div', 'xrow'); b.appendChild(el('div', 'xsub', 'Voice for ' + THK.lang(cur().lang).name + ' – pick the most natural one:')); b.appendChild(vb);
          f.ttsVoices({ tag: LT[cur().lang] }).then(function (r) {
            var L = cur().lang, vs = (r.voices || []).filter(function (v) { return !v.missing; }).sort(function (a, c2) { return (c2.quality - a.quality) || (a.network - c2.network); }); S.ttsVoice = S.ttsVoice || {};
            var one = function (label, name) { var p = pill(label, (S.ttsVoice[L] || '') === name, function () { S.ttsVoice[L] = name; A.saveS(); $$('.btn', vb).forEach(function (q) { q.classList.remove('on'); }); p.classList.add('on'); if (nat()) nat().ttsSpeak({ text: THK.lang(L).id === 'en' ? 'This is how I sound.' : '1 2 3', lang: LT[L], rate: RD.rate, pitch: 1, id: 'pv', voice: name }); }); vb.appendChild(p); };
            one('Device default', ''); vs.forEach(function (v, i) { one('Voice ' + (i + 1) + (v.quality >= 400 ? ' – high quality' : '') + (v.network ? ' – online' : ' – offline'), v.name); });
            if (!vs.length) vb.appendChild(el('div', 'xsub', 'No separate voices found for this language.'));
          });
        }
        row('Install or manage voices', false, function () { f.ttsSettings(); });
      } else {
        var vs = voicesFor(cur().lang);
        row('Automatic', !RD.voice, function () { RD.voice = ''; });
        vs.forEach(function (v) { row(v.name, RD.voice === v.name, function () { RD.voice = v.name; }); });
        if (!vs.length) b.appendChild(el('div', 'xsub', 'No ' + THK.lang(cur().lang).name + ' voice is installed on this device. Add one in the device’s text-to-speech settings.'));
      }
      row('Different tone per character', RD.multi, function () { RD.multi = !RD.multi; });
      d = dlg('Voice', b, [{ l: 'Close', cls: 'pri' }]);
    }));
    bar.appendChild(pill('Exit reading', false, function () { X.reading(false); }));
  }
  X.reading = function (on, autoplay) {
    if (on === undefined) on = !RD.on; var c = cur(); if (on && !c) return;
    RD.on = !!on; root().classList.toggle('reading', RD.on);
    $$('.ed').forEach(function (e) { e.contentEditable = RD.on ? 'false' : A.PT; });
    if (RD.on) { RD.i = 0; drawBar(); loadVoices(); if (autoplay) setTimeout(function () { if (!canSpeak()) toast('Read aloud is not available on this device'); else speakAt(0); }, 150); $('#scroll').scrollTop = 0; }
    else { stopSpeak(); }
  };

  /* ============================================================ Word (.docx) export */
  var CRC = (function () { var t = []; for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u) { var c = 0xFFFFFFFF; for (var i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function zip(files) { // stored (uncompressed) zip
    var enc = new TextEncoder(), parts = [], cd = [], off = 0;
    function w16(a, v) { a.push(v & 255, (v >> 8) & 255); } function w32(a, v) { a.push(v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >>> 24) & 255); }
    Object.keys(files).forEach(function (n) {
      var nm = enc.encode(n), d = enc.encode(files[n]), c = crc32(d), h = [];
      w32(h, 0x04034b50); w16(h, 20); w16(h, 0x0800); w16(h, 0); w16(h, 0); w16(h, 0x21); w32(h, c); w32(h, d.length); w32(h, d.length); w16(h, nm.length); w16(h, 0);
      parts.push(new Uint8Array(h), nm, d);
      var e = []; w32(e, 0x02014b50); w16(e, 20); w16(e, 20); w16(e, 0x0800); w16(e, 0); w16(e, 0); w16(e, 0x21); w32(e, c); w32(e, d.length); w32(e, d.length); w16(e, nm.length); w16(e, 0); w16(e, 0); w16(e, 0); w16(e, 0); w32(e, 0); w32(e, off);
      cd.push(new Uint8Array(e), nm); off += h.length + nm.length + d.length;
    });
    var cdLen = cd.reduce(function (n, p) { return n + p.length; }, 0), end = []; w32(end, 0x06054b50); w16(end, 0); w16(end, 0); w16(end, Object.keys(files).length); w16(end, Object.keys(files).length); w32(end, cdLen); w32(end, off); w16(end, 0);
    var all = parts.concat(cd, [new Uint8Array(end)]), len = all.reduce(function (n, p) { return n + p.length; }, 0), out = new Uint8Array(len), p0 = 0; all.forEach(function (p) { out.set(p, p0); p0 += p.length; }); return out;
  }
  function xe(s) { return String(s == null ? '' : s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function runsXml(text, fm, base) { // base: {b,i,u,c,z}
    text = text || ''; var pts = [0, text.length]; (fm || []).forEach(function (r) { pts.push(r.s, r.e); });
    pts = pts.filter(function (p, i, a) { return p >= 0 && p <= text.length && a.indexOf(p) === i; }).sort(function (a, b) { return a - b; }); var out = '';
    for (var i = 0; i < pts.length - 1; i++) {
      var p = pts[i], q = pts[i + 1], seg = text.slice(p, q), a = Object.assign({}, base || {}); (fm || []).forEach(function (r) { if (r.s <= p && p < r.e) { ['b', 'i', 'u', 'c', 'z'].forEach(function (k) { if (r[k]) a[k] = r[k]; }); } });
      var rp = (a.b ? '<w:b/>' : '') + (a.i ? '<w:i/>' : '') + (a.u ? '<w:u w:val="single"/>' : '') + (a.c ? '<w:color w:val="' + String(a.c).replace('#', '') + '"/>' : '') + (a.z ? '<w:sz w:val="' + Math.round(a.z * 2) + '"/><w:szCs w:val="' + Math.round(a.z * 2) + '"/>' : '');
      seg.split('\n').forEach(function (line, li) { out += '<w:r>' + (rp ? '<w:rPr>' + rp + '</w:rPr>' : '') + (li ? '<w:br/>' : '') + '<w:t xml:space="preserve">' + xe(line) + '</w:t></w:r>'; });
    } return out;
  }
  X.docx = function (d, o) {
    o = o || {}; var P = THK.paperOf(d), tw = function (mm) { return Math.round(mm * 56.6929); }, W = tw(parseFloat(P.w)), H = tw(parseFloat(P.h)), ms = Math.min(1, parseFloat(P.w) / 210), two = d.fmt === 'two', fs = d.size || 12;
    var latin = THK.font(d.font).g || /Courier|Times|Arial/.test(THK.font(d.font).label) ? ((THK.font(d.font).label.match(/Courier New|Times New Roman|Arial/) || [])[0] || (d.lang === 'en' ? 'Courier New' : 'Courier New')) : 'Courier New';
    var fonts = '<w:rFonts w:ascii="' + latin + '" w:hAnsi="' + latin + '" w:cs="Nirmala UI" w:eastAsia="Nirmala UI"/>';
    var mT = tw(22 * ms), mR = tw(20 * ms), mB = tw(20 * ms), mL = tw((two ? 20 : 30) * ms);
    function sect(extra) { return '<w:sectPr>' + (extra || '') + '<w:pgSz w:w="' + W + '" w:h="' + H + '"/><w:pgMar w:top="' + mT + '" w:right="' + mR + '" w:bottom="' + mB + '" w:left="' + mL + '" w:header="' + tw(10) + '" w:footer="' + tw(10) + '" w:gutter="0"/></w:sectPr>'; }
    function para(inner, ppr) { return '<w:p><w:pPr>' + (ppr || '') + '</w:pPr>' + inner + '</w:p>'; }
    var body = '', cf = d.cfm || {};
    if (o.cover !== false) {
      var sp = Math.round((H - mT - mB) * 0.28);
      body += para(runsXml(d.title || 'Untitled', cf.title, { b: 1, z: fs * 2.4 }), '<w:spacing w:before="' + sp + '" w:after="' + tw(10) + '"/><w:jc w:val="center"/>');
      [['Writer :', d.writer, cf.writer], ['Director :', d.director, cf.director], ['Date :', d.date || THK.todayStr(), d.date ? cf.date : null]].forEach(function (r) { body += para('<w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">' + xe(r[0]) + ' </w:t></w:r>' + runsXml(r[1] || '', r[2]), '<w:spacing w:after="120"/><w:jc w:val="center"/>'); });
      body += '<w:p><w:pPr>' + sect('<w:type w:val="nextPage"/>') + '</w:pPr></w:p>'.replace('<w:type w:val="nextPage"/>', '');
    }
    var TWD = W - mL - mR, ind = { char: '<w:ind w:left="' + Math.round(TWD * 0.15) + '" w:right="' + Math.round(TWD * 0.15) + '"/><w:jc w:val="center"/>', paren: '<w:ind w:left="' + Math.round(TWD * 0.15) + '" w:right="' + Math.round(TWD * 0.15) + '"/><w:jc w:val="center"/>', dial: '<w:ind w:left="' + Math.round(TWD * 0.16) + '" w:right="' + Math.round(TWD * 0.16) + '"/>' };
    if (!two) {
      var sn = 0, snOn = o.sceneNos !== false, numR = function (n) { return '<w:r><w:rPr><w:b/></w:rPr><w:t>' + n + '</w:t></w:r>'; };
      d.blocks.forEach(function (b) {
        if (b.t === 'scene') sn++;
        var x = b.x || ''; if (b.t === 'note') return; if (!x.trim() && !(b.x2 || '').trim()) { if (b.pb) body += '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'; return; }
        var ppr = (b.pb ? '<w:pageBreakBefore/>' : ''), base = null, t = x, fm = (b.fm || {}).x, sceneNo = false;
        if (b.t === 'scene' && !(fm && fm.length)) t = x = THK.stripSn(x);
        if (b.t === 'scene') { sceneNo = snOn; ppr = '<w:keepNext/>' + ppr + (snOn ? '<w:tabs><w:tab w:val="left" w:pos="567"/><w:tab w:val="right" w:pos="' + (W - mL - mR) + '"/></w:tabs>' : '') + '<w:spacing w:before="240" w:after="120"/>' + (snOn ? '<w:ind w:left="567" w:hanging="567"/>' : ''); base = { b: 1 }; if (b.x2) { t = x + ' – ' + b.x2; } }
        else if (b.t === 'char') { ppr = '<w:keepNext/>' + ppr + '<w:spacing w:before="120" w:after="0"/>' + ind.char; base = { b: 1 }; }
        else if (b.t === 'paren') { ppr = '<w:keepNext/>' + ppr + '<w:spacing w:after="0"/>' + ind.paren; t = '(' + x.replace(/^\(|\)$/g, '') + ')'; fm = (fm || []).map(function (r) { return Object.assign({}, r, { s: r.s + 1, e: r.e + 1 }); }); }
        else if (b.t === 'dial') ppr += '<w:spacing w:after="160"/>' + ind.dial;
        else if (b.t === 'trans') { ppr += '<w:spacing w:before="120" w:after="160"/><w:jc w:val="right"/>'; base = { b: 1 }; }
        else if (THK.el && THK.el.get(d, b.t)) { var cx = THK.el.docx(d, b); ppr += '<w:spacing w:after="160"/><w:ind w:left="' + Math.round(TWD * cx.ind / 100) + '" w:right="' + Math.round(TWD * cx.ind / 100) + '"/><w:jc w:val="' + cx.jc + '"/>'; base = { b: cx.b, i: cx.i, u: cx.u }; var xx = cx.up ? x.toUpperCase() : x; t = cx.pre + xx + cx.suf; fm = (fm || []).map(function (r) { return Object.assign({}, r, { s: r.s + cx.pre.length, e: r.e + cx.pre.length }); }); }
        else ppr += '<w:spacing w:after="160"/>';
        if (b.al) ppr += '<w:jc w:val="' + ({ left: 'left', center: 'center', right: 'right', justify: 'both' })[b.al] + '"/>';
        body += para(sceneNo ? numR(sn) + '<w:r><w:tab/></w:r>' + runsXml(t, fm, base) + '<w:r><w:tab/></w:r>' + numR(sn) : runsXml(t, fm, base), ppr);
      });
    } else { // two column layout: a borderless table, one row per line
      var cell = function (inner, wd) { return '<w:tc><w:tcPr><w:tcW w:w="' + wd + '" w:type="dxa"/></w:tcPr>' + (inner || '<w:p/>') + '</w:tc>'; }, half = Math.floor((W - mL - mR) / 2), rows = '';
      var sn2 = 0;
      d.blocks.forEach(function (b) {
        if (b.t === 'scene') sn2++;
        var x = b.x || ''; if (b.t === 'note' || (!x.trim() && !(b.x2 || '').trim())) return; var l = '', r = '', fm = (b.fm || {}).x;
        if (b.t === 'scene' && !(fm && fm.length)) x = THK.stripSn(x);
        if (b.t === 'scene') { l = para((o.sceneNos !== false ? '<w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">' + sn2 + '  </w:t></w:r>' : '') + runsXml(x, fm, { b: 1 }), '<w:keepNext/>'); r = b.x2 ? para(runsXml(b.x2, (b.fm || {}).x2, { b: 1 })) : ''; }
        else if (b.t === 'char') { l = para(runsXml(x, fm, { b: 1 }), '<w:jc w:val="right"/>'); }
        else if (b.t === 'paren') r = para(runsXml('(' + x.replace(/^\(|\)$/g, '') + ')', (fm || []).map(function (q) { return Object.assign({}, q, { s: q.s + 1, e: q.e + 1 }); })));
        else if (b.t === 'dial') r = para(runsXml(x, fm));
        else if (b.t === 'trans') l = para(runsXml(x, fm, { b: 1 }), '<w:jc w:val="right"/>'); else if (THK.el && THK.el.get(d, b.t)) { var cx2 = THK.el.docx(d, b), tt = cx2.pre + (cx2.up ? x.toUpperCase() : x) + cx2.suf, pp = para(runsXml(tt, (fm || []).map(function (r) { return Object.assign({}, r, { s: r.s + cx2.pre.length, e: r.e + cx2.pre.length }); }), { b: cx2.b, i: cx2.i, u: cx2.u }), '<w:jc w:val="' + cx2.jc + '"/>'); if (THK.el.get(d, b.t).col === 'r') r = pp; else l = pp; } else l = para(runsXml(x, fm));
        rows += '<w:tr><w:trPr><w:cantSplit/></w:trPr>' + cell(l, half) + cell(r, half) + '</w:tr>';
      });
      body += '<w:tbl><w:tblPr><w:tblW w:w="' + (half * 2) + '" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid><w:gridCol w:w="' + half + '"/><w:gridCol w:w="' + half + '"/></w:tblGrid>' + rows + '</w:tbl><w:p/>';
    }
    body += sect('<w:headerReference w:type="default" r:id="rId2"/>' + '') .replace('<w:pgSz', '<w:pgNumType w:start="1"/><w:pgSz'.replace('<w:pgNumType w:start="1"/>', '')).replace('</w:sectPr>', '<w:pgNumType w:start="1"/></w:sectPr>');
    var NS = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
    var doc = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document ' + NS + '><w:body>' + body + '</w:body></w:document>';
    var hdr = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:hdr ' + NS + '><w:p><w:pPr><w:tabs><w:tab w:val="right" w:pos="' + (W - mL - mR) + '"/></w:tabs></w:pPr><w:r><w:rPr><w:sz w:val="16"/></w:rPr><w:t xml:space="preserve">' + xe(d.title || '') + (d.hdr ? '  ·  ' + xe(d.hdr) : '') + '</w:t></w:r><w:r><w:tab/></w:r><w:r><w:rPr><w:sz w:val="18"/></w:rPr><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p></w:hdr>';
    var styles = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles ' + NS + '><w:docDefaults><w:rPrDefault><w:rPr>' + fonts + '<w:sz w:val="' + Math.round(fs * 2) + '"/><w:szCs w:val="' + Math.round(fs * 2) + '"/><w:lang w:val="en-IN" w:bidi="ar-SA"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="0" w:line="300" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style></w:styles>';
    var files = {
      '[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/header1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml"/></Types>',
      '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
      'word/_rels/document.xml.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/header" Target="header1.xml"/></Relationships>',
      'word/document.xml': doc, 'word/styles.xml': styles, 'word/header1.xml': hdr
    };
    return zip(files);
  };


  /* ============================================================ EPUB (e-book) export – reflowable, readers add their own page turning, fonts, night mode and bookmarks */
  X.epub = function (d, o) {
    o = o || {}; var L = THK.lang(d.lang), bcp = L.bcp || 'en', rtl = !!L.rtl, id = 'urn:uuid:' + (d.id || 'finnish') + '-' + Date.now().toString(36), title = d.title || 'Untitled';
    function bu(h, f) { var fm = (f || []).map(function (r) { return { s: r.s, e: r.e, b: r.b, i: r.i, u: r.u }; }); return THK.richHtml(h || '', fm).replace(/\n/g, '<br/>').replace(/&nbsp;/g, '&#160;'); }
    var HEAD = function (t) { return '<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html><html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" lang="' + bcp + '" xml:lang="' + bcp + '"' + (rtl ? ' dir="rtl"' : '') + '><head><meta charset="utf-8"/><title>' + xe(t) + '</title><link rel="stylesheet" type="text/css" href="style.css"/></head><body>'; };
    var chapters = [], curC = null, n = 0, sn = 0;
    (d.blocks || []).forEach(function (b) {
      if (b.t === 'scene') sn++;
      if (b.t === 'note') return; var x = b.x || ''; if (!x.trim() && !(b.x2 || '').trim()) return;
      if (b.t === 'scene' && !((b.fm || {}).x || []).length) x = THK.stripSn(x);
      if (b.t === 'scene' || !curC) { n++; curC = { id: 'c' + ('000' + n).slice(-3), title: b.t === 'scene' ? (sn + '. ' + x + (b.x2 ? ' – ' + b.x2 : '')).trim() : 'Opening', html: '' }; chapters.push(curC); }
      var t = x, fm = (b.fm || {}).x; if (b.t === 'paren') { t = '(' + x.replace(/^\(|\)$/g, '') + ')'; fm = null; } else if (b.t === 'scene' && b.x2) { t = x + ' – ' + b.x2; fm = null; }
      var ct = THK.el && THK.el.get(d, b.t); if (ct) { t = ct.pre + (ct.up ? t.toUpperCase() : t) + ct.suf; if (fm) fm = fm.map(function (r) { return Object.assign({}, r, { s: r.s + ct.pre.length, e: r.e + ct.pre.length }); }); }
      var tag = b.t === 'scene' ? 'h2' : 'p', al = b.al ? ' style="text-align:' + b.al + '"' : '';
      curC.html += '<' + tag + ' class="' + b.t + '"' + al + '>' + (b.t === 'scene' ? '<span class="sn">' + sn + '</span>' : '') + bu(t, fm) + '</' + tag + '>';
    });
    if (!chapters.length) chapters.push({ id: 'c001', title: 'Script', html: '<p class="action"></p>' });
    var css = (d.ct || []).map(function (t) { return '.' + t.id + '{text-align:' + t.al + ';margin:0 ' + t.ind + '% .8em ' + t.ind + '%;' + (t.b ? 'font-weight:bold;' : '') + (t.i ? 'font-style:italic;' : '') + (t.u ? 'text-decoration:underline;' : '') + '}'; }).join('') + 'body{margin:0;padding:0 .4em;line-height:1.5}h1{text-align:center;font-size:1.8em;margin:20% 0 .6em;line-height:1.25}.by{text-align:center;margin:.2em 0}p{margin:0 0 .8em;white-space:pre-wrap;orphans:2;widows:2}h2.scene .sn{font-weight:normal;opacity:.65;margin-right:.9em}h2.scene{font-size:1em;font-weight:bold;text-transform:uppercase;margin:1.6em 0 .8em;page-break-after:avoid;break-after:avoid}.char{margin:1em 0 .1em 22%;font-weight:bold;page-break-after:avoid;break-after:avoid}.paren{margin:0 18% .1em 18%;font-style:italic;page-break-after:avoid;break-after:avoid}.dial{margin:0 10% .8em 10%}.trans{text-align:right;font-weight:bold;margin:1em 0}.shot{font-weight:bold;text-transform:uppercase}';
    var files = { 'mimetype': 'application/epub+zip' };
    files['META-INF/container.xml'] = '<?xml version="1.0" encoding="UTF-8"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>';
    files['OEBPS/style.css'] = css;
    var cover = HEAD(title) + '<h1>' + bu(title, (d.cfm || {}).title) + '</h1>' + (d.writer ? '<p class="by">' + xe(d.writer) + '</p>' : '') + (d.director ? '<p class="by">' + xe(d.director) + '</p>' : '') + '<p class="by">' + xe(d.date || THK.todayStr()) + '</p></body></html>';
    files['OEBPS/cover.xhtml'] = cover;
    chapters.forEach(function (c) { files['OEBPS/' + c.id + '.xhtml'] = HEAD(c.title) + c.html + '</body></html>'; });
    var navItems = chapters.map(function (c) { return '<li><a href="' + c.id + '.xhtml">' + xe(c.title) + '</a></li>'; }).join('');
    files['OEBPS/nav.xhtml'] = HEAD('Contents') + '<nav epub:type="toc" id="toc"><h2>Contents</h2><ol>' + navItems + '</ol></nav></body></html>';
    files['OEBPS/toc.ncx'] = '<?xml version="1.0" encoding="UTF-8"?><ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head><meta name="dtb:uid" content="' + xe(id) + '"/></head><docTitle><text>' + xe(title) + '</text></docTitle><navMap>' + chapters.map(function (c, i) { return '<navPoint id="n' + (i + 1) + '" playOrder="' + (i + 1) + '"><navLabel><text>' + xe(c.title) + '</text></navLabel><content src="' + c.id + '.xhtml"/></navPoint>'; }).join('') + '</navMap></ncx>';
    var man = '<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/><item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/><item id="css" href="style.css" media-type="text/css"/><item id="cover" href="cover.xhtml" media-type="application/xhtml+xml"/>' + chapters.map(function (c) { return '<item id="' + c.id + '" href="' + c.id + '.xhtml" media-type="application/xhtml+xml"/>'; }).join('');
    var spine = '<itemref idref="cover"/>' + chapters.map(function (c) { return '<itemref idref="' + c.id + '"/>'; }).join('');
    files['OEBPS/content.opf'] = '<?xml version="1.0" encoding="UTF-8"?><package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bid"' + (rtl ? ' dir="rtl"' : '') + '><metadata xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:identifier id="bid">' + xe(id) + '</dc:identifier><dc:title>' + xe(title) + '</dc:title><dc:language>' + bcp + '</dc:language>' + (d.writer ? '<dc:creator>' + xe(d.writer) + '</dc:creator>' : '') + '<meta property="dcterms:modified">' + new Date().toISOString().slice(0, 19) + 'Z</meta></metadata><manifest>' + man + '</manifest><spine toc="ncx"' + (rtl ? ' page-progression-direction="rtl"' : '') + '>' + spine + '</spine></package>';
    return zip(files);
  };

  /* ============================================================ customise sheet */
  X.customDlg = function () {
    var b = el('div', '');
    head(b, 'Writing'); var r1 = rowOf(b);
    function tgl(label, key, def, after) { var p = pill(label, def ? S[key] !== false : !!S[key], function () { S[key] = def ? (S[key] === false) : !S[key]; A.saveS(); p.classList.toggle('on', def ? S[key] !== false : !!S[key]); applyTw(); if (after) after(); }); return p; }
    r1.appendChild(tgl('Typewriter scrolling', 'tw', false)); r1.appendChild(tgl('Dim other lines in focus mode', 'fdim', true));
    b.appendChild(el('div', 'xsub', 'Typewriter scrolling keeps the line you are typing near the middle of the screen. Focus mode hides everything except the page.'));
    var r2 = rowOf(b); r2.appendChild(pill('Focus mode', false, function () { closeAll(); X.focus(true); })); r2.appendChild(pill('Quick phrases…', false, function () { closeAll(); X.snipsDlg(); }));
    head(b, 'Look'); var r3 = rowOf(b); r3.appendChild(pill('Theme, accent & wallpaper…', false, function () { closeAll(); A.themeDlg(); })); r3.appendChild(pill('Cover style…', false, function () { closeAll(); X.coverDlg(); })); r3.appendChild(pill('Paper size…', false, function () { closeAll(); X.paperDlg(); })); r3.appendChild(pill('Watermark & header…', false, function () { closeAll(); X.wmDlg(); }));
    head(b, 'Safety'); var r4 = rowOf(b); r4.appendChild(pill('App lock…', false, function () { closeAll(); X.lockDlg(); })); r4.appendChild(pill('Version history…', false, function () { closeAll(); X.historyDlg(); }));
    function closeAll() { $$('.scrim').forEach(function (s) { s.remove(); }); }
    dlg('Customise', b, [{ l: 'Done', cls: 'pri' }]);
  };

  /* ============================================================ menu items + commands */
  function req(fn) { return function () { if (!cur()) return toast('Open a script first'); fn(); }; }
  X.menu = function () {
    return {
      cover: { l: 'Edit cover page…', fn: X.coverDlg }, paper: { l: 'Paper size…  (' + THK.paperOf(cur()).n + ')', fn: X.paperDlg }, wm: { l: 'Watermark & header…', fn: X.wmDlg }, outline: { l: 'Outline (scene cards)…', fn: X.outline }, history: { l: 'Version history…', fn: X.historyDlg },
      focus: { l: 'Focus mode', k: 'Ctrl+Shift+D', fn: function () { X.focus(true); } }, reading: { l: 'Reading mode', fn: function () { X.reading(true); } }, read: { l: 'Read aloud', fn: function () { X.reading(true, true); } },
      snips: { l: 'Quick phrases…', fn: X.snipsDlg }, custom: { l: 'Customise…', fn: X.customDlg }
    };
  };
  X.cmds = function () { return [['Focus mode', function () { X.focus(true); }], ['Reading mode', function () { X.reading(true); }], ['Read aloud', function () { X.reading(true, true); }], ['Outline (scene cards)', X.outline], ['Quick phrases', X.snipsDlg], ['Version history', X.historyDlg], ['Paper size', X.paperDlg], ['Watermark & header', X.wmDlg], ['Cover style & logo', X.coverDlg], ['Customise', X.customDlg], ['Lock app now', X.lockNow], ['Export Word (.docx)', function () { try { A.deliverBin(A.fname() + '.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', X.docx(cur(), { cover: true })); } catch (er) { toast('Word export failed'); } }]]; };
  /* keep watermark + typewriter in step with the script being shown */
  var _ra = null; (function hook() { var obs = new MutationObserver(function () { X.wmRefresh(); applyTw(); }); var pg = $('#page'); if (pg) obs.observe(pg, { childList: true }); var cv = $('#cover'); if (cv) obs.observe(cv, { childList: true }); })();
  X.accent(); applyTw();
})();
