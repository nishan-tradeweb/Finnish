/* Notes – a separate full-screen rich-text canvas (own storage, same look, theme, language and speech as the script editor). */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, $ = A.$, S = A.S, N = THK.notes = {};
  var note = null, ed = null, saved = null, active = false, tmr = 0, status = 'saved', dirtyFlag = false, fmtOpen = false, fmtPanel = null, tl = { buf: '', len: 0, node: null, off: -1 };
  var SIZES = [12, 14, 16, 18, 20, 24, 28, 32, 40, 48];
  var INKS = ['#111111', '#d32f2f', '#e8590c', '#e0a800', '#2f9e44', '#1c7ed6', '#6741d9', '#c2255c', '#7a7a7a', '#ffffff'];
  var HILITES = ['#fff3a3', '#ffd8a8', '#ffc9c9', '#d3f9d8', '#c5f6fa', '#d0ebff', '#e5dbff', '#eaeaea'];
  var PAPERS = [['#ffffff', 'White'], ['#fbf6e9', 'Cream'], ['#eef2f7', 'Mist'], ['#e9f3ec', 'Sage'], ['#25272e', 'Slate'], ['#000000', 'Black']];

  /* ---------------------------------------------------------------- storage (own database – never mixed with scripts) */
  var DB = {
    db: null,
    init: function () {
      return new Promise(function (res) {
        if (DB.db) return res();
        try { var r = indexedDB.open('finnish-notes', 1); r.onupgradeneeded = function () { r.result.createObjectStore('notes', { keyPath: 'id' }); }; r.onsuccess = function () { DB.db = r.result; res(); }; r.onerror = r.onblocked = function () { res(); }; } catch (e) { res(); }
      });
    },
    all: function () {
      return DB.init().then(function () {
        var ls = []; try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (k.indexOf('finnish.note.') === 0) ls.push(JSON.parse(localStorage.getItem(k))); } } catch (e) { }
        if (!DB.db) return ls;
        return new Promise(function (res) { var q = DB.db.transaction('notes').objectStore('notes').getAll(); q.onsuccess = function () { var m = {}; q.result.concat(ls).forEach(function (n) { if (!m[n.id] || m[n.id].updated < n.updated) m[n.id] = n; }); res(Object.keys(m).map(function (k) { return m[k]; })); }; q.onerror = function () { res(ls); }; });
      });
    },
    put: function (n) {
      return DB.init().then(function () {
        if (!DB.db) { try { localStorage.setItem('finnish.note.' + n.id, JSON.stringify(n)); } catch (e) { } return; }
        return new Promise(function (res) { try { var tx = DB.db.transaction('notes', 'readwrite'); tx.objectStore('notes').put(n); tx.oncomplete = function () { res(); }; tx.onerror = tx.onabort = function () { try { localStorage.setItem('finnish.note.' + n.id, JSON.stringify(n)); } catch (e) { } res(); }; } catch (e) { res(); } });
      });
    },
    del: function (id) {
      try { localStorage.removeItem('finnish.note.' + id); } catch (e) { }
      return DB.init().then(function () { if (!DB.db) return; return new Promise(function (res) { var tx = DB.db.transaction('notes', 'readwrite'); tx.objectStore('notes').delete(id); tx.oncomplete = tx.onerror = function () { res(); }; }); });
    }
  };
  N.DB = DB;

  function blank() {
    var L = THK.lang(S.lang), fo = L.id === 'en' && THK.FONTS.some(function (f) { return f.id === 'Inter'; }) ? 'Inter' : L.def;
    return { id: A.uid(), title: '', html: '', lang: L.id, font: fo, size: 18, lh: 1.6, paper: '#ffffff', created: Date.now(), updated: Date.now() };
  }
  function isEmpty(n) { return !n.title && !/\S/.test((n.html || '').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ')) && !/<img|<li/i.test(n.html || ''); }
  function lum(hex) { var m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return 1; var v = parseInt(m[1], 16); return (0.299 * (v >> 16) + 0.587 * ((v >> 8) & 255) + 0.114 * (v & 255)) / 255; }

  /* ---------------------------------------------------------------- screen */
  function build() {
    var T = $('#nTop'), P = $('#nPage'), AC = $('#nAcc'); if (T.dataset.ok) return; T.dataset.ok = 1; ed = P;
    ed.contentEditable = 'true'; ed.spellcheck = false; ed.className = 'nted'; ed.setAttribute('data-ph', 'Start writing…'); ed.setAttribute('role', 'textbox'); ed.setAttribute('aria-multiline', 'true');
    var home = el('button', 'btn', 'Home'); home.onclick = N.close;
    var tt = el('div', 'ttl'); var ti = el('input', 'ntti'); ti.id = 'ntTitle'; ti.placeholder = 'Untitled note'; ti.maxLength = 80; ti.setAttribute('aria-label', 'Note title');
    ti.oninput = function () { note.title = ti.value; touch(); }; ti.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); ti.blur(); ed.focus(); } };
    var sv = el('small', ''); sv.id = 'ntsv'; tt.appendChild(ti); tt.appendChild(sv);
    var more = el('button', 'btn', 'More'); more.onclick = function (e) { moreMenu(e.currentTarget); };
    T.appendChild(home); T.appendChild(tt); T.appendChild(more);
    var sp = el('button', 'btn', 'Speak'); sp.id = 'ntSpeak'; sp.title = 'Speak to type – writes in the language chosen on the right'; sp.onmousedown = function (e) { e.preventDefault(); }; sp.onclick = dictate;
    var fm = el('button', 'btn', 'Format'); fm.id = 'ntFmtBtn'; fm.onmousedown = function (e) { e.preventDefault(); }; fm.onclick = toggleFmt;
    var lg = el('button', 'btn', ''); lg.id = 'ntLang'; lg.title = 'Writing language'; lg.onmousedown = function (e) { e.preventDefault(); }; lg.onclick = function (e) { A.langMenu(e.currentTarget); };
    AC.appendChild(sp); AC.appendChild(fm); AC.appendChild(lg);
    wire();
  }
  function setStatus(s) { status = s; var e = $('#ntsv'); if (e) { e.textContent = s === 'saved' ? '● Saved' : '○ Saving…'; e.style.color = s === 'saved' ? '#30d158' : '#ff9f0a'; } }
  function touch() { dirtyFlag = true; setStatus('saving'); clearTimeout(tmr); tmr = setTimeout(persist, 650); }
  function persist() {
    clearTimeout(tmr); if (!note) return Promise.resolve();
    note.html = ed.innerHTML; note.updated = Date.now();
    if (isEmpty(note)) { dirtyFlag = false; setStatus('saved'); return DB.del(note.id); }
    return DB.put(note).then(function () { dirtyFlag = false; setStatus('saved'); try { S.lastNote = note.id; A.saveS(); } catch (e) { } });
  }
  function look() {
    if (!note) return; var L = THK.lang(note.lang || S.lang), s = $('#nt').style, dark = lum(note.paper) < 0.45;
    THK.loadFont(note.font);
    s.setProperty('--pagec', note.paper || '#fff'); s.setProperty('--textc', dark ? '#f2f2f2' : '#101010'); s.setProperty('--ntf', THK.fontStack(note.font)); s.setProperty('--ntfs', (note.size || 18) + 'px'); s.setProperty('--ntlh', note.lh || 1.6);
    ed.dir = L.rtl ? 'rtl' : 'ltr'; ed.lang = L.bcp || 'en';
    var l = $('#ntLang'); if (l) { l.textContent = THK.lang(S.lang).native; l.classList.toggle('on', !!S.ml); }
  }
  function load(n) {
    note = n; ed.innerHTML = n.html || ''; $('#ntTitle').value = n.title || ''; look(); setStatus('saved'); dirtyFlag = false; tl.buf = ''; $('#nScroll').scrollTop = 0; if (fmtOpen) drawFmt();
  }
  N.open = function (id) {
    build(); active = true; A.show('nt');
    var go = function (n) { load(n); };
    DB.all().then(function (all) {
      all.sort(function (a, b) { return b.updated - a.updated; });
      var n = (id && all.filter(function (x) { return x.id === id; })[0]) || (!id && all.filter(function (x) { return x.id === S.lastNote; })[0]) || (!id && all[0]) || blank();
      go(n);
    });
  };
  N.close = function () {
    var fin = function () { active = false; closeFmt(); A.renderHome(); }; if (!note) return fin();
    persist().then(fin);
  };
  N.onLang = function () {
    if (!active || !note) return; var L = THK.lang(S.lang); note.lang = L.id;
    if (!THK.fontsFor(L.id, false).some(function (f) { return f.id === note.font; })) note.font = L.def;
    look(); if (fmtOpen) drawFmt(); touch();
  };
  THK.phon = { type: function (c) { phon(c); }, back: function () { phonBack(); }, st: tl };
  N.refresh = function () { if (active && note) look(); };
  N.newNote = function () { persist().then(function () { load(blank()); setTimeout(function () { ed.focus(); }, 60); }); };

  /* ---------------------------------------------------------------- editing */
  function wire() {
    document.addEventListener('selectionchange', function () {
      if (!active) return; var s = getSelection(); if (!s.rangeCount) return; var r = s.getRangeAt(0); if (ed.contains(r.commonAncestorContainer)) { saved = r.cloneRange(); if (fmtOpen) refreshState(); }
    });
    ed.addEventListener('input', function () { touch(); caretIntoView(); if (fmtOpen) refreshState(); });
    ed.addEventListener('paste', function (e) { e.preventDefault(); var t = (e.clipboardData || window.clipboardData).getData('text/plain'); if (t) document.execCommand('insertText', false, t); });
    ed.addEventListener('keydown', onKey);
    ed.addEventListener('beforeinput', function (e) { if (e.inputType === 'insertFromDrop') e.preventDefault(); });
    ed.addEventListener('click', function (e) {
      var li = e.target.closest && e.target.closest('ul.ckl > li'); if (!li || !ed.contains(li)) return;
      var r = li.getBoundingClientRect(), x = (document.documentElement.dir === 'rtl' || ed.dir === 'rtl') ? r.right - e.clientX : e.clientX - r.left;
      if (x < 30) { li.classList.toggle('done'); touch(); }
    });
    ed.addEventListener('blur', function () { if (dirtyFlag) persist(); });
    document.addEventListener('visibilitychange', function () { if (active && document.hidden && dirtyFlag) persist(); });
    window.addEventListener('pagehide', function () { if (active && dirtyFlag) persist(); });
  }
  function caretIntoView() {
    var s = getSelection(); if (!s.rangeCount) return; var r = s.getRangeAt(0).cloneRange(); r.collapse(false); var b = r.getClientRects()[0] || (r.startContainer.nodeType === 1 && r.startContainer.getBoundingClientRect()); if (!b) return;
    var sc = $('#nScroll'), sr = sc.getBoundingClientRect(), pad = fmtOpen ? 20 : 70;
    if (b.bottom > sr.bottom - pad) sc.scrollTop += b.bottom - sr.bottom + pad; else if (b.top < sr.top + 10) sc.scrollTop -= sr.top - b.top + 20;
  }
  function onKey(e) {
    var mod = e.ctrlKey || e.metaKey, k = e.key;
    if (mod) {
      var l = k.toLowerCase();
      if (l === 's') { e.preventDefault(); return e.shiftKey ? saveAs() : save(); }
      if (l === 'b' || l === 'i' || l === 'u') { e.preventDefault(); return cmd({ b: 'bold', i: 'italic', u: 'underline' }[l]); }
      if (k === ' ') { e.preventDefault(); return A.langMenu($('#ntLang')); }
      return;
    }
    if (k.length === 1 && S.ml && /[A-Za-z]/.test(k) && !e.altKey) { e.preventDefault(); return phon(k); }
    if (k === 'Backspace' && tl.buf) { var s = getSelection(); if (s.rangeCount && s.anchorNode === tl.node && s.anchorOffset === tl.off && s.isCollapsed) { e.preventDefault(); return phonBack(); } }
    tl.buf = '';
  }
  /* phonetic typing (English letters → the chosen language), same engine as inside the script editor */
  function phon(ch) {
    var s = getSelection(); if (!s.rangeCount) return; var r = s.getRangeAt(0);
    if (!r.collapsed) { document.execCommand('delete'); tl.buf = ''; tl.len = 0; s = getSelection(); r = s.getRangeAt(0); }
    var n = r.startContainer, o = r.startOffset;
    if (tl.node !== n || tl.off !== o || !tl.buf) { tl.buf = ''; tl.len = 0; }
    tl.buf += ch; var out = A.trFn()(tl.buf);
    if (tl.len && n.nodeType === 3 && o >= tl.len) { r.setStart(n, o - tl.len); s.removeAllRanges(); s.addRange(r); }
    document.execCommand('insertText', false, out); tl.len = out.length; s = getSelection(); tl.node = s.anchorNode; tl.off = s.anchorOffset;
  }
  function phonBack() {
    var s = getSelection(), r = s.getRangeAt(0), n = r.startContainer, o = r.startOffset; tl.buf = tl.buf.slice(0, -1); var out = tl.buf ? A.trFn()(tl.buf) : '';
    if (n.nodeType === 3 && o >= tl.len) { r.setStart(n, o - tl.len); s.removeAllRanges(); s.addRange(r); }
    if (out) document.execCommand('insertText', false, out); else document.execCommand('delete');
    tl.len = out.length; s = getSelection(); tl.node = s.anchorNode; tl.off = s.anchorOffset; if (!tl.buf) tl.node = null;
  }
  function focusEd() {
    if (document.activeElement !== ed) { ed.focus({ preventScroll: true }); }
    if (saved) { var s = getSelection(); s.removeAllRanges(); try { s.addRange(saved); } catch (e) { } }
  }
  function cmd(c, v) { if (!note) return; focusEd(); try { document.execCommand('styleWithCSS', false, c !== 'fontSize'); } catch (e) { } document.execCommand(c, false, v == null ? null : v); touch(); if (fmtOpen) refreshState(); }
  function hasSel() { var s = getSelection(); return s.rangeCount && !s.isCollapsed && ed.contains(s.getRangeAt(0).commonAncestorContainer); }
  function setSize(px) {
    px = Math.max(8, Math.min(120, Math.round(px)));
    focusEd();
    if (hasSel()) {
      document.execCommand('styleWithCSS', false, false); document.execCommand('fontSize', false, '7');
      var made = [];
      [].forEach.call(ed.querySelectorAll('font[size="7"]'), function (f) { var sp = document.createElement('span'); sp.style.fontSize = px + 'px'; while (f.firstChild) sp.appendChild(f.firstChild); f.parentNode.replaceChild(sp, f); made.push(sp); });
      [].forEach.call(ed.querySelectorAll('span[style*="font-size"] span[style*="font-size"]'), function (s2) { s2.style.fontSize = ''; });
      if (made.length) { var rg = document.createRange(); rg.setStartBefore(made[0]); rg.setEndAfter(made[made.length - 1]); var sl = getSelection(); sl.removeAllRanges(); sl.addRange(rg); saved = rg.cloneRange(); }
      touch();
    } else { note.size = px; look(); touch(); }
    if (fmtOpen) refreshState();
  }
  function setFont(f) {
    THK.loadFont(f.id); focusEd();
    if (hasSel()) { document.execCommand('styleWithCSS', false, true); document.execCommand('fontName', false, THK.fontStack(f.id)); touch(); }
    else { note.font = f.id; look(); touch(); }
    if (fmtOpen) refreshState();
  }
  function list(kind) {
    focusEd(); document.execCommand('styleWithCSS', false, false);
    if (kind === 'check') {
      var ul = closest('ul'); if (ul && ul.classList.contains('ckl')) { document.execCommand('insertUnorderedList'); touch(); return; }
      if (!ul) document.execCommand('insertUnorderedList'); ul = closest('ul'); if (ul) ul.classList.add('ckl');
    } else {
      document.execCommand(kind === 'ol' ? 'insertOrderedList' : 'insertUnorderedList');
      var u = closest('ul'); if (u) u.classList.remove('ckl');
    }
    touch(); if (fmtOpen) refreshState();
  }
  function closest(tag) { var s = getSelection(); if (!s.rangeCount) return null; var n = s.anchorNode; while (n && n !== ed) { if (n.nodeType === 1 && n.nodeName.toLowerCase() === tag) return n; n = n.parentNode; } return null; }
  function block(tag) { focusEd(); document.execCommand('formatBlock', false, tag); touch(); if (fmtOpen) refreshState(); }

  /* ---------------------------------------------------------------- speak */
  function dictate() {
    if (!note) return; var L = THK.lang(S.lang), lang = (THK.LOC || {})[S.lang] || 'en-IN', FP = THK.fp(), f = FP && FP.dictate ? FP : null, b = $('#ntSpeak');
    var st = function (on) { b.classList.toggle('on', on); b.textContent = on ? 'Listening…' : 'Speak'; };
    if (b.classList.contains('on')) return;
    var put = function (t) { if (!t) return A.toast('Nothing was heard'); focusEd(); document.execCommand('insertText', false, (/\s$/.test(textBefore()) || !textBefore() ? '' : ' ') + t); touch(); };
    if (f) { st(true); return f.dictate({ lang: lang, prompt: 'Speak in ' + L.name }).then(function (r) { st(false); put(r && r.text); }).catch(function (e) { st(false); if (!e || !/cancel/i.test(String(e.message || e))) A.toast('Speech recognition for ' + L.name + ' is not available on this device – install its voice in Google speech settings'); }); }
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return A.toast('Speaking to type needs the Android app or a browser with speech recognition');
    var rec = new SR(); rec.lang = lang; rec.interimResults = false; rec.maxAlternatives = 1; st(true);
    rec.onresult = function (e) { put(e.results[0][0].transcript); }; rec.onerror = function () { st(false); A.toast('Could not hear anything'); }; rec.onend = function () { st(false); };
    try { rec.start(); } catch (er) { st(false); A.toast('Speaking could not start'); }
  }
  function textBefore() { var s = getSelection(); if (!s.rangeCount || !ed.contains(s.anchorNode)) return ''; var n = s.anchorNode; return n.nodeType === 3 ? n.textContent.slice(0, s.anchorOffset) : ''; }

  /* ---------------------------------------------------------------- format panel */
  function toggleFmt() { fmtOpen ? closeFmt() : openFmt(); }
  function openFmt() { fmtOpen = true; var p = $('#nFmt'); p.hidden = false; drawFmt(); $('#ntFmtBtn').classList.add('on'); }
  function closeFmt() { fmtOpen = false; var p = $('#nFmt'); if (p) p.hidden = true; var b = $('#ntFmtBtn'); if (b) b.classList.remove('on'); }
  function pill(t, fn, cls, title) { var b = el('button', 'btn sm ' + (cls || ''), esc(t)); b.type = 'button'; b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = fn; if (title) b.title = title; return b; }
  function sec(p, t, sub) { p.appendChild(el('div', 'nfh', esc(t) + (sub ? ' <small>' + esc(sub) + '</small>' : ''))); var r = el('div', 'nfr'); p.appendChild(r); return r; }
  function sw(c, fn) { var b = el('button', 'sw'); b.type = 'button'; b.style.background = c; b.title = c; b.onmousedown = function (e) { e.preventDefault(); }; b.onclick = fn; return b; }
  function drawFmt() {
    var p = $('#nFmt'); p.innerHTML = ''; var L = THK.lang(S.lang);
    var top = el('div', 'nft', '<b>Format</b><span>Select text to style only that part. With nothing selected, font and size change the whole note.</span>'); var x = pill('Close', closeFmt, 'pri'); top.appendChild(x); p.appendChild(top);
    var body = el('div', 'nfb'); p.appendChild(body); fmtPanel = body;
    var add = function (t, sub) { return sec(body, t, sub); };
    /* font – only fonts that suit the chosen language, then Latin ones for mixed writing */
    var r = add('Font', L.name); r.classList.add('nff');
    var mine = THK.fontsFor(S.lang, false); if (S.lang !== 'en') mine = mine.concat(THK.fontsFor('en', false).filter(function (f) { return !mine.some(function (m) { return m.id === f.id; }); }).slice(0, 8));
    mine.forEach(function (f) { var b = pill(f.label, function () { setFont(f); }, 'nfont', f.label); b.dataset.f = f.id; b.style.fontFamily = f.stack; THK.loadFont(f.id); r.appendChild(b); });
    r = add('Size'); r.classList.add('nsz');
    var cur = el('span', 'nsv', '18'); cur.id = 'ntSz';
    r.appendChild(pill('A−', function () { setSize(curSize() - 2); }, 'nstep')); r.appendChild(cur); r.appendChild(pill('A+', function () { setSize(curSize() + 2); }, 'nstep'));
    var r2 = el('div', 'nfr'); body.appendChild(r2); SIZES.forEach(function (n) { var b = pill(String(n), function () { setSize(n); }, 'nsmall'); b.dataset.z = n; r2.appendChild(b); });
    r = add('Style');
    [['B', 'bold', 'Bold', 'fb-b'], ['I', 'italic', 'Italic', 'fb-i'], ['U', 'underline', 'Underline', 'fb-u'], ['S', 'strikeThrough', 'Strikethrough', 'fb-s'], ['x²', 'superscript', 'Superscript', ''], ['x₂', 'subscript', 'Subscript', '']].forEach(function (s) { var b = pill(s[0], function () { cmd(s[1]); }, 'nicon ' + s[3], s[2]); b.dataset.c = s[1]; r.appendChild(b); });
    r = add('Heading');
    [['Title', 'h1'], ['Heading', 'h2'], ['Subheading', 'h3'], ['Body', 'p']].forEach(function (h) { var b = pill(h[0], function () { block(h[1]); }); b.dataset.h = h[1]; r.appendChild(b); });
    r = add('Alignment');
    [['Left', 'justifyLeft'], ['Centre', 'justifyCenter'], ['Right', 'justifyRight'], ['Justify', 'justifyFull']].forEach(function (a) { var b = pill(a[0], function () { cmd(a[1]); }); b.dataset.c = a[1]; r.appendChild(b); });
    r = add('Lists & indent');
    [['• Bullets', function () { list('ul'); }, 'ul'], ['1. Numbers', function () { list('ol'); }, 'ol'], ['☑ Checklist', function () { list('check'); }, 'ck'], ['Indent', function () { cmd('indent'); }], ['Outdent', function () { cmd('outdent'); }]].forEach(function (a) { var b = pill(a[0], a[1]); if (a[2]) b.dataset.l = a[2]; r.appendChild(b); });
    r = add('Text colour'); r.classList.add('nsw');
    INKS.forEach(function (c) { r.appendChild(sw(c, function () { cmd('foreColor', c); })); });
    var ci = el('input'); ci.type = 'color'; ci.className = 'swc'; ci.value = '#d32f2f'; ci.title = 'Any colour'; ci.onchange = function () { cmd('foreColor', ci.value); }; ci.onmousedown = function () { if (!hasSel() && saved) { } }; r.appendChild(ci);
    r.appendChild(pill('Auto', function () { cmd('foreColor', note && lum(note.paper) < .45 ? '#f2f2f2' : '#101010'); }));
    r = add('Highlight'); r.classList.add('nsw');
    HILITES.forEach(function (c) { r.appendChild(sw(c, function () { cmd('hiliteColor', c); })); });
    r.appendChild(pill('None', function () { cmd('hiliteColor', 'transparent'); }));
    r = add('Spacing'); [['Tight', 1.3], ['Normal', 1.6], ['Relaxed', 1.9], ['Wide', 2.3]].forEach(function (s) { var b = pill(s[0], function () { note.lh = s[1]; look(); touch(); refreshState(); }); b.dataset.lh = s[1]; r.appendChild(b); });
    r = add('Paper'); r.classList.add('nsw');
    PAPERS.forEach(function (c) { var b = sw(c[0], function () { note.paper = c[0]; look(); touch(); refreshState(); }); b.dataset.p = c[0]; b.title = c[1]; r.appendChild(b); });
    r = add('Tools');
    r.appendChild(pill('Undo', function () { cmd('undo'); })); r.appendChild(pill('Redo', function () { cmd('redo'); })); r.appendChild(pill('Clear formatting', function () { cmd('removeFormat'); }));
    r.appendChild(pill('Insert date', function () { focusEd(); document.execCommand('insertText', false, new Date().toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' })); touch(); }));
    refreshState();
  }
  function curSize() { var s = getSelection(), n = s.rangeCount && s.anchorNode; if (n && ed.contains(n)) { n = n.nodeType === 3 ? n.parentNode : n; var v = parseFloat(getComputedStyle(n).fontSize); if (v) return Math.round(v); } return note ? note.size : 18; }
  function qs(c) { try { return document.queryCommandState(c); } catch (e) { return false; } }
  function refreshState() {
    if (!fmtPanel || !note) return; var q = function (s) { return [].slice.call(fmtPanel.querySelectorAll(s)); };
    q('[data-c]').forEach(function (b) { b.classList.toggle('on', qs(b.dataset.c)); });
    var sz = curSize(); var e = $('#ntSz'); if (e) e.textContent = sz; q('[data-z]').forEach(function (b) { b.classList.toggle('on', +b.dataset.z === sz); });
    var fam = ''; var s = getSelection(); if (s.rangeCount && ed.contains(s.anchorNode)) { var n = s.anchorNode.nodeType === 3 ? s.anchorNode.parentNode : s.anchorNode; fam = (getComputedStyle(n).fontFamily || '').split(',')[0].replace(/['"\s]/g, '').toLowerCase(); }
    q('[data-f]').forEach(function (b) { var f = THK.font(b.dataset.f), nm = f.stack.split(',')[0].replace(/['"\s]/g, '').toLowerCase(); b.classList.toggle('on', fam ? nm === fam : b.dataset.f === note.font); });
    var blk = closest('h1') ? 'h1' : closest('h2') ? 'h2' : closest('h3') ? 'h3' : 'p'; q('[data-h]').forEach(function (b) { b.classList.toggle('on', b.dataset.h === blk); });
    var ul = closest('ul'), ol = closest('ol'); q('[data-l]').forEach(function (b) { var k = b.dataset.l; b.classList.toggle('on', k === 'ck' ? !!(ul && ul.classList.contains('ckl')) : k === 'ul' ? !!(ul && !ul.classList.contains('ckl')) : !!ol); });
    q('[data-lh]').forEach(function (b) { b.classList.toggle('on', +b.dataset.lh === +note.lh); });
    q('[data-p]').forEach(function (b) { b.classList.toggle('on', b.dataset.p === note.paper); });
  }

  /* ---------------------------------------------------------------- More menu, files, export */
  function title() { return (note.title || '').trim() || 'Untitled note'; }
  function save() { persist().then(function () { A.toast('Saved on this device ✓ – open it again from More › Saved notes'); }); }
  function saveAs() {
    A.ask('Save As', 'New name', title(), function (n) {
      if (!n) return; persist().then(function () { var c = JSON.parse(JSON.stringify(note)); c.id = A.uid(); c.title = n; c.created = c.updated = Date.now(); c.html = ed.innerHTML; return DB.put(c).then(function () { load(c); S.lastNote = c.id; A.saveS(); A.toast('Saved as “' + n + '”'); }); });
    }, 'Save');
  }
  function rename() { A.ask('Rename note', 'Title', note.title || '', function (n) { note.title = n || ''; $('#ntTitle').value = note.title; touch(); }, 'Rename'); }
  function del() {
    A.confirmD('Delete this note?', '“' + title() + '” will be removed from this device.', function () { var id = note.id; DB.del(id).then(function () { note.html = ''; note.title = ''; dirtyFlag = false; load(blank()); A.toast('Note deleted'); }); }, 'Delete');
  }
  function moreMenu(a) {
    var ae = document.activeElement; if (ae === ed || ae === $('#ntTitle')) ae.blur();
    A.menu(a, [
      { hd: 'Notes' }, { l: 'New note', fn: N.newNote }, { l: 'Saved notes', fn: savedDlg },
      { hr: 1 }, { hd: 'File' }, { l: 'Save', k: 'Ctrl+S', fn: save }, { l: 'Save As', k: 'Ctrl+Shift+S', fn: saveAs }, { l: 'Rename', fn: rename },
      { hr: 1 }, { hd: 'Export' }, { l: 'PDF', fn: exportPdf }, { l: 'Text file (.txt)', fn: exportTxt }, { l: 'Web page (.html)', fn: exportHtml },
      { hr: 1 }, { l: 'Delete note', fn: del }
    ], true);
  }
  function savedDlg() {
    persist().then(function () { return DB.all(); }).then(function (all) {
      all.sort(function (a, b) { return b.updated - a.updated; });
      var box = el('div', 'ntl'), d;
      if (!all.length) box.appendChild(el('p', '', 'No saved notes yet. Anything you write is kept here automatically.'));
      all.forEach(function (n) {
        var t = (n.title || '').trim() || 'Untitled note', sn = (n.html || '').replace(/<\/(p|div|li|h\d)>/gi, ' ').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').trim().slice(0, 70);
        var r = el('div', 'sv' + (note && n.id === note.id ? ' cur' : '')); r.innerHTML = '<div class="n"><b>' + esc(t) + '</b><small>' + esc(new Date(n.updated).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) + (sn ? ' · ' + sn : '')) + '</small></div>';
        var x = el('button', 'btn sm', 'Delete'); x.onclick = function (e) { e.stopPropagation(); A.confirmD('Delete “' + t + '”?', 'This note will be removed from this device.', function () { DB.del(n.id).then(function () { if (note && n.id === note.id) { load(blank()); } if (d) d.close(); savedDlg(); }); }, 'Delete'); }; r.appendChild(x);
        r.onclick = function () { d.close(); persist().then(function () { load(n); }); }; box.appendChild(r);
      });
      d = A.dlg('Saved notes', box, [{ l: 'Close' }], { nofocus: true });
    });
  }
  function plainText() { return ed.innerText.replace(/ /g, ' ').replace(/\n{3,}/g, '\n\n'); }
  function fname() { return title().replace(/[\\\/:*?"<>|\n]+/g, ' ').trim() || 'note'; }
  function exportTxt() { persist().then(function () { A.deliver(fname() + '.txt', 'text/plain', title() + '\n\n' + plainText()); }); }
  function pageCss() {
    var dark = lum(note.paper) < .45;
    return '@page{size:A4;margin:18mm 16mm}html,body{margin:0;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{font-family:' + THK.fontStack(note.font) + ';font-size:' + (note.size * 0.75) + 'pt;line-height:' + note.lh + ';color:' + (dark ? '#111' : '#101010') + '}' +
      'h1{font-size:1.7em;margin:.4em 0}h2{font-size:1.35em;margin:.4em 0}h3{font-size:1.15em;margin:.4em 0}p,div{margin:0}ul,ol{margin:.3em 0;padding-left:1.5em}ul.ckl{list-style:none;padding-left:0}ul.ckl li{padding-left:1.6em;position:relative}ul.ckl li::before{content:"☐";position:absolute;left:0}ul.ckl li.done::before{content:"☑"}ul.ckl li.done{text-decoration:line-through;opacity:.6}.nt-title{font-size:1.9em;font-weight:700;margin:0 0 .6em}';
  }
  function usedFonts() { var h = ed.innerHTML, ids = [note.font]; THK.FONTS.forEach(function (f) { var nm = f.stack.split(',')[0].replace(/['"]/g, '').trim(); if (nm && h.indexOf(nm) >= 0 && ids.indexOf(f.id) < 0) ids.push(f.id); }); return ids; }
  function exportPdf() {
    persist().then(function () {
      var d = { title: fname(), lang: note.lang, font: note.font, paper: 'a4' }, html = THK.shell(d, pageCss(), (note.title ? '<div class="nt-title">' + esc(note.title) + '</div>' : '') + '<div>' + ed.innerHTML + '</div>', usedFonts());
      try { THK.printRaw(html, d); } catch (e) { A.toast('PDF export failed: ' + e.message); }
    });
  }
  function exportHtml() {
    persist().then(function () { var d = { title: fname(), lang: note.lang, font: note.font, paper: 'a4' }; A.deliver(fname() + '.html', 'text/html', THK.shell(d, pageCss().replace(/@page\{[^}]*\}/, '') + 'body{max-width:780px;margin:24px auto;padding:0 16px}', (note.title ? '<div class="nt-title">' + esc(note.title) + '</div>' : '') + '<div>' + ed.innerHTML + '</div>', usedFonts())); });
  }

  /* ---------------------------------------------------------------- look (theme-aware, reuses the editor's glass / pill styles) */
  var st = document.createElement('style');
  st.textContent =
    '#nt{padding:0;display:flex;flex-direction:column;overflow:hidden}' +
    '#nSheet{width:min(100%,1100px);padding:0;display:flex;flex-direction:column;margin:0 auto;min-height:100%}' +
    '#nWork{flex:1;min-height:0;display:flex;padding:8px}#nScroll{flex:1;min-width:0;overflow:auto;border-radius:22px;padding:0;overscroll-behavior:contain;display:flex}' +
    '#nPage.nted{flex:1 0 auto;min-height:60vh;outline:none;white-space:normal;word-wrap:break-word;overflow-wrap:anywhere;font-family:var(--ntf,var(--font));font-size:var(--ntfs,18px);line-height:var(--ntlh,1.6);caret-color:var(--acc);padding:clamp(18px,5vw,48px) clamp(16px,5vw,56px) 90px;-webkit-user-modify:read-write;user-modify:read-write;border-radius:22px}' +
    '#nPage.nted:empty::before{content:attr(data-ph);opacity:.35;pointer-events:none}' +
    '.nted h1{font-size:1.8em;line-height:1.25;margin:.3em 0}.nted h2{font-size:1.4em;line-height:1.3;margin:.3em 0}.nted h3{font-size:1.15em;margin:.3em 0}.nted p,.nted div{margin:0}.nted ul,.nted ol{margin:.3em 0;padding-inline-start:1.5em}' +
    '.nted ul.ckl{list-style:none;padding-inline-start:0}.nted ul.ckl>li{position:relative;padding-inline-start:1.8em;min-height:1.4em}.nted ul.ckl>li::before{content:"";position:absolute;inset-inline-start:.15em;top:.32em;width:.95em;height:.95em;border:2px solid currentColor;border-radius:.3em;opacity:.55;box-sizing:border-box;cursor:pointer}' +
    '.nted ul.ckl>li.done::before{background:var(--acc);border-color:var(--acc);opacity:1;box-shadow:inset 0 0 0 2px var(--pagec,#fff)}.nted ul.ckl>li.done{text-decoration:line-through;opacity:.62}' +
    '#nTop .ttl{display:flex;flex-direction:column;align-items:center;text-align:center;cursor:default;padding:2px 6px}#nTop .ntti{width:100%;min-width:0;border:0;outline:0;background:transparent;color:var(--ink);font:inherit;font-weight:700;text-align:center;text-overflow:ellipsis;padding:2px 4px}#nTop .ntti::placeholder{color:var(--ink2);opacity:.8}' +
    '#nTop .ttl small{text-align:center;display:block;font-size:11px;font-weight:500}' +
    '#nAcc .btn{flex:1 1 0}' +
    '#nFmt{margin:0 8px 8px;border-radius:26px;display:flex;flex-direction:column;max-height:52vh;max-height:min(52vh,560px);overflow:hidden;z-index:6}' +
    '#nFmt .nft{display:flex;align-items:center;gap:10px;padding:12px 14px 8px}#nFmt .nft b{font-size:16px}#nFmt .nft span{flex:1;font-size:11.5px;color:var(--ink2);line-height:1.3}' +
    '#nFmt .nfb{overflow:auto;padding:2px 14px 14px;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;touch-action:pan-y}' +
    '#nFmt .nfh{font-size:11px;text-transform:uppercase;letter-spacing:.6px;color:var(--ink2);margin:12px 4px 6px;font-weight:600}#nFmt .nfh small{text-transform:none;letter-spacing:0;font-weight:400;opacity:.8;margin-left:4px}' +
    '#nFmt .nfr{display:flex;flex-wrap:wrap;gap:6px;align-items:center}#nFmt .nff{max-height:156px;overflow:auto;padding:2px}' +
    '#nFmt .btn{padding:8px 14px}#nFmt .nfont{font-size:15px;max-width:100%;white-space:nowrap}#nFmt .nsmall{min-width:44px;padding:7px 8px}#nFmt .nicon{min-width:44px;padding:8px 10px}#nFmt .nstep{min-width:50px}#nFmt .nsv{min-width:38px;text-align:center;font-weight:700}' +
    '#nFmt .fb-b{font-weight:800}#nFmt .fb-i{font-style:italic}#nFmt .fb-u{text-decoration:underline}#nFmt .fb-s{text-decoration:line-through}' +
    '#nFmt .nsw .sw{width:30px;height:30px;border-radius:50%;border:2px solid var(--edge);padding:0;cursor:pointer;flex:0 0 30px}#nFmt .nsw .sw[data-p]{width:38px;border-radius:12px}#nFmt .nsw .sw[data-p].on{outline:3px solid var(--acc);outline-offset:2px}#nFmt .swc{width:38px;height:30px;border:0;padding:0;background:none;border-radius:50%}' +
    '.ntl{display:flex;flex-direction:column;gap:8px;max-height:56vh;overflow:auto}.ntl .sv.cur{outline:2px solid var(--acc)}.ntl .sv .btn{flex:0 0 auto}';
  document.head.appendChild(st);
  window.addEventListener('resize', function () { if (active) caretIntoView(); });
})();
