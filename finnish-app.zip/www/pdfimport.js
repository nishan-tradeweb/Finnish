/* PDF import – reads the real text of a screenplay PDF (offline, bundled pdf.js) and rebuilds scenes, action, characters,
   dialogue, parentheticals and transitions from where each line sits on the page. Works for Standard and Two Column layouts
   and for every language in the app, as long as the PDF contains real text (not a scan, and not glyph-shape-only fonts). */
(function () {
  'use strict';

  /* ------------------------------------------------------------------ pdf.js loader */
  var lib = null;
  function url(p) { return new URL(p, document.baseURI).href; }
  function load() {
    if (lib) return Promise.resolve(lib);
    return import(url('vendor/pdfjs/pdf.min.js')).then(function (m) { m.GlobalWorkerOptions.workerSrc = url('vendor/pdfjs/pdf.worker.min.js'); lib = m; return m; });
  }

  /* ------------------------------------------------------------------ text → lines */
  var NUMONLY = /^\d{1,4}[A-Z]?\.?$/;
  function pageRows(tc, vw, vh) {
    var runs = [], cur = null;
    tc.items.forEach(function (it) {
      if (typeof it.str !== 'string' || !it.str.length) return;
      if (it.str.indexOf('\u0000') >= 0) it = { str: it.str.replace(/\u0000+/g, '\u25A1'), transform: it.transform, width: it.width, height: it.height };   /* glyphs the PDF could not name: keep a visible mark */
      var tr = it.transform, x = tr[4], y = tr[5], sz = Math.hypot(tr[0], tr[1]) || it.height || 10, w = it.width || 0;
      if (x + w > vw * 1.03 || x < -vw * 0.03 || y < -2 || y > vh + 2 || (Math.abs(tr[1]) > 0.3 * sz && Math.abs(tr[0]) < 0.9 * sz)) return;   /* watermarks / rotated stamps / text outside the page */
      if (!it.str.trim()) { if (cur && Math.abs(y - cur.y) <= 0.4 * Math.max(sz, cur.sz)) cur.sp = true; else if (cur) { runs.push(cur); cur = null; } return; }   /* spaces never stretch a run */
      if (cur && Math.abs(y - cur.y) <= 0.4 * Math.max(sz, cur.sz)) {
        var gap = Math.max(x - cur.x1, cur.x0 - (x + w)), brk = gap > 0.06 * vw || (NUMONLY.test(it.str.trim()) && x + w <= cur.x0 + 1) || (NUMONLY.test(cur.t.trim()) && (gap > 0.5 * sz || cur.sp)) || (NUMONLY.test(it.str.trim()) && x > 0.89 * vw && gap > 0.5 * sz);
        if (!brk) {
          cur.t += ((cur.sp || gap > 0.22 * sz) && !/\s$/.test(cur.t) && !/^\s/.test(it.str) ? ' ' : '') + it.str; cur.sp = false;
          cur.x0 = Math.min(cur.x0, x); cur.x1 = Math.max(cur.x1, x + w); cur.sz = Math.max(cur.sz, sz); return;
        }
      }
      if (cur) runs.push(cur);
      cur = { t: it.str, x0: x, x1: x + w, y: y, sz: sz };
    });
    if (cur) runs.push(cur);
    runs.forEach(function (r) { r.t = fixIndic(r.t.replace(/\s+$/, '').replace(/^\s+/, '')); if (/[\u2E80-\u2FDF\uFB50-\uFEFF\uFF00-\uFFEF]/.test(r.t)) r.t = r.t.normalize('NFKC'); });
    runs = runs.filter(function (r) { return r.t; });
    /* runs on the same height become one row (two column pages put action and dialogue on the same line) */
    runs.sort(function (a, b) { return b.y - a.y; });
    var rows = [];
    runs.forEach(function (r) {
      var last = rows[rows.length - 1];
      if (last && Math.abs(last.y - r.y) <= 0.4 * Math.max(last.sz, r.sz)) { last.segs.push(r); last.sz = Math.max(last.sz, r.sz); } else rows.push({ y: r.y, sz: r.sz, segs: [r] });
    });
    rows.forEach(function (r) { r.segs.sort(function (a, b) { return a.x0 - b.x0; }); });
    return { w: vw, h: vh, rows: rows };
  }

  /* ------------------------------------------------------------------ language of the text */
  var STOP = {
    en: 'the and to of is you he she it in that was for with this have not but are', es: 'el la de que y en los un una es no por con para se las del', fr: 'le la les de des et que est un une pas je vous nous dans pour',
    de: 'der die das und ist nicht ich du ein eine zu mit den von sie er', it: 'il di che e la non un una per sono con le del gli ma', tr: 'bir ve bu ne için ben sen de da mi çok ama değil', id: 'yang dan di itu ini aku kamu tidak dengan untuk dari ada saya', tl: 'ang ng sa na ako ikaw siya mga ay hindi ito mo ka'
  };
  THK._pageRows = pageRows;
  THK._pdfLoad = function () { return load(); };
  /* finnish PDFs carry the whole script (invisible 1-pixel link) so they come back exactly, in every language */
  THK.FNX = 'https://finnish.invalid/#FNX1.';
  THK.pdfPayload = function (d) {
    var o = {}; Object.keys(d).forEach(function (k) { if (k === 'id' || k === '_h' || k === 'created' || k === 'updated') return; if (k === 'logo' && String(d[k]).length > 200000) return; if (k === 'cl' && d.cl) { var c2 = JSON.parse(JSON.stringify(d.cl)), big = function (s) { return typeof s === 'string' && s.length > 150000; }; if (c2.bg && big(c2.bg.img)) delete c2.bg.img; (c2.items || []).forEach(function (it) { if (big(it.src)) { it.hide = 1; delete it.src; } }); o.cl = c2; return; } o[k] = d[k]; });
    return THK.FNX + btoa(unescape(encodeURIComponent(JSON.stringify(o)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  };
  THK.detectLang = function (text) {
    text = String(text || '').slice(0, 6000); var n = {}, k;
    var R = { ml: /[ഀ-ൿ]/g, ta: /[஀-௿]/g, te: /[ఀ-౿]/g, kn: /[ಀ-೿]/g, hi: /[ऀ-ॿ]/g, bn: /[ঀ-৿]/g, gu: /[઀-૿]/g, pa: /[਀-੿]/g, th: /[฀-๿]/g, ko: /[ᄀ-ᇿ㄰-㆏가-힯]/g, kana: /[぀-ヿ]/g, han: /[一-鿿]/g, ar: /[؀-ۿݐ-ݿ]/g, ru: /[Ѐ-ӿ]/g };
    for (k in R) n[k] = (text.match(R[k]) || []).length;
    var best = '', bv = 0; for (k in n) if (n[k] > bv) { bv = n[k]; best = k; }
    var letters = (text.match(/[A-Za-zÀ-ɏ]/g) || []).length;
    if (bv >= 8 && bv * 2 >= letters) {
      if (best === 'kana') return 'ja'; if (best === 'han') return n.kana > 0 ? 'ja' : 'zh';
      if (best === 'hi') return /ळ/.test(text) ? 'mr' : 'hi';
      if (best === 'bn') return /[ৰৱ]/.test(text) ? 'as' : 'bn';
      return best;
    }
    var words = text.toLowerCase().match(/[a-zÀ-ɏ']+/g) || [], bestL = 'en', bs = 0;
    for (k in STOP) { var set = {}; STOP[k].split(' ').forEach(function (w) { set[w] = 1; }); var sc = 0; words.forEach(function (w) { if (set[w]) sc++; }); if (k !== 'en') sc *= 1.15; if (sc > bs) { bs = sc; bestL = k; } }
    return bs >= 4 ? bestL : 'en';
  };

  /* ------------------------------------------------------------------ rules */
  var SC_LATIN = /^(?:#?\d{1,4}[A-Z]?#?\s*[.)\-:]?\s*)?(?:INT|EXT|EST|I\s*\/\s*E|INT\.?\s*\/\s*EXT\.?|INNEN|AUSSEN|INTERIEUR|EXTERIEUR|INTÉRIEUR|EXTÉRIEUR|INTERNO|ESTERNO|INTERIOR|EXTERIOR|DALAM|LUAR|İÇ|DIŞ|ВНУТР|НАТ|ИНТ|ЭКСТ|SCENE|SCENA|ESCENA|SZENE|SCÈNE|SAHNE|ADEGAN|EKSENA|СЦЕНА|CENA)(?![A-Za-zÀ-ɏ])/i;
  var SC_OTHER = /^(?:#?\d{1,4}[A-Z]?#?\s*[.)\-:]?\s*)?(?:സീൻ|രംഗം|ഉ\s*ൾ|പു\s*റം|காட்சி|సన్నివేశం|ದೃಶ್ಯ|দৃশ্য|દૃશ્ય|ਦ੍ਰਿਸ਼|दृश्य|ฉาก|씬|장면|場面|シーン|场景|場景|內景|外景|内景|外景|室内|室外|屋内|屋外|مشهد|داخلي|خارجي)/;
  var TRANS = /(?:^|\s)(?:CUT TO|FADE (?:IN|OUT|TO)|DISSOLVE TO|SMASH CUT|MATCH CUT|JUMP CUT|WIPE TO|CUT)\s*[:.]?$|TO:$|^(?:കട്ട്|ഫെയ്ഡ്)|^(?:FADE (?:IN|OUT)[:.]?)$/;
  var MORE = /^\(?\s*(?:MORE|CONT['’]?D\.?|CONTINUED|CONT\.?)\s*\)?\s*[:.]?$/i;
  var CJK = /[぀-ヿ㐀-鿿가-힯฀-๿]/;
  var SC_RTL = /[\u0590-\u08FF][\s\S]{0,80}\s(?:INT|EXT|I\/E)\.?\s*$/;   /* right-to-left PDFs give the heading in visual order, so INT./EXT. ends the line */
  function isScene(t) { return SC_LATIN.test(t) || SC_OTHER.test(t) || SC_RTL.test(t); }
  function join(a, b) { if (!a) return b; if (CJK.test(a.slice(-1)) && CJK.test(b.charAt(0))) return a + b; if (/-$/.test(a) && /^[a-z]/.test(b)) return a + b; return a + ' ' + b; }
  function upperish(s) { return s === s.toUpperCase() && s !== s.toLowerCase(); }
  function hasCase(s) { return /[A-Za-zÀ-ɏͰ-ϿЀ-ӿ]/.test(s); }
  function cleanName(s) { return s.replace(/[:：]\s*$/, '').replace(/\s*\((?:CONT['’]?D\.?|CONT\.?|MORE)\)\s*$/i, '').replace(/\s+:$/, '').trim(); }
  /* pre-base vowel signs (Malayalam, Tamil, Bengali, Hindi, Gujarati, Punjabi) come out in visual order from many PDFs: move them behind their consonant cluster */
  var IND = [
    { c: '[\\u0D15-\\u0D3A\\u0D7A-\\u0D7F]', v: '\\u0D4D', p: '\\u0D46\\u0D47\\u0D48', two: { '\\u0D46\\u0D3E': '\\u0D4A', '\\u0D47\\u0D3E': '\\u0D4B', '\\u0D46\\u0D57': '\\u0D4C' } },
    { c: '[\\u0B95-\\u0BB9]', v: '\\u0BCD', p: '\\u0BC6\\u0BC7\\u0BC8', two: { '\\u0BC6\\u0BBE': '\\u0BCA', '\\u0BC7\\u0BBE': '\\u0BCB', '\\u0BC6\\u0BD7': '\\u0BCC' } },
    { c: '[\\u0995-\\u09B9\\u09DC-\\u09DF\\u09F0\\u09F1]', v: '\\u09CD', p: '\\u09C7\\u09C8', two: { '\\u09C7\\u09BE': '\\u09CB', '\\u09C7\\u09D7': '\\u09CC' } },
    { c: '[\\u0915-\\u0939\\u0958-\\u095F]', v: '\\u094D', p: '\\u093F', two: {} },
    { c: '[\\u0A95-\\u0AB9]', v: '\\u0ACD', p: '\\u0ABF', two: {} },
    { c: '[\\u0A15-\\u0A39]', v: '\\u0A4D', p: '\\u0A3F', two: {} }
  ].map(function (r) { r.re = new RegExp('(^|[^' + r.c.slice(1, -1) + r.v + '])([' + r.p + '])(' + r.c + '(?:' + r.v + r.c + ')*)(\\u0D3E|\\u0BBE|\\u0BD7|\\u09BE|\\u09D7|\\u0D57)?', 'g'); return r; });
  function fixIndic(t) {
    if (!/[ऀ-෿]/.test(t)) return t;
    IND.forEach(function (r) { t = t.replace(r.re, function (m, pre, sign, cl, post) { var key = post ? sign + post : '', two = key && r.two[key]; return pre + cl + (two || (sign + (post || ''))); }); });
    return t;
  }
  function uid(n) { return Math.random().toString(36).slice(2, 8) + n; }



  /* ------------------------------------------------------------------ text quality */
  var LEG = /[¡-¿À-ÿ∂≤≥≠∏∑√∞‰ƒ˙˚˝˛˜ˆ™]/g, QUOTES = /[‘’“”–—…•]/g;
  var EN = {}; 'the and to of is you he she it in that was for with this have not but are on at as be his her they we what your all can will just so do if me my no yes there from by'.split(' ').forEach(function (w) { EN[w] = 1; });
  THK.pdfQuality = function (pages) {
    var lines = [], n = 0;
    for (var i = 0; i < pages.length && n < 6000; i++) pages[i].rows.forEach(function (r) { if (n++ < 6000) lines.push(r.segs.map(function (s) { return s.t; }).join(' ')); });
    var legacy = 0, tot = 0, lost = 0, letters = 0, indic = 0, badW = 0;
    lines.forEach(function (t) {
      if (t.length < 6) return; tot++;
      var sym = (t.replace(QUOTES, '').match(LEG) || []).length, lt = (t.match(/[A-Za-z]/g) || []).length;
      var words = t.toLowerCase().match(/[a-z']+/g) || [], en = 0; words.forEach(function (w) { if (EN[w]) en++; });
      if (lt >= 5 && sym / (lt + sym) > 0.04 && en <= words.length * 0.12) legacy++;
      lost += (t.match(/□/g) || []).length; letters += t.length;
      t.split(/\s+/).forEach(function (w) { if (!/[ऀ-෿]/.test(w)) return; indic++; if (/^[ऀ-ःऺ-ॏॗॢॣംഃാ-്ൗൢൣ]/.test(w.replace(/^[^ऀ-෿]+/, '')) || /[ऀ-෿][0-9A-Za-z\/:;<>@#~^|\\{}][ऀ-෿]/.test(w) || /□/.test(w)) badW++; });
    });
    return { legacy: tot > 20 && legacy > tot * 0.25, lost: lost, lostRatio: letters ? lost / letters : 0, badWords: indic ? badW / indic : 0, indicWords: indic };
  };

  /* ------------------------------------------------------------------ standard layout classifier (learns this PDF's own indents) */
  var TRANS3 = /^[A-Z][A-Z ]{0,24}\b(?:CUT|FADE|DISSOLVE|WIPE|SMASH|MATCH|BLACK|WHITE)\b[A-Z ]{0,16}[:.]$/;
  var TRANS2 = /^[-–—(\s]*(?:cut(?:\s*back)?\s*to|dissolve\s*to|fade\s*(?:in|out|to)|match\s*cut|smash\s*cut|jump\s*cut|time\s*cut|flash\s*(?:back|forward)(?:\s*to)?|back\s*to|end\s*(?:flash\s*back|montage)|montage|later|title\s*card|intercut(?:\s*with)?)\b[^a-z0-9]{0,6}$/i;
  function nameLike(t) {
    var s = t.replace(/\s*\([^)]*\)\s*$/, '').replace(/[:：]\s*$/, '').trim();
    if (!s || s.length > 34 || /^\d/.test(s) || s.split(/\s+/).length > 4) return false;
    if (/[.!?…।。！？؟,;]$/.test(s)) return false;
    return hasCase(s) ? upperish(s) : true;
  }
  function near(a, b, tol) { return Math.abs(a - b) <= tol; }
  function stdClassify(flat, L, cw, R, m, push, appendTo, headOf, getBlocks) {
    var N = flat.length, tol = Math.max(5, cw * 0.014);
    var ln = flat.map(function (r, i) {
      var sg = r.segs;
      if (sg.length >= 2 && NUMONLY.test(sg[sg.length - 1].t) && sg[sg.length - 1].x0 - sg[sg.length - 2].x1 > cw * 0.06) sg = sg.slice(0, -1);
      if (sg.length >= 2 && NUMONLY.test(sg[0].t) && sg[1].x0 - sg[0].x1 > cw * 0.06 && sg[0].x1 <= L + cw * 0.02) sg = sg.slice(1);
      r = { segs: sg, gap: r.gap, y: r.y };
      var t = r.segs.map(function (s) { return s.t; }).reduce(join, ''), x0 = r.segs[0].x0, x1 = r.segs[r.segs.length - 1].x1;
      return { i: i, t: t, x0: x0, x1: x1, c: (x0 + x1) / 2, brk: r.gap > m * 1.35, y: r.y };
    });
    ln.forEach(function (l) { l.sc = isScene(l.t) && l.t.length <= 120; l.tr = !l.sc && l.t.length <= 34 && (TRANS.test(l.t) && (upperish(l.t) || !hasCase(l.t)) || TRANS2.test(l.t) || TRANS3.test(l.t)); });
    var colonRows = ln.filter(function (l) { return !l.sc && /^[^\s:：]{1,24}(\s[^\s:：]{1,18}){0,2}\s*[:：]\s+\S/.test(l.t); }).length;
    var indented = ln.filter(function (l) { return (l.x0 - L) / cw >= 0.07; }).length, useColon = colonRows >= 3 && indented < 3;
    /* ---- pass 1: clear character cues (short caps/caseless line, directly followed by text that sits to its left or a parenthetical) */
    function nextTight(l) { var q = ln[l.i + 1]; return q && !q.brk && !q.sc && !q.tr ? q : null; }
    function cueStrict(l) {
      if (l.sc || l.tr || !nameLike(l.t)) return false;
      var q = nextTight(l); if (!q) return false;
      return q.x0 <= l.x0 - 6 || /^\(/.test(q.t) || (Math.abs(q.c - l.c) <= tol * 2 && l.x0 - L > cw * 0.1 && q.x0 - L > cw * 0.1);
    }
    var chars = ln.filter(function (l) { return cueStrict(l) && (l.brk || l.i === 0 || !ln[l.i - 1] || true); });
    var cx0 = {}, cc = {}, dx = {}, px = {};
    chars.forEach(function (l) { var k = Math.round(l.x0 / 4); cx0[k] = (cx0[k] || 0) + 1; var k2 = Math.round(l.c / 4); cc[k2] = (cc[k2] || 0) + 1; var q = nextTight(l); if (q) { var kq = Math.round(q.x0 / 4); (/^\(/.test(q.t) ? px : dx)[kq] = ((/^\(/.test(q.t) ? px : dx)[kq] || 0) + 1; } });
    function modes(h, frac) { var tot = 0, k; for (k in h) tot += h[k]; var out = []; for (k in h) if (h[k] >= Math.max(3, tot * frac)) out.push(+k * 4); return out; }
    var charX = modes(cx0, 0.08), centX = modes(cc, 0.25), dialX = modes(dx, 0.08), parX = modes(px, 0.1);
    var centred = chars.length >= 8 && charX.length > 6 || (centX.length && centX.length <= 2 && charX.length === 0);
    function inSet(x, set, tl) { return set.some(function (v) { return near(x, v, tl); }); }
    function isChar(l) {
      if (cueStrict(l)) return 0.93;
      if (l.sc || l.tr || !l.brk && l.i > 0 && false) return 0;
      var q = nextTight(l); if (!q) return 0;
      /* mixed-case names (Word scripts): must sit where the other character cues sit */
      var s = l.t.replace(/\s*\([^)]*\)\s*$/, '').replace(/[:：]\s*$/, '').trim();
      if (s.length > 30 || s.split(/\s+/).length > 4 || /[.!?…,;]$/.test(s) || /^\d/.test(s)) return 0;
      if (l.brk && (inSet(l.x0, charX, tol) || (centred && inSet(l.c, centX, tol * 1.6))) && (q.x0 <= l.x0 + 2 || /^\(/.test(q.t))) return 0.72;
      /* no indents at all: a caps line alone above text */
      var pv = ln[l.i - 1], prevEnd = !pv || /[.!?…"”')\]—-]$/.test(pv.t) || pv.sc || pv.tr;
      if ((l.brk || prevEnd) && nameLike(l.t) && hasCase(s) && upperish(s) && near(q.x0, l.x0, tol) && !(hasCase(q.t) && upperish(q.t.replace(/\([^)]*\)/g, '')))) return 0.6;
      return 0;
    }
    var flushDial = dialX.length > 0 && near(dialX[0], L, tol * 1.5), after = '', c;
    ln.forEach(function (l, i) {
      var t = l.t, last = getBlocks()[getBlocks().length - 1];
      function P(type, txt, cf, x2) { var b = push(type, txt, x2); b.c = cf; b.k = Math.round(l.x0 / 8); after = type; return b; }
      if (l.sc) { P('scene', headOf(t), 0.97); return; }
      if (l.tr || ((l.x0 - L) / cw > 0.45 && l.x1 >= R - cw * 0.06 && t.length <= 30 && (upperish(t) || !hasCase(t)) && !nextTight(l))) { P('trans', t.replace(/^[-–—\s]+|[-–—\s]+$/g, '').replace(/[:：]\s*$/, ':'), l.tr ? 0.92 : 0.7); return; }
      if (useColon) { var cm = t.match(/^([^\s:：]{1,24}(?:\s[^\s:：]{1,18}){0,2})\s*[:：]\s+([\s\S]+)$/); if (cm) { P('char', cleanName(cm[1]), 0.85); P('dial', cm[2], 0.85); return; } }
      if ((c = isChar(l))) { P('char', cleanName(t), c); return; }
      var inDial = after === 'char' || after === 'paren' || (after === 'dial' && !l.brk);
      if (inDial) {
        if (/^\(/.test(t) && (after !== 'dial' || near(l.x0, parX.length ? parX[0] : l.x0, tol * 2) || /\)$/.test(t) && t.length < 60)) { var pm = t.match(/^\(\s*([^)]*?)\s*\)\s*(.*)$/); if (pm) { P('paren', pm[1], 0.9); if (pm[2]) P('dial', pm[2], 0.85); } else P('paren', t.replace(/^\(\s*/, ''), 0.6); return; }
        var okX = flushDial || l.x0 > L + cw * 0.04 || after !== 'dial';
        if (okX) { if (after === 'dial' && last && last.t === 'dial') { appendTo(last, t); } else P('dial', t, dialX.length && inSet(l.x0, dialX, tol * 2) ? 0.95 : 0.7); return; }
      }
      /* action */
      if (last && last.t === 'action' && after === 'action' && !l.brk) { appendTo(last, t); return; }
      var odd = dialX.length && l.x0 > L + cw * 0.12 && !inSet(l.x0, dialX, tol * 2);
      P('action', t, odd ? 0.55 : 0.9);
    });
    /* "NAME : text" scripts typed with the name on its own line: drop the colon that starts the dialogue */
    getBlocks().forEach(function (b, i, a) { if (b.t === 'dial' && i && (a[i - 1].t === 'char' || a[i - 1].t === 'paren') && /^[:：]\s*\S/.test(b.x)) b.x = b.x.replace(/^[:：]\s*/, ''); });
    /* nothing but one column of short lines (subtitle files): one block per sentence */
    var bl = getBlocks();
    if (bl.length && bl.filter(function (b) { return b.t === 'scene' || b.t === 'char'; }).length < Math.max(4, ln.length * 0.01) && bl.length < ln.length) {
      var raw = ln.map(function (l) { return l.t; });
      if (raw.filter(function (t) { return t.length < 52; }).length > raw.length * 0.8) {
        bl.length = 0; var cur2 = null;
        raw.forEach(function (t, i) { if (cur2 && !/[.!?…।।]["”']?$/.test(cur2.x) && !/^[-–—]/.test(t) && !ln[i].brk) cur2.x = join(cur2.x, t); else { cur2 = push('action', t); cur2.c = 0.5; } });
      }
    }
  }

  /* ------------------------------------------------------------------ pages → script */
  THK.pdfPagesToScript = function (pages, fname, opts) {
    opts = opts || {};
    var d = THK.newImportDoc(String(fname || '').replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ').trim());
    var all = pages.reduce(function (n, p) { return n + p.rows.length; }, 0);
    if (!all) { var e0 = new Error('This PDF has no readable text. It looks like a scan (a picture of each page).'); e0.needOcr = true; throw e0; }
    /* unreadable text: replacement characters / private-use glyphs mean the font has no real text inside */
    var sample = pages.slice(0, 6).map(function (p) { return p.rows.map(function (r) { return r.segs.map(function (s) { return s.t; }).join(' '); }).join('\n'); }).join('\n');
    var bad = (sample.match(/[�-]/g) || []).length;
    var noText = sample.length < 40, glyphBad = bad > sample.length * 0.12;
    /* ---- is the text readable at all? (old 8-bit Malayalam fonts, damaged glyph maps) – the script always opens; problems are reported in the review screen */
    var q = THK.pdfQuality(pages);

    /* ---- find the first page with a scene heading; everything before it is the cover / contents */
    var rowText = function (r) { return r.segs.map(function (s) { return s.t; }).join(' '); };
    var firstScene = -1;
    pages.forEach(function (p, i) { if (firstScene < 0 && p.rows.some(function (r) { return isScene(rowText(r)) && !isTocRow(r); }) && !isTocPage(p)) firstScene = i; });
    function isTocRow(r) { return r.segs.length >= 3 && NUMONLY.test(r.segs[0].t) && isScene(r.segs[1].t) && !NUMONLY.test(r.segs[r.segs.length - 1].t); }
    function isTocPage(p) { return p.rows.some(function (r) { return /^(CONTENTS|TABLE OF CONTENTS|INDEX|ഉള്ളടക്കം|विषय[- ]?सूची|உள்ளடக்கம்|目次|目录|目錄|الفهرس|İÇİNDEKİLER|INHALT|SOMMAIRE|INDICE|ÍNDICE|СОДЕРЖАНИЕ|DAFTAR ISI|NILALAMAN|สารบัญ|차례|목차)$/i.test(rowText(r).trim()); }) || p.rows.filter(isTocRow).length >= 3; }
    var sceneTotal = pages.reduce(function (n, p) { return n + p.rows.filter(function (r) { return isScene(rowText(r)) && !isTocRow(r); }).length; }, 0);
    if (sceneTotal < 3 && pages.length >= 20) firstScene = 0;
    var coverPages = firstScene > 0 ? pages.slice(0, firstScene) : [];
    var bodyPages = firstScene > 0 ? pages.slice(firstScene) : (firstScene === 0 ? pages : pages);
    bodyPages = bodyPages.filter(function (p, i) { return !(isTocPage(p) && i < 3); });

    /* ---- cover page(s): title, writer, director, "based on" */
    if (coverPages.length) {
      var cp = coverPages[0], rows = cp.rows.filter(function (r) { return r.y > cp.h * 0.1 && r.y < cp.h * 0.93; }), szs = rows.map(function (r) { return r.sz; }).sort(function (a, b) { return a - b; }), med = szs[Math.floor(szs.length / 2)] || 10;
      var big = rows.filter(function (r) { return r.sz >= med * 1.25; }), tl = (big.length ? big : rows.slice(0, 1));
      if (tl.length) { var mx = Math.max.apply(null, tl.map(function (r) { return r.sz; })); tl = tl.filter(function (r) { return r.sz >= mx * 0.92; }); d.title = tl.map(rowText).reduce(join, '').trim().slice(0, 200) || d.title; }
      var LBLW = /^(?:written by|writer|screenplay by|screenplay|story by|by|രചന|തിരക്കഥ|लेखक|கதை|எழுத்து|రచన|ಬರಹ|লেখক|작가|脚本|脚本家|编剧|編劇|作者|автор|сценарий|drehbuch von|autor|écrit par|scritto da|escrito por|yazan|ditulis oleh|isinulat ni|เขียนโดย|كتابة|تأليف)\s*[:：\-–]?\s*(.*)$/i;
      var LBLD = /^(?:directed by|director|സംവിധാനം|दिग्दर्शक|निर्देशक|இயக்கம்|దర్శకత్వం|ನಿರ್ದೇಶನ|পরিচালক|감독|監督|导演|導演|режиссёр|режиссер|regie|réalisé par|regia|dirigido por|yönetmen|sutradara|direktor|ผู้กำกับ|إخراج|اخراج)\s*[:：\-–]?\s*(.*)$/i;
      rows.forEach(function (r, i) {
        var t = rowText(r).trim(), m;
        if ((m = t.match(LBLW)) && !d.writer) d.writer = (m[1] || (rows[i + 1] ? rowText(rows[i + 1]) : '')).trim();
        else if ((m = t.match(LBLD)) && !d.director) d.director = (m[1] || (rows[i + 1] ? rowText(rows[i + 1]) : '')).trim();
        else if (/^(?:based on|adapted from|inspired by)\b/i.test(t) && !d.basedOn) d.basedOn = t;
      });
    }

    /* ---- clean body rows: headers, footers, page numbers, scene numbers in the margins */
    var norm = function (t) { return t.replace(/\d+/g, '#').trim(); }, seen = {};
    bodyPages.forEach(function (p) { var k = {}; p.rows.forEach(function (r) { if (r.y > p.h * 0.93 || r.y < p.h * 0.055) { var t = norm(rowText(r)); if (!k[t]) { k[t] = 1; seen[t] = (seen[t] || 0) + 1; } } }); });
    var titleN = (d.title || '').trim().toLowerCase();
    var body = bodyPages.map(function (p, pi) {
      var rows = p.rows.filter(function (r) {
        var t = rowText(r).trim(), band = r.y > p.h * 0.93 || r.y < p.h * 0.055;
        if (MORE.test(t)) return false;
        if (!band) return true;
        if (/^\W*\d{1,4}\W*$/.test(t) || r.segs.every(function (s) { return NUMONLY.test(s.t) || /^\W*\d{1,4}\W*$/.test(s.t); })) return false;
        if (bodyPages.length >= 3 && seen[norm(t)] >= Math.max(2, bodyPages.length * 0.4)) return false;
        if (titleN && t.toLowerCase().indexOf(titleN) >= 0 && t.length <= titleN.length + 12) return false;
        return !(r.segs.length >= 2 && r.segs.some(function (s) { return /^\W*\d{1,4}\W*$/.test(s.t); }));
      });
      return { w: p.w, h: p.h, rows: rows };
    });
    /* drop page numbers that sit near the top right on pages without a margin band (e.g. "12.") */
    body.forEach(function (p) { if (p.rows.length > 3) { var f = p.rows[0]; if (f.y > p.h * 0.88 && f.segs.length === 1 && /^\d{1,4}\.?$/.test(f.segs[0].t)) p.rows.shift(); } });

    /* ---- text area: left edge L, right edge R (from long lines only) */
    var xs0 = [], xs1 = [];
    body.forEach(function (p) { p.rows.forEach(function (r) { r.segs.forEach(function (s) { if (s.t.length >= 14) { xs0.push(s.x0); xs1.push(s.x1); } }); }); });
    if (!xs0.length) body.forEach(function (p) { p.rows.forEach(function (r) { r.segs.forEach(function (s) { xs0.push(s.x0); xs1.push(s.x1); }); }); });
    var pw = body[0] ? body[0].w : 595;
    var L = (function () { var h = {}; xs0.forEach(function (x) { var k = Math.round(x / (pw * 0.006)); h[k] = (h[k] || 0) + 1; }); var ks = Object.keys(h).map(Number).sort(function (a, b) { return a - b; }), min = Math.max(2, xs0.length * 0.04); for (var i = 0; i < ks.length; i++) if (h[ks[i]] >= min) return ks[i] * pw * 0.006; return Math.min.apply(null, xs0); })();
    xs1.sort(function (a, b) { return a - b; });
    var R = xs1.length ? xs1[Math.min(xs1.length - 1, Math.floor(xs1.length * 0.97))] : pw * 0.9, cw = Math.max(50, R - L);
    /* scene numbers printed in the margins */
    var tol = pw * 0.012;
    body.forEach(function (p) { p.rows.forEach(function (r) { r.nums = []; r.segs = r.segs.filter(function (s) { if (NUMONLY.test(s.t) && (s.x1 <= L + tol || s.x0 >= R - tol * 0.5) && r.segs.length > 1) { r.nums.push(s.t); return false; } return true; }); }); p.rows = p.rows.filter(function (r) { return r.segs.length; }); });
    /* a number that stayed glued to the front of a heading ("12 INT. HOUSE") is removed with the shared helper */
    var strip = THK.stripSn || function (x) { return x; };

    /* ---- typical line spacing */
    var hist = {}; body.forEach(function (p) { for (var i = 1; i < p.rows.length; i++) { var dy = p.rows[i - 1].y - p.rows[i].y; if (dy > 5 && dy < 42) { var k = Math.round(dy * 2) / 2; hist[k] = (hist[k] || 0) + 1; } } });
    var m = 14, hb = 0; for (var hk in hist) if (hist[hk] > hb) { hb = hist[hk]; m = +hk; }
    /* flatten with gaps and page-break continuity */
    var flat = [], prev = null;
    body.forEach(function (p, pi) {
      p.rows.forEach(function (r, ri) {
        var q = { y: r.y, sz: r.sz, segs: r.segs, pw: p.w, ph: p.h, gap: 999 };
        if (prev) { if (ri === 0 && pi > 0) q.gap = prev.y > prev.ph * 0.07 + 3 * m ? 999 : m; else q.gap = prev.y - r.y; }
        flat.push(q); prev = q;
      });
    });

    /* ---- two column? action on the left, dialogue on the right of the same line */
    var splitX = L + cw * 0.5, both = 0, right = 0, segCount = 0;
    flat.forEach(function (r) { r.segs.forEach(function (s) { segCount++; }); var l = r.segs.some(function (s) { return s.x0 < splitX - cw * 0.04; }), rt = r.segs.some(function (s) { return s.x0 >= L + cw * 0.46 && s.x0 <= L + cw * 0.62 && s.x1 - s.x0 < cw * 0.55; }); if (rt) right++; if (l && rt && r.segs.length >= 2) both++; });
    var two = flat.length > 3 && (both >= Math.max(3, flat.length * 0.02) || (right >= 6 && right > flat.length * 0.22 && both >= Math.max(4, flat.length * 0.01)));

    var blocks = [], last = null;
    function push(t, x, x2) { var b = { id: uid(blocks.length), t: t, x: x }; if (t === 'scene') b.x2 = x2 || ''; blocks.push(b); last = b; return b; }
    function appendTo(b, t) { b.x = join(b.x, t); }
    function headOf(t) { return strip(t).replace(/^\s*#?\d{1,4}[A-Z]?#?\s*[.)\-:]\s*(?=\S)/, '').replace(/\s+#\d{1,4}[A-Z]?#\s*$/, '').trim(); }

    if (two) {
      var ci = null; // current dialogue being built
      flat.forEach(function (r) {
        var segs = r.segs, lefts = segs.filter(function (s) { return s.x0 < splitX - cw * 0.03; }), rights = segs.filter(function (s) { return s.x0 >= splitX - cw * 0.03; });
        var lt = lefts.map(function (s) { return s.t; }).reduce(join, ''), rt = rights.map(function (s) { return s.t; }).reduce(join, '');
        if (lt && isScene(lt)) { push('scene', headOf(lt), rt); ci = null; return; }
        var whole = segs.map(function (s) { return s.t; }).reduce(join, ''); if (segs.length <= 2 && TRANS.test(whole) && whole.length <= 34 && upperish(whole)) { push('trans', whole); ci = null; return; }
        if (lt && !rt && TRANS.test(lt) && upperish(lt)) { push('trans', lt); ci = null; return; }
        if (lt) {
          var l0 = lefts[lefts.length - 1], rightAligned = l0.x1 >= L + cw * 0.38, nameish = lt.length <= 40 && !/[.!?…।。！？؟]$/.test(lt.replace(/[:：]\s*$/, '')) && (!hasCase(lt) || upperish(lt.replace(/\s*\([^)]*\)\s*$/, '')) || true);
          if (rt && rightAligned && nameish) { push('char', cleanName(lt)); ci = null; }
          else if (rightAligned && nameish && !rt && (flat.indexOf(r) + 1 < flat.length) && flat[flat.indexOf(r) + 1].segs.some(function (s) { return s.x0 >= splitX - cw * 0.03; }) && r.gap > m * 1.3) { push('char', cleanName(lt)); ci = null; }
          else { if (last && last.t === 'action' && r.gap <= m * 1.35 && !ci) appendTo(last, lt); else push('action', lt); ci = null; }
        }
        if (rt) {
          if (/^\(/.test(rt) && !ci) { var pb = push('paren', rt.replace(/^\(\s*/, '').replace(/\s*\)$/, '')); ci = null; }
          else if (ci && r.gap <= m * 1.5 && !lt) appendTo(ci, rt);
          else ci = push('dial', last && (last.t === 'char' || last.t === 'paren') ? rt.replace(/^[:：]\s*(?=\S)/, '') : rt);
        }
      });
    } else {
      stdClassify(flat, L, cw, R, m, push, appendTo, headOf, function () { return blocks; });
    }
    if (!blocks.length) throw new Error('No script text found in this PDF');
    d.blocks = blocks;
    d.lang = THK.detectLang(blocks.map(function (b) { return b.x; }).join(' '));
    d.font = THK.defaultFont(d.lang);
    d.rtl = THK.lang(d.lang).rtl;
    if (!d.title) d.title = 'Imported script';
    blocks.forEach(function (b) { if (b.c == null) b.c = two ? 0.8 : 0.9; });
    blocks.forEach(function (b) { if (typeof b.x === 'string' && b.x.indexOf('□') >= 0) b.c = Math.min(b.c == null ? 1 : b.c, 0.5); });
    var lowN = blocks.filter(function (b) { return b.c < 0.75; }).length, warn = [];
    if (opts.conv && opts.conv.converted) warn.push('This PDF was typed with an old Malayalam font (' + opts.conv.fonts.map(function (f) { return f.replace(/^\w+\+/, ''); }).join(', ') + '). Its letters were converted to Unicode with a built-in table (' + opts.conv.converted + ' characters). Please skim the spelling' + (opts.conv.unknown ? ' – ' + opts.conv.unknown + ' letters the table does not know are shown as □' : '') + '.');
    if (opts.conv && opts.conv.fixed) warn.push(opts.conv.fixed + ' letters in this PDF had a wrong text map; they were corrected from a table for the font. Please skim the spelling.');
    if (opts.conv && opts.conv.filled) warn.push(opts.conv.filled + ' joined letters that this PDF had lost were filled in from a table for its font. They are usually right, but check the spelling.');
    if (opts.ocrDone) { var oi = opts.ocrInfo || {}; warn.length = 0; warn.push('Read by ' + (opts.method || 'OCR') + ', average confidence ' + (oi.avg || '?') + '%. OCR can mix up similar letters and conjuncts, so please skim the spelling' + (oi.low ? ' – ' + oi.low + ' words were read with low confidence' : '') + '.'); }
    if (q.legacy && !opts.ocrDone) warn.push('This PDF uses an old font whose letters could not be converted, so many words will look like gibberish. Use “Read with OCR” (when online), or export the script from the original app as .fdx / .docx / Fountain.');
    if (glyphBad && !opts.ocrDone) warn.push('Much of the text in this PDF is stored as glyph shapes, not real letters, so many characters are unreadable. Use “Read with OCR” (when online) for a better result.');
    if (noText && !opts.ocrDone) warn.push('This PDF has almost no readable text. It may be a scan – use “Read with OCR” (when online).');
    if (q.lost > 5 && !opts.ocrDone) warn.push('About ' + q.lost + ' letters could not be read (the PDF lost them when it was made). They are shown as □ — please retype them.');
    else if (q.badWords > 0.08 && q.indicWords > 100 && !opts.ocrDone) warn.push('About ' + Math.round(q.badWords * 100) + '% of the words look broken (letters or signs missing). The PDF has damaged text, so spelling needs checking.');
    d._imp = { total: blocks.length, low: lowN, warn: warn, pages: pages.length, method: opts.method || 'text layer', ocr: !opts.ocrDone && !!(q.legacy || glyphBad || noText || q.lostRatio > 0.02 || (q.badWords > 0.08 && q.indicWords > 100)), src: opts.src };
    return d;
  };


  /* ------------------------------------------------------------------ review screen (shown after reading a PDF) */
  var TYPES = [['scene', 'Scene heading'], ['action', 'Action'], ['char', 'Character'], ['paren', 'Parenthetical'], ['dial', 'Dialogue'], ['trans', 'Transition']];
  function clean(d) { (d.blocks || []).forEach(function (b) { delete b.c; delete b.k; }); delete d._imp; }
  THK.pdfReview = function (d) {
    return new Promise(function (resolve) {
      var A = THK.app, imp = d._imp || {}, blocks = d.blocks, low = blocks.filter(function (b) { return b.c < 0.75; });
      var plain = blocks.length > 20 && blocks.every(function (b) { return b.t === 'action' || b.t === 'scene'; }) && low.length > blocks.length * 0.8;
      var warn = (imp.warn || []).slice();
      if (plain) warn.push('No screenplay layout was found (no indents, no character names). The lines were imported as Action – set Character / Dialogue below, or use the original file if you have it.');
      if (!low.length && !warn.length) { clean(d); resolve(true); return; }
      var wrap = A.el('div', 'pdfrev'), apply = true;
      var sum = A.el('p', '', '<b>' + blocks.length + '</b> lines read from <b>' + (imp.pages || '?') + '</b> pages (text layer, no OCR needed).<br><b>' + (blocks.length - low.length) + '</b> were recognised with confidence, <b>' + low.length + '</b> need a quick look.');
      wrap.appendChild(sum);
      warn.forEach(function (w) { wrap.appendChild(A.el('p', 'pdfwarn', '⚠ ' + A.esc(w))); });
      if (low.length) {
        var lab = A.el('label', 'pdfsim', '<input type="checkbox" checked> Apply a change to similar lines (same type and indent)');
        lab.querySelector('input').onchange = function () { apply = this.checked; };
        wrap.appendChild(lab);
        low.sort(function (a, b) { return (b.x.indexOf('□') >= 0) - (a.x.indexOf('□') >= 0); });
        var list = A.el('div', 'pdflist'), shown = low.slice(0, 40), sels = [];
        shown.forEach(function (b, i) {
          var row = A.el('div', 'pdfrow'), tx = A.el('div', 'pdftx', A.esc(b.x.slice(0, 90)).replace(/□+/g, '<mark>$&</mark>')), sel = A.el('select', 'pdfsel');
          TYPES.forEach(function (t) { var o = document.createElement('option'); o.value = t[0]; o.textContent = t[1]; if (t[0] === b.t) o.selected = true; sel.appendChild(o); });
          sel.onchange = function () {
            var from = b.t, to = sel.value, k = b.k;
            var set = apply ? low.filter(function (x) { return x.t === from && x.k === k; }) : [b];
            set.forEach(function (x) { x.t = to; x.c = 1; if (to === 'scene' && x.x2 == null) x.x2 = ''; });
            shown.forEach(function (x, j) { sels[j].value = x.t; });
          };
          sels.push(sel); row.appendChild(tx); row.appendChild(sel); list.appendChild(row);
        });
        wrap.appendChild(list);
        if (low.length > shown.length) wrap.appendChild(A.el('p', 'pdfmore', 'Showing the first ' + shown.length + ' of ' + low.length + '. Changing one with “similar lines” on fixes the rest of its kind in one go.'));
      }
      var done = false;
      var btns = [{ l: 'Cancel', fn: function () { if (!done) { done = true; resolve(false); } } }];
      if (imp.ocr && imp.src && THK.pdfOcrFlow) btns.push({ l: 'Read with OCR', fn: function () { done = true; resolve({ ocr: true, buf: imp.src, name: d.title, hint: THK.detectLang(blocks.slice(0, 200).map(function (b) { return b.x; }).join(' ')) }); } });
      btns.push({ l: 'Open script', cls: 'pri', fn: function () { done = true; clean(d); resolve(true); } });
      A.dlg('Check the imported script', wrap, btns, { nofocus: true, onclose: function () { if (!done) { done = true; resolve(false); } } });
    });
  };
  (function () {
    var st = document.createElement('style');
    st.textContent = '.pdfrev{max-height:62vh;overflow:auto;-webkit-overflow-scrolling:touch}.pdfrev p{margin:0 0 8px;font-size:14px;line-height:1.45}.pdfwarn{padding:8px 10px;border-radius:14px;background:rgba(255,170,60,.16);border:1px solid rgba(255,170,60,.35)}.pdftx mark{background:rgba(255,170,60,.45);color:inherit;border-radius:4px;padding:0 2px}.pdfsim{display:flex;gap:8px;align-items:center;font-size:13.5px;margin:6px 0 10px}.pdflist{display:flex;flex-direction:column;gap:6px}.pdfrow{display:flex;gap:8px;align-items:center;padding:6px 8px;border-radius:14px;border:1px solid var(--edge,rgba(128,128,128,.25));background:var(--glass,rgba(128,128,128,.08))}.pdftx{flex:1;min-width:0;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.pdfsel{flex:none;max-width:44%;font-size:13px}.pdfmore{opacity:.7;font-size:12.5px!important;margin-top:8px!important}';
    document.head.appendChild(st);
  })();

  /* ------------------------------------------------------------------ public entry */
  THK.parsePdf = function (buf, fname) {
    var keep = buf.slice(0);   /* pdf.js takes over the original buffer; OCR needs its own copy */
    var payload = function (doc) {
      var n = Math.min(doc.numPages, 3), i = 0, hit = null;
      function nx() {
        if (hit || i >= n) return Promise.resolve(hit);
        return doc.getPage(++i).then(function (pg) { return pg.getAnnotations(); }).then(function (an) {
          an.forEach(function (a) { if (!hit && a.url && a.url.indexOf(THK.FNX) === 0) hit = a.url.slice(THK.FNX.length); }); return nx();
        });
      }
      return nx().then(function (b64) {
        if (!b64) return null;
        try { var js = decodeURIComponent(escape(atob(b64.replace(/-/g, '+').replace(/_/g, '/')))), d = JSON.parse(js); if (d && d.blocks && d.blocks.length) { delete d.id; return d; } } catch (e) { }
        return null;
      });
    };
    return load().then(function (pdfjs) {
      return pdfjs.getDocument({ data: new Uint8Array(buf), cMapUrl: url('vendor/pdfjs/cmaps/'), cMapPacked: true, isEvalSupported: false, useSystemFonts: true, verbosity: 0 }).promise;
    }).then(function (doc) {
      return payload(doc).then(function (exact) { return exact ? { exact: exact, doc: doc } : { doc: doc }; });
    }).then(function (o) {
      if (o.exact) { try { o.doc.destroy(); } catch (e) { } return o.exact; }
      var doc = o.doc, n = Math.min(doc.numPages, 400), out = [], i = 0;
      function next() {
        if (i >= n) return Promise.resolve(out);
        return doc.getPage(++i).then(function (pg) {
          var vp = pg.getViewport({ scale: 1 });
          return pg.getTextContent({ includeMarkedContent: false }).then(function (tc) { out.push(pageRows(tc, vp.width, vp.height)); pg.cleanup && pg.cleanup(); return next(); });
        });
      }
      return next().then(function (pages) {
        var q = THK.pdfQuality(pages), need = q.legacy || q.lost > 3 || (q.badWords > 0.08 && q.indicWords > 100);
        var fin = function (pgs, opts) { try { doc.destroy(); } catch (e) { } opts = opts || {}; opts.src = keep; return THK.pdfPagesToScript(pgs, fname, opts); };
        if (!need || !THK.pdfReadGlyphs) return fin(pages);
        /* old fonts / lost letters: read the raw glyph codes and convert them with the per-font tables */
        return load().then(function (m) { return THK.pdfReadGlyphs(m, doc, pageRows, 400); }).then(function (r) {
          var q2 = THK.pdfQuality(r.pages), better = q.legacy || r.stats.converted || r.stats.filled || r.stats.fixed || q2.lost < q.lost;
          return fin(better ? r.pages : pages, better ? { conv: r.stats, method: 'glyph codes' } : {});
        }, function () { return fin(pages); });
      });
    });
  };
})();
