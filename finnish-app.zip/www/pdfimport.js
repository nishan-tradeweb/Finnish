/* PDF import – reads the real text of a screenplay PDF (offline, bundled pdf.js) and rebuilds scenes, action, characters,
   dialogue, parentheticals and transitions from where each line sits on the page. Works for Standard and Two Column layouts
   and for every language in the app, as long as the PDF contains real text (not a scan, and not glyph-shape-only fonts). */
(function () {
  'use strict';

  /* ------------------------------------------------------------------ pdf.js loader */
  var lib = null;
  function url(p) { return new URL(p, document.baseURI).href; }
  function load() {
    if (lib) return Promise.resolve(lib);
    return import(url('vendor/pdfjs/pdf.min.js')).then(function (m) { m.GlobalWorkerOptions.workerSrc = url('vendor/pdfjs/pdf.worker.min.js'); lib = m; return m; });
  }

  /* ------------------------------------------------------------------ text → lines */
  var NUMONLY = /^\d{1,4}[A-Z]?\.?$/;
  function pageRows(tc, vw, vh) {
    var runs = [], cur = null;
    tc.items.forEach(function (it) {
      if (typeof it.str !== 'string' || !it.str.length) return;
      var tr = it.transform, x = tr[4], y = tr[5], sz = Math.hypot(tr[0], tr[1]) || it.height || 10, w = it.width || 0;
      if (!it.str.trim()) { if (cur && Math.abs(y - cur.y) <= 0.4 * Math.max(sz, cur.sz)) cur.sp = true; else if (cur) { runs.push(cur); cur = null; } return; }   /* spaces never stretch a run */
      if (cur && Math.abs(y - cur.y) <= 0.4 * Math.max(sz, cur.sz)) {
        var gap = Math.max(x - cur.x1, cur.x0 - (x + w)), brk = gap > 0.06 * vw || (NUMONLY.test(it.str.trim()) && x + w <= cur.x0 + 1) || (NUMONLY.test(cur.t.trim()) && (gap > 0.5 * sz || cur.sp)) || (NUMONLY.test(it.str.trim()) && x > 0.89 * vw && gap > 0.5 * sz);
        if (!brk) {
          cur.t += ((cur.sp || gap > 0.22 * sz) && !/\s$/.test(cur.t) && !/^\s/.test(it.str) ? ' ' : '') + it.str; cur.sp = false;
          cur.x0 = Math.min(cur.x0, x); cur.x1 = Math.max(cur.x1, x + w); cur.sz = Math.max(cur.sz, sz); return;
        }
      }
      if (cur) runs.push(cur);
      cur = { t: it.str, x0: x, x1: x + w, y: y, sz: sz };
    });
    if (cur) runs.push(cur);
    runs.forEach(function (r) { r.t = fixIndic(r.t.replace(/\s+$/, '').replace(/^\s+/, '')); if (/[\u2E80-\u2FDF\uFB50-\uFEFF\uFF00-\uFFEF]/.test(r.t)) r.t = r.t.normalize('NFKC'); });
    runs = runs.filter(function (r) { return r.t; });
    /* runs on the same height become one row (two column pages put action and dialogue on the same line) */
    runs.sort(function (a, b) { return b.y - a.y; });
    var rows = [];
    runs.forEach(function (r) {
      var last = rows[rows.length - 1];
      if (last && Math.abs(last.y - r.y) <= 0.4 * Math.max(last.sz, r.sz)) { last.segs.push(r); last.sz = Math.max(last.sz, r.sz); } else rows.push({ y: r.y, sz: r.sz, segs: [r] });
    });
    rows.forEach(function (r) { r.segs.sort(function (a, b) { return a.x0 - b.x0; }); });
    return { w: vw, h: vh, rows: rows };
  }

  /* ------------------------------------------------------------------ language of the text */
  var STOP = {
    en: 'the and to of is you he she it in that was for with this have not but are', es: 'el la de que y en los un una es no por con para se las del', fr: 'le la les de des et que est un une pas je vous nous dans pour',
    de: 'der die das und ist nicht ich du ein eine zu mit den von sie er', it: 'il di che e la non un una per sono con le del gli ma', tr: 'bir ve bu ne için ben sen de da mi çok ama değil', id: 'yang dan di itu ini aku kamu tidak dengan untuk dari ada saya', tl: 'ang ng sa na ako ikaw siya mga ay hindi ito mo ka'
  };
  THK._pageRows = pageRows;
  /* finnish PDFs carry the whole script (invisible 1-pixel link) so they come back exactly, in every language */
  THK.FNX = 'https://finnish.invalid/#FNX1.';
  THK.pdfPayload = function (d) {
    var o = {}; Object.keys(d).forEach(function (k) { if (k === 'id' || k === '_h' || k === 'created' || k === 'updated') return; if (k === 'logo' && String(d[k]).length > 200000) return; o[k] = d[k]; });
    return THK.FNX + btoa(unescape(encodeURIComponent(JSON.stringify(o)))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  };
  THK.detectLang = function (text) {
    text = String(text || '').slice(0, 6000); var n = {}, k;
    var R = { ml: /[ഀ-ൿ]/g, ta: /[஀-௿]/g, te: /[ఀ-౿]/g, kn: /[ಀ-೿]/g, hi: /[ऀ-ॿ]/g, bn: /[ঀ-৿]/g, gu: /[઀-૿]/g, pa: /[਀-੿]/g, th: /[฀-๿]/g, ko: /[ᄀ-ᇿ㄰-㆏가-힯]/g, kana: /[぀-ヿ]/g, han: /[一-鿿]/g, ar: /[؀-ۿݐ-ݿ]/g, ru: /[Ѐ-ӿ]/g };
    for (k in R) n[k] = (text.match(R[k]) || []).length;
    var best = '', bv = 0; for (k in n) if (n[k] > bv) { bv = n[k]; best = k; }
    var letters = (text.match(/[A-Za-zÀ-ɏ]/g) || []).length;
    if (bv >= 8 && bv * 2 >= letters) {
      if (best === 'kana') return 'ja'; if (best === 'han') return n.kana > 0 ? 'ja' : 'zh';
      if (best === 'hi') return /ळ/.test(text) ? 'mr' : 'hi';
      if (best === 'bn') return /[ৰৱ]/.test(text) ? 'as' : 'bn';
      return best;
    }
    var words = text.toLowerCase().match(/[a-zÀ-ɏ']+/g) || [], bestL = 'en', bs = 0;
    for (k in STOP) { var set = {}; STOP[k].split(' ').forEach(function (w) { set[w] = 1; }); var sc = 0; words.forEach(function (w) { if (set[w]) sc++; }); if (k !== 'en') sc *= 1.15; if (sc > bs) { bs = sc; bestL = k; } }
    return bs >= 4 ? bestL : 'en';
  };

  /* ------------------------------------------------------------------ rules */
  var SC_LATIN = /^(?:#?\d{1,4}[A-Z]?#?\s*[.)\-:]?\s*)?(?:INT|EXT|EST|I\s*\/\s*E|INT\.?\s*\/\s*EXT\.?|INNEN|AUSSEN|INTERIEUR|EXTERIEUR|INTÉRIEUR|EXTÉRIEUR|INTERNO|ESTERNO|INTERIOR|EXTERIOR|DALAM|LUAR|İÇ|DIŞ|ВНУТР|НАТ|ИНТ|ЭКСТ|SCENE|SCENA|ESCENA|SZENE|SCÈNE|SAHNE|ADEGAN|EKSENA|СЦЕНА|CENA)(?![A-Za-zÀ-ɏ])/i;
  var SC_OTHER = /^(?:#?\d{1,4}[A-Z]?#?\s*[.)\-:]?\s*)?(?:സീൻ|രംഗം|ഉ\s*ൾ|പു\s*റം|காட்சி|సన్నివేశం|ದೃಶ್ಯ|দৃশ্য|દૃશ્ય|ਦ੍ਰਿਸ਼|दृश्य|ฉาก|씬|장면|場面|シーン|场景|場景|內景|外景|内景|外景|室内|室外|屋内|屋外|مشهد|داخلي|خارجي)/;
  var TRANS = /(?:^|\s)(?:CUT TO|FADE (?:IN|OUT|TO)|DISSOLVE TO|SMASH CUT|MATCH CUT|JUMP CUT|WIPE TO|CUT)\s*[:.]?$|TO:$|^(?:കട്ട്|ഫെയ്ഡ്)|^(?:FADE (?:IN|OUT)[:.]?)$/;
  var MORE = /^\(?\s*(?:MORE|CONT['’]?D\.?|CONTINUED|CONT\.?)\s*\)?\s*[:.]?$/i;
  var CJK = /[぀-ヿ㐀-鿿가-힯฀-๿]/;
  function isScene(t) { return SC_LATIN.test(t) || SC_OTHER.test(t); }
  function join(a, b) { if (!a) return b; if (CJK.test(a.slice(-1)) && CJK.test(b.charAt(0))) return a + b; if (/-$/.test(a) && /^[a-z]/.test(b)) return a + b; return a + ' ' + b; }
  function upperish(s) { return s === s.toUpperCase() && s !== s.toLowerCase(); }
  function hasCase(s) { return /[A-Za-zÀ-ɏͰ-ϿЀ-ӿ]/.test(s); }
  function cleanName(s) { return s.replace(/[:：]\s*$/, '').replace(/\s*\((?:CONT['’]?D\.?|CONT\.?|MORE)\)\s*$/i, '').replace(/\s+:$/, '').trim(); }
  /* pre-base vowel signs (Malayalam, Tamil, Bengali, Hindi, Gujarati, Punjabi) come out in visual order from many PDFs: move them behind their consonant cluster */
  var IND = [
    { c: '[\\u0D15-\\u0D3A\\u0D7A-\\u0D7F]', v: '\\u0D4D', p: '\\u0D46\\u0D47\\u0D48', two: { '\\u0D46\\u0D3E': '\\u0D4A', '\\u0D47\\u0D3E': '\\u0D4B', '\\u0D46\\u0D57': '\\u0D4C' } },
    { c: '[\\u0B95-\\u0BB9]', v: '\\u0BCD', p: '\\u0BC6\\u0BC7\\u0BC8', two: { '\\u0BC6\\u0BBE': '\\u0BCA', '\\u0BC7\\u0BBE': '\\u0BCB', '\\u0BC6\\u0BD7': '\\u0BCC' } },
    { c: '[\\u0995-\\u09B9\\u09DC-\\u09DF\\u09F0\\u09F1]', v: '\\u09CD', p: '\\u09C7\\u09C8', two: { '\\u09C7\\u09BE': '\\u09CB', '\\u09C7\\u09D7': '\\u09CC' } },
    { c: '[\\u0915-\\u0939\\u0958-\\u095F]', v: '\\u094D', p: '\\u093F', two: {} },
    { c: '[\\u0A95-\\u0AB9]', v: '\\u0ACD', p: '\\u0ABF', two: {} },
    { c: '[\\u0A15-\\u0A39]', v: '\\u0A4D', p: '\\u0A3F', two: {} }
  ].map(function (r) { r.re = new RegExp('(^|[^' + r.c.slice(1, -1) + r.v + '])([' + r.p + '])(' + r.c + '(?:' + r.v + r.c + ')*)(\\u0D3E|\\u0BBE|\\u0BD7|\\u09BE|\\u09D7|\\u0D57)?', 'g'); return r; });
  function fixIndic(t) {
    if (!/[ऀ-෿]/.test(t)) return t;
    IND.forEach(function (r) { t = t.replace(r.re, function (m, pre, sign, cl, post) { var key = post ? sign + post : '', two = key && r.two[key]; return pre + cl + (two || (sign + (post || ''))); }); });
    return t;
  }
  function uid(n) { return Math.random().toString(36).slice(2, 8) + n; }

  /* ------------------------------------------------------------------ pages → script */
  THK.pdfPagesToScript = function (pages, fname) {
    var d = THK.newImportDoc(String(fname || '').replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ').trim());
    var all = pages.reduce(function (n, p) { return n + p.rows.length; }, 0);
    if (!all) throw new Error('This PDF has no readable text. It may be a scan (a picture of a page).');
    /* unreadable text: replacement characters / private-use glyphs mean the font has no real text inside */
    var sample = pages.slice(0, 6).map(function (p) { return p.rows.map(function (r) { return r.segs.map(function (s) { return s.t; }).join(' '); }).join('\n'); }).join('\n');
    var bad = (sample.match(/[�-]/g) || []).length;
    if (sample.length < 40) throw new Error('This PDF has almost no readable text. It may be a scan (a picture of a page).');
    if (bad > sample.length * 0.12) throw new Error('The text in this PDF is stored as glyph shapes, not real letters, so it cannot be read back (this happens with some Final Draft PDFs).');

    /* ---- find the first page with a scene heading; everything before it is the cover / contents */
    var rowText = function (r) { return r.segs.map(function (s) { return s.t; }).join(' '); };
    var firstScene = -1;
    pages.forEach(function (p, i) { if (firstScene < 0 && p.rows.some(function (r) { return isScene(rowText(r)) && !isTocRow(r); }) && !isTocPage(p)) firstScene = i; });
    function isTocRow(r) { return r.segs.length >= 3 && NUMONLY.test(r.segs[0].t) && isScene(r.segs[1].t) && !NUMONLY.test(r.segs[r.segs.length - 1].t); }
    function isTocPage(p) { return p.rows.some(function (r) { return /^(CONTENTS|TABLE OF CONTENTS|INDEX|ഉള്ളടക്കം|विषय[- ]?सूची|உள்ளடக்கம்|目次|目录|目錄|الفهرس|İÇİNDEKİLER|INHALT|SOMMAIRE|INDICE|ÍNDICE|СОДЕРЖАНИЕ|DAFTAR ISI|NILALAMAN|สารบัญ|차례|목차)$/i.test(rowText(r).trim()); }) || p.rows.filter(isTocRow).length >= 3; }
    var coverPages = firstScene > 0 ? pages.slice(0, firstScene) : [];
    var bodyPages = firstScene > 0 ? pages.slice(firstScene) : (firstScene === 0 ? pages : pages);
    bodyPages = bodyPages.filter(function (p, i) { return !(isTocPage(p) && i < 3); });

    /* ---- cover page(s): title, writer, director, "based on" */
    if (coverPages.length) {
      var cp = coverPages[0], rows = cp.rows.filter(function (r) { return r.y > cp.h * 0.1 && r.y < cp.h * 0.93; }), szs = rows.map(function (r) { return r.sz; }).sort(function (a, b) { return a - b; }), med = szs[Math.floor(szs.length / 2)] || 10;
      var big = rows.filter(function (r) { return r.sz >= med * 1.25; }), tl = (big.length ? big : rows.slice(0, 1));
      if (tl.length) { var mx = Math.max.apply(null, tl.map(function (r) { return r.sz; })); tl = tl.filter(function (r) { return r.sz >= mx * 0.92; }); d.title = tl.map(rowText).reduce(join, '').trim().slice(0, 200) || d.title; }
      var LBLW = /^(?:written by|writer|screenplay by|screenplay|story by|by|രചന|തിരക്കഥ|लेखक|கதை|எழுத்து|రచన|ಬರಹ|লেখক|작가|脚本|脚本家|编剧|編劇|作者|автор|сценарий|drehbuch von|autor|écrit par|scritto da|escrito por|yazan|ditulis oleh|isinulat ni|เขียนโดย|كتابة|تأليف)\s*[:：\-–]?\s*(.*)$/i;
      var LBLD = /^(?:directed by|director|സംവിധാനം|दिग्दर्शक|निर्देशक|இயக்கம்|దర్శకత్వం|ನಿರ್ದೇಶನ|পরিচালক|감독|監督|导演|導演|режиссёр|режиссер|regie|réalisé par|regia|dirigido por|yönetmen|sutradara|direktor|ผู้กำกับ|إخراج|اخراج)\s*[:：\-–]?\s*(.*)$/i;
      rows.forEach(function (r, i) {
        var t = rowText(r).trim(), m;
        if ((m = t.match(LBLW)) && !d.writer) d.writer = (m[1] || (rows[i + 1] ? rowText(rows[i + 1]) : '')).trim();
        else if ((m = t.match(LBLD)) && !d.director) d.director = (m[1] || (rows[i + 1] ? rowText(rows[i + 1]) : '')).trim();
        else if (/^(?:based on|adapted from|inspired by)\b/i.test(t) && !d.basedOn) d.basedOn = t;
      });
    }

    /* ---- clean body rows: headers, footers, page numbers, scene numbers in the margins */
    var norm = function (t) { return t.replace(/\d+/g, '#').trim(); }, seen = {};
    bodyPages.forEach(function (p) { var k = {}; p.rows.forEach(function (r) { if (r.y > p.h * 0.93 || r.y < p.h * 0.055) { var t = norm(rowText(r)); if (!k[t]) { k[t] = 1; seen[t] = (seen[t] || 0) + 1; } } }); });
    var titleN = (d.title || '').trim().toLowerCase();
    var body = bodyPages.map(function (p, pi) {
      var rows = p.rows.filter(function (r) {
        var t = rowText(r).trim(), band = r.y > p.h * 0.93 || r.y < p.h * 0.055;
        if (MORE.test(t)) return false;
        if (!band) return true;
        if (/^\W*\d{1,4}\W*$/.test(t) || r.segs.every(function (s) { return NUMONLY.test(s.t) || /^\W*\d{1,4}\W*$/.test(s.t); })) return false;
        if (bodyPages.length >= 3 && seen[norm(t)] >= Math.max(2, bodyPages.length * 0.4)) return false;
        if (titleN && t.toLowerCase().indexOf(titleN) >= 0 && t.length <= titleN.length + 12) return false;
        return !(r.segs.length >= 2 && r.segs.some(function (s) { return /^\W*\d{1,4}\W*$/.test(s.t); }));
      });
      return { w: p.w, h: p.h, rows: rows };
    });
    /* drop page numbers that sit near the top right on pages without a margin band (e.g. "12.") */
    body.forEach(function (p) { if (p.rows.length > 3) { var f = p.rows[0]; if (f.y > p.h * 0.88 && f.segs.length === 1 && /^\d{1,4}\.?$/.test(f.segs[0].t)) p.rows.shift(); } });

    /* ---- text area: left edge L, right edge R (from long lines only) */
    var xs0 = [], xs1 = [];
    body.forEach(function (p) { p.rows.forEach(function (r) { r.segs.forEach(function (s) { if (s.t.length >= 14) { xs0.push(s.x0); xs1.push(s.x1); } }); }); });
    if (!xs0.length) body.forEach(function (p) { p.rows.forEach(function (r) { r.segs.forEach(function (s) { xs0.push(s.x0); xs1.push(s.x1); }); }); });
    var pw = body[0] ? body[0].w : 595;
    var L = (function () { var h = {}; xs0.forEach(function (x) { var k = Math.round(x / (pw * 0.006)); h[k] = (h[k] || 0) + 1; }); var ks = Object.keys(h).map(Number).sort(function (a, b) { return a - b; }), min = Math.max(2, xs0.length * 0.04); for (var i = 0; i < ks.length; i++) if (h[ks[i]] >= min) return ks[i] * pw * 0.006; return Math.min.apply(null, xs0); })();
    xs1.sort(function (a, b) { return a - b; });
    var R = xs1.length ? xs1[Math.min(xs1.length - 1, Math.floor(xs1.length * 0.97))] : pw * 0.9, cw = Math.max(50, R - L);
    /* scene numbers printed in the margins */
    var tol = pw * 0.012;
    body.forEach(function (p) { p.rows.forEach(function (r) { r.nums = []; r.segs = r.segs.filter(function (s) { if (NUMONLY.test(s.t) && (s.x1 <= L + tol || s.x0 >= R - tol * 0.5) && r.segs.length > 1) { r.nums.push(s.t); return false; } return true; }); }); p.rows = p.rows.filter(function (r) { return r.segs.length; }); });
    /* a number that stayed glued to the front of a heading ("12 INT. HOUSE") is removed with the shared helper */
    var strip = THK.stripSn || function (x) { return x; };

    /* ---- typical line spacing */
    var hist = {}; body.forEach(function (p) { for (var i = 1; i < p.rows.length; i++) { var dy = p.rows[i - 1].y - p.rows[i].y; if (dy > 5 && dy < 42) { var k = Math.round(dy * 2) / 2; hist[k] = (hist[k] || 0) + 1; } } });
    var m = 14, hb = 0; for (var hk in hist) if (hist[hk] > hb) { hb = hist[hk]; m = +hk; }
    /* flatten with gaps and page-break continuity */
    var flat = [], prev = null;
    body.forEach(function (p, pi) {
      p.rows.forEach(function (r, ri) {
        var q = { y: r.y, sz: r.sz, segs: r.segs, pw: p.w, ph: p.h, gap: 999 };
        if (prev) { if (ri === 0 && pi > 0) q.gap = prev.y > prev.ph * 0.07 + 3 * m ? 999 : m; else q.gap = prev.y - r.y; }
        flat.push(q); prev = q;
      });
    });

    /* ---- two column? action on the left, dialogue on the right of the same line */
    var splitX = L + cw * 0.5, both = 0, right = 0, segCount = 0;
    flat.forEach(function (r) { r.segs.forEach(function (s) { segCount++; }); var l = r.segs.some(function (s) { return s.x0 < splitX - cw * 0.04; }), rt = r.segs.some(function (s) { return s.x0 >= L + cw * 0.46 && s.x0 <= L + cw * 0.62 && s.x1 - s.x0 < cw * 0.55; }); if (rt) right++; if (l && rt && r.segs.length >= 2) both++; });
    var two = flat.length > 3 && (both >= 3 || (right >= 6 && right > flat.length * 0.22 && both >= 1));

    var blocks = [], last = null;
    function push(t, x, x2) { var b = { id: uid(blocks.length), t: t, x: x }; if (t === 'scene') b.x2 = x2 || ''; blocks.push(b); last = b; return b; }
    function appendTo(b, t) { b.x = join(b.x, t); }
    function headOf(t) { return strip(t).replace(/^\s*#?\d{1,4}[A-Z]?#?\s*[.)\-:]\s*(?=\S)/, '').replace(/\s+#\d{1,4}[A-Z]?#\s*$/, '').trim(); }

    if (two) {
      var ci = null; // current dialogue being built
      flat.forEach(function (r) {
        var segs = r.segs, lefts = segs.filter(function (s) { return s.x0 < splitX - cw * 0.03; }), rights = segs.filter(function (s) { return s.x0 >= splitX - cw * 0.03; });
        var lt = lefts.map(function (s) { return s.t; }).reduce(join, ''), rt = rights.map(function (s) { return s.t; }).reduce(join, '');
        if (lt && isScene(lt)) { push('scene', headOf(lt), rt); ci = null; return; }
        var whole = segs.map(function (s) { return s.t; }).reduce(join, ''); if (segs.length <= 2 && TRANS.test(whole) && whole.length <= 34 && upperish(whole)) { push('trans', whole); ci = null; return; }
        if (lt && !rt && TRANS.test(lt) && upperish(lt)) { push('trans', lt); ci = null; return; }
        if (lt) {
          var l0 = lefts[lefts.length - 1], rightAligned = l0.x1 >= L + cw * 0.38, nameish = lt.length <= 40 && !/[.!?…।。！？؟]$/.test(lt.replace(/[:：]\s*$/, '')) && (!hasCase(lt) || upperish(lt.replace(/\s*\([^)]*\)\s*$/, '')) || true);
          if (rt && rightAligned && nameish) { push('char', cleanName(lt)); ci = null; }
          else if (rightAligned && nameish && !rt && (flat.indexOf(r) + 1 < flat.length) && flat[flat.indexOf(r) + 1].segs.some(function (s) { return s.x0 >= splitX - cw * 0.03; }) && r.gap > m * 1.3) { push('char', cleanName(lt)); ci = null; }
          else { if (last && last.t === 'action' && r.gap <= m * 1.35 && !ci) appendTo(last, lt); else push('action', lt); ci = null; }
        }
        if (rt) {
          if (/^\(/.test(rt) && !ci) { var pb = push('paren', rt.replace(/^\(\s*/, '').replace(/\s*\)$/, '')); ci = null; }
          else if (ci && r.gap <= m * 1.5 && !lt) appendTo(ci, rt);
          else ci = push('dial', rt);
        }
      });
    } else {
      /* ---------------- standard layout, decided from indentation, spacing and wording */
      var nxt = function (i) { var q = flat[i + 1]; return q || null; };
      var colon = flat.filter(function (r) { var t = r.segs.map(function (s) { return s.t; }).join(' '); return /^[^\s:：]{1,24}(\s[^\s:：]{1,18}){0,2}\s*[:：]\s+\S/.test(t) && !isScene(t); }).length;
      var indRows = flat.filter(function (r) { return (r.segs[0].x0 - L) / cw >= 0.07; }).length, useColon = colon >= 3 && indRows < 3;
      var after = ''; // previous block type
      flat.forEach(function (r, i) {
        var t = r.segs.map(function (s) { return s.t; }).reduce(join, ''), x0 = r.segs[0].x0, x1 = r.segs[r.segs.length - 1].x1, f = (x0 - L) / cw, ctr = Math.abs((x0 + x1) / 2 - (L + cw / 2)) / cw, brk = r.gap > m * 1.35;
        var q = nxt(i), qf = q ? (q.segs[0].x0 - L) / cw : -1, qScene = q ? isScene(q.segs.map(function (s) { return s.t; }).join(' ')) : true;
        if (isScene(t)) { push('scene', headOf(t)); after = 'scene'; return; }
        if ((TRANS.test(t) && t.length <= 34 && (upperish(t) || !hasCase(t))) || (f > 0.45 && x1 >= R - cw * 0.06 && t.length <= 30 && (upperish(t) || !hasCase(t)))) { push('trans', t.replace(/[:：]\s*$/, ':')); after = 'trans'; return; }
        if (useColon) { var cm = t.match(/^([^\s:：]{1,24}(?:\s[^\s:：]{1,18}){0,2})\s*[:：]\s+([\s\S]+)$/); if (cm) { push('char', cleanName(cm[1])); push('dial', cm[2]); after = 'dial'; return; } }
        if (f < 0.07 && !(after === 'char' || after === 'paren')) {            /* flush left: action */
          if (last && last.t === 'action' && !brk) appendTo(last, t); else push('action', t); after = 'action'; return;
        }
        /* indented text */
        if (/^\(/.test(t) && (after === 'char' || after === 'dial' || after === 'paren')) { push('paren', t.replace(/^\(\s*/, '').replace(/\s*\)\s*$/, '')); after = 'paren'; return; }
        if (after === 'char' || after === 'paren') { push('dial', t); after = 'dial'; return; }
        var s2 = t.replace(/\s*\([^)]*\)\s*$/, '').replace(/[:：]\s*$/, '').trim(), words = s2.split(/\s+/).length, endP = /[.!?…।。！？؟]$/.test(s2);
        var capsName = hasCase(s2) ? upperish(s2) : (s2.length <= 26 && words <= 4);
        var charLike = s2.length > 0 && s2.length <= 40 && !endP && (capsName || ctr < 0.07 || f >= 0.26 || (brk && s2.length <= 24 && words <= 3));
        var nextInd = q && !qScene && qf >= 0.07;
        if (after === 'dial' && !brk && !(charLike && nextInd && (f >= 0.26 || ctr < 0.05) && s2.length <= 24)) { appendTo(last, t); return; }
        if (charLike && nextInd) { push('char', cleanName(t)); after = 'char'; return; }
        if (after === 'dial') { push('dial', t); return; }
        if (last && last.t === 'action' && !brk) appendTo(last, t); else push('action', t); after = 'action';
      });
    }
    if (!blocks.length) throw new Error('No script text found in this PDF');
    d.blocks = blocks;
    d.lang = THK.detectLang(blocks.map(function (b) { return b.x; }).join(' '));
    d.font = THK.defaultFont(d.lang);
    d.rtl = THK.lang(d.lang).rtl;
    if (!d.title) d.title = 'Imported script';
    return d;
  };

  /* ------------------------------------------------------------------ public entry */
  THK.parsePdf = function (buf, fname) {
    var payload = function (doc) {
      var n = Math.min(doc.numPages, 3), i = 0, hit = null;
      function nx() {
        if (hit || i >= n) return Promise.resolve(hit);
        return doc.getPage(++i).then(function (pg) { return pg.getAnnotations(); }).then(function (an) {
          an.forEach(function (a) { if (!hit && a.url && a.url.indexOf(THK.FNX) === 0) hit = a.url.slice(THK.FNX.length); }); return nx();
        });
      }
      return nx().then(function (b64) {
        if (!b64) return null;
        try { var js = decodeURIComponent(escape(atob(b64.replace(/-/g, '+').replace(/_/g, '/')))), d = JSON.parse(js); if (d && d.blocks && d.blocks.length) { delete d.id; return d; } } catch (e) { }
        return null;
      });
    };
    return load().then(function (pdfjs) {
      return pdfjs.getDocument({ data: new Uint8Array(buf), cMapUrl: url('vendor/pdfjs/cmaps/'), cMapPacked: true, isEvalSupported: false, useSystemFonts: true, verbosity: 0 }).promise;
    }).then(function (doc) {
      return payload(doc).then(function (exact) { return exact ? { exact: exact, doc: doc } : { doc: doc }; });
    }).then(function (o) {
      if (o.exact) { try { o.doc.destroy(); } catch (e) { } return o.exact; }
      var doc = o.doc, n = Math.min(doc.numPages, 400), out = [], i = 0;
      function next() {
        if (i >= n) return Promise.resolve(out);
        return doc.getPage(++i).then(function (pg) {
          var vp = pg.getViewport({ scale: 1 });
          return pg.getTextContent({ includeMarkedContent: false }).then(function (tc) { out.push(pageRows(tc, vp.width, vp.height)); pg.cleanup && pg.cleanup(); return next(); });
        });
      }
      return next().then(function (pages) { try { doc.destroy(); } catch (e) { } return THK.pdfPagesToScript(pages, fname); });
    });
  };
})();
