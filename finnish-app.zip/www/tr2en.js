/* Translate to English – turns a script written in any language into a new English script (the original stays untouched).
   Uses Google's free translate service, so it needs internet. Character names are turned into English letters by sound and shown to you first,
   so every name is spelled the same way all through the script. */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, T = THK.tr2en = {};
  var URL_ = 'https://translate.googleapis.com/translate_a/single';

  function post(q, extra) {
    var body = 'client=gtx&sl=auto&tl=en&dj=0&dt=t' + (extra || '') + '&q=' + encodeURIComponent(q);
    return fetch(URL_, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' }, body: body }).then(function (r) {
      if (!r.ok) throw new Error('Google answered ' + r.status);
      return r.json();
    });
  }
  function retry(fn, n) { return fn().catch(function (e) { if (n <= 0 || (e && e.cancelled)) throw e; return new Promise(function (ok) { setTimeout(ok, 700 * (4 - n)); }).then(function () { return retry(fn, n - 1); }); }); }
  function netErr(e) { return new Error(navigator.onLine === false ? 'Translate to English needs the internet. Connect and try again.' : 'Google could not be reached (' + ((e && e.message) || 'network') + '). Check the connection and try again.'); }

  /* one string -> English (keeps the line breaks inside it) */
  function one(s) { return retry(function () { return post(s); }, 2).then(function (d) { return { t: (d[0] || []).map(function (x) { return x && x[0] || ''; }).join(''), sl: d[2] }; }); }
  /* many single-line strings in one request; falls back to one-by-one if Google changes the number of lines */
  function many(list, st) {
    if (!list.length) return Promise.resolve([]);
    var txt = list.join('\n');
    return retry(function () { return post(txt); }, 2).then(function (d) {
      if (d[2] && !st.sl) st.sl = d[2];
      var out = (d[0] || []).map(function (x) { return x && x[0] || ''; }).join('').split('\n');
      if (out.length === list.length) return out.map(function (s) { return s.replace(/\s+$/, ''); });
      var res = []; return list.reduce(function (p, s, i) { return p.then(function () { if (st.cancel) throw { cancelled: true }; return one(s).then(function (r) { res[i] = r.t; }); }); }, Promise.resolve()).then(function () { return res; });
    });
  }
  /* a name -> its sound in English letters */
  function nameSound(n) {
    return retry(function () { return post(n, '&dt=rm'); }, 2).then(function (d) {
      var tr = '', en = '';
      (d[0] || []).forEach(function (seg) { if (!seg) return; en += seg[0] || ''; if (seg[3]) tr += seg[3]; });
      var s = (tr || en || n).trim();
      return s.replace(/\b([a-z])/g, function (m) { return m.toUpperCase(); });
    });
  }

  var HEAD = [[/^(inside|interior|indoors?|int\b)[\s.,:\-–]*/i, 'INT. '], [/^(outside|exterior|outdoors?|ext\b)[\s.,:\-–]*/i, 'EXT. ']];
  function fixHead(s) { s = s.trim(); if (!/^(INT|EXT|I\/E)\b/i.test(s)) for (var i = 0; i < HEAD.length; i++) if (HEAD[i][0].test(s)) { s = s.replace(HEAD[i][0], HEAD[i][1]); break; } return s.toUpperCase(); }
  function isLatin(s) { return !/[^\u0000-ɏ -⁯\s]/.test(s); }

  T.run = function () {
    var cur = A.cur; if (!cur) return;
    var blocks = cur.blocks.filter(function (b) { return b.t !== 'img'; });
    if (!blocks.some(function (b) { return (b.x || '').trim(); })) return A.toastIn('There is nothing to translate yet');
    var st = { cancel: false, sl: '' };
    var names = {}, order = [];
    blocks.forEach(function (b) { if (b.t === 'char') { var n = (b.x || '').replace(/\(.*?\)/g, '').replace(/[:：]\s*$/, '').trim(); if (n && !names[n]) { names[n] = ''; order.push(n); } } });
    var wrap = el('div', ''), msg = el('p', '', 'Finding the character names…'), bar = el('div', '', '<div style="height:8px;border-radius:99px;background:rgba(128,128,128,.25);overflow:hidden"><div class="ocrbar" style="height:100%;width:2%;border-radius:99px;background:#5e6cf2;transition:width .25s"></div></div>');
    wrap.appendChild(msg); wrap.appendChild(bar); var fill = bar.querySelector('.ocrbar');
    var d1 = A.dlg('Translate to English', wrap, [{ l: 'Cancel', fn: function () { st.cancel = true; } }], { nofocus: true });
    function prog(v, t) { fill.style.width = Math.max(2, Math.min(100, Math.round(v * 100))) + '%'; if (t) msg.textContent = t; }
    function chk() { if (st.cancel) throw { cancelled: true }; }
    /* step 1 – names */
    var i = 0, p = Promise.resolve();
    order.forEach(function (n) {
      p = p.then(function () { chk(); return isLatin(n) ? n : nameSound(n); }).then(function (s) { names[n] = s; i++; prog(0.2 * i / Math.max(1, order.length)); });
    });
    p.then(function () { chk(); d1.close(); return askNames(names, order); }).then(function (map) {
      if (!map) return;
      var d2 = A.dlg('Translating…', (function () { var w = el('div', ''); w.appendChild(msg); w.appendChild(bar); return w; })(), [{ l: 'Cancel', fn: function () { st.cancel = true; } }], { nofocus: true });
      prog(0.02, 'Translating the script… (keep the app open)');
      return translateAll(cur, map, st, prog).then(function (copy) { d2.close(); if (!copy) return; done(copy, st); }, function (e) { d2.close(); throw e; });
    }).catch(function (e) {
      try { d1.close(); } catch (x) { }
      if (e && e.cancelled) return A.toastIn('Translation cancelled');
      A.dlg('Could not translate', '<p>' + esc(netErr(e).message) + '</p>', [{ l: 'Close', cls: 'pri' }]);
    });
  };

  function askNames(names, order) {
    return new Promise(function (resolve) {
      if (!order.length) return resolve({});
      var w = el('div', ''), list = el('div', 'pdflist'), inputs = {};
      w.appendChild(el('p', '', 'These are the character names as they sound in English letters. Fix any spelling now – every place the name appears will use it.'));
      order.forEach(function (n) { var r = el('div', 'trrow'); r.appendChild(el('span', 'trsrc', esc(n))); var i = el('input'); i.type = 'text'; i.value = names[n]; i.setAttribute('autocapitalize', 'words'); inputs[n] = i; r.appendChild(i); list.appendChild(r); });
      w.appendChild(list);
      A.dlg('Check the names (' + order.length + ')', w, [{ l: 'Cancel', fn: function () { resolve(null); } }, { l: 'Translate', cls: 'pri', fn: function () { var m = {}; order.forEach(function (n) { m[n] = (inputs[n].value || names[n]).trim(); }); resolve(m); } }], { nofocus: true });
    });
  }

  function translateAll(cur, nameMap, st, prog) {
    var uniq = {}, list = [];
    function want(s) { s = (s || '').replace(/\s*\n\s*/g, ' ').trim(); if (s && !uniq.hasOwnProperty(s)) { uniq[s] = null; list.push(s); } return s; }
    cur.blocks.forEach(function (b) { if (b.t === 'img') return; if (b.t === 'char') return; want(b.x); if (b.x2) want(b.x2); });
    want(cur.title);
    var batches = [], bt = [], len = 0;
    list.forEach(function (s) { if (bt.length && (len + s.length > 1400 || bt.length >= 40)) { batches.push(bt); bt = []; len = 0; } bt.push(s); len += s.length + 1; });
    if (bt.length) batches.push(bt);
    var done = 0, conc = 3, idx = 0, failed = null;
    return new Promise(function (resolve, reject) {
      if (!batches.length) return resolve(build());
      function next() {
        if (failed) return; if (st.cancel) { failed = { cancelled: true }; return reject(failed); }
        if (idx >= batches.length) { if (done >= batches.length) resolve(build()); return; }
        var b = batches[idx++];
        many(b, st).then(function (out) { b.forEach(function (s, k) { uniq[s] = (out[k] || '').trim() || s; }); done++; prog(0.05 + 0.93 * done / batches.length, 'Translating… ' + Math.round(100 * done / batches.length) + '%'); next(); }, function (e) { failed = e; reject(e); });
      }
      for (var k = 0; k < conc; k++) next();
    }).then(function (copy) { return copy; });

    function tr(s) { var k = (s || '').replace(/\s*\n\s*/g, ' ').trim(); return k ? (uniq[k] || k) : ''; }
    function build() {
      var c = JSON.parse(JSON.stringify(cur)); c.id = A.uid(); delete c.path; delete c.updated;
      c.title = tr(cur.title) || cur.title; c.lang = 'en'; c.font = THK.defaultFont('en'); delete c.titleFont; delete c.cfm;
      c.title = (c.title + ' (English)').slice(0, 120);
      c.blocks = c.blocks.map(function (b) {
        if (b.t === 'img') return b; delete b.fm;
        if (b.t === 'char') {
          var raw = b.x || '', core = raw.replace(/\(.*?\)/g, '').replace(/[:：]\s*$/, '').trim(), ext = (raw.match(/\((.*?)\)/) || [])[1];
          var nm = nameMap[core] || core; if (ext) nm += ' (' + (isLatin(ext) ? ext : (tr(ext) || ext)).toUpperCase() + ')'; b.x = nm.toUpperCase(); return b;
        }
        b.x = tr(b.x); if (b.t === 'scene') { b.x = fixHead(b.x); if (b.x2 != null) b.x2 = tr(b.x2).toUpperCase(); }
        else if (b.t === 'trans') b.x = b.x.toUpperCase();
        return b;
      });
      return c;
    }
  }

  function done(copy, st) {
    var w = el('div', '', '<p>Your English script is ready' + (st.sl ? ' (the original language was detected as <b>' + esc(st.sl) + '</b>)' : '') + '. The original script is unchanged. Machine translation is good for understanding, but please read it through before sharing.</p>');
    A.dlg('Done', w, [{ l: 'Stay here' }, { l: 'Open English script', cls: 'pri', fn: function () { setTimeout(function () { A.openDoc(A.norm(copy), true); }, 60); } }]);
  }
  var st = document.createElement('style'); st.textContent = '.trrow{display:flex;gap:8px;align-items:center;margin:6px 0}.trsrc{flex:0 0 38%;opacity:.8;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.trrow input{flex:1;min-width:0;padding:8px 12px;border-radius:99px;border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit;font:inherit}';
  document.head.appendChild(st);
})();
