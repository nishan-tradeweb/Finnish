/* Game Centre — tiny offline arcade. Each game: {id,name,tag,icon,start(host,api)->{stop}} */
(function () {
  'use strict';
  window.THK = window.THK || {};
  var G = THK.games = {}, root = null, live = null;
  var KEY = 'finnish.games';
  function load() { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; } }
  function best(id) { return (load()[id] || {}).best || 0; }
  function setBest(id, n) { var d = load(); d[id] = d[id] || {}; if (n > (d[id].best || 0)) { d[id].best = n; try { localStorage.setItem(KEY, JSON.stringify(d)); } catch (e) { } return true; } return false; }
  function el(t, c, h) { var e = document.createElement(t); if (c) e.className = c; if (h != null) e.innerHTML = h; return e; }

  var css = '#gc{position:fixed;inset:0;z-index:80;display:flex;flex-direction:column;background:linear-gradient(140deg,var(--bg1),var(--bg2));color:var(--ink);font-family:var(--ui);animation:fade .22s;touch-action:manipulation;-webkit-user-select:none;user-select:none}' +
    '#gc .gh{display:flex;align-items:center;gap:10px;padding:calc(max(10px,env(safe-area-inset-top)) + 4px) 16px 8px}#gc .gh .tt{flex:1;min-width:0}#gc .gh h1{margin:0;font-size:26px;font-weight:800;background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent;width:max-content;max-width:100%}#gc .gh small{color:var(--ink2);font-size:13px}' +
    '#gc .gg{flex:1;overflow:auto;padding:10px 16px calc(env(safe-area-inset-bottom) + 20px);display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:14px;align-content:start}' +
    '#gc .gcard{border-radius:28px;padding:16px 12px 14px;display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center;cursor:pointer;background:var(--glass);border:1px solid var(--edge);-webkit-backdrop-filter:blur(22px) saturate(1.7);backdrop-filter:blur(22px) saturate(1.7);box-shadow:var(--shadow),inset 0 2px 0 rgba(255,255,255,.55);transition:transform .15s}#gc .gcard:active{transform:scale(.96)}' +
    '#gc .gcard .ic{width:84px;height:84px;border-radius:24px;display:flex;align-items:center;justify-content:center;background:linear-gradient(160deg,rgba(255,255,255,.5),rgba(255,255,255,.08));border:1px solid var(--edge);box-shadow:inset 0 2px 0 rgba(255,255,255,.6),0 8px 20px rgba(60,60,140,.25)}#gc .gcard b{font-size:17px}#gc .gcard small{color:var(--ink2);font-size:12.5px}' +
    '#gc .gcard.soon{cursor:default;opacity:.55;border-style:dashed}#gc .gcard.soon:active{transform:none}' +
    '#gc .pill{display:inline-block;padding:3px 11px;border-radius:99px;font-size:12px;font-weight:700;background:rgba(94,108,242,.16);color:var(--acc)}' +
    '#gc .gplay{position:relative;flex:1;min-height:0;overflow:hidden}#gc canvas{position:absolute;inset:0;width:100%;height:100%;display:block;touch-action:none}' +
    '#gc .hud{position:absolute;left:0;right:0;top:0;display:flex;align-items:flex-start;justify-content:space-between;gap:8px;padding:calc(max(10px,env(safe-area-inset-top)) + 4px) 14px 0;pointer-events:none}#gc .hud .btn{pointer-events:auto}' +
    '#gc .sc{position:absolute;left:0;right:0;top:calc(max(10px,env(safe-area-inset-top)) + 56px);text-align:center;pointer-events:none}#gc .sc b{display:block;font-size:64px;line-height:1;font-weight:800;color:var(--ink);text-shadow:0 4px 18px rgba(94,108,242,.35)}#gc .sc small{font-size:13px;color:var(--ink2);letter-spacing:.08em;text-transform:uppercase}' +
    '#gc .hint{position:absolute;left:0;right:0;bottom:calc(env(safe-area-inset-bottom) + 34px);text-align:center;color:var(--ink2);font-size:15px;pointer-events:none;transition:opacity .3s}' +
    '#gc .perf{position:absolute;left:0;right:0;top:34%;text-align:center;pointer-events:none;font-weight:800;font-size:22px;color:var(--acc);opacity:0}#gc .perf.go{animation:gperf .7s ease-out}@keyframes gperf{0%{opacity:0;transform:translateY(10px) scale(.8)}20%{opacity:1;transform:none}100%{opacity:0;transform:translateY(-26px)}}' +
    '#gc .over{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(10,14,24,.28);animation:fade .25s}#gc .over .card{width:min(340px,100%);border-radius:30px;padding:24px 22px;text-align:center;display:flex;flex-direction:column;gap:10px;background:var(--glass2);border:1px solid var(--edge);-webkit-backdrop-filter:blur(30px) saturate(1.8);backdrop-filter:blur(30px) saturate(1.8);box-shadow:0 20px 60px rgba(0,0,0,.35),inset 0 1px 0 rgba(255,255,255,.6)}' +
    '#gc .over h2{margin:0;font-size:22px}#gc .over .big{font-size:56px;font-weight:800;line-height:1;background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent}#gc .over .row{justify-content:center;margin-top:6px}' +
    '.btn>svg{width:24px;height:22px;vertical-align:-6px;margin-right:2px}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  /* ---- joystick icon (for home pill) ---- */
  G.joy = '<svg viewBox="0 0 26 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M7.4 6.5h11.2c2.4 0 4.4 1.7 4.9 4l1.2 5.6c.5 2.3-1.3 4.4-3.6 4.4-1.2 0-2.3-.6-3-1.6l-.9-1.4c-.4-.6-1-.9-1.7-.9h-5c-.7 0-1.3.3-1.7.9l-.9 1.4c-.7 1-1.8 1.6-3 1.6-2.3 0-4.1-2.1-3.6-4.4l1.2-5.6c.5-2.3 2.5-4 4.9-4z" fill="currentColor" fill-opacity=".14"/><path d="M8 9.8v4.6M5.7 12.1h4.6"/><circle cx="17.2" cy="10.9" r=".95" fill="currentColor" stroke="none"/><circle cx="19.4" cy="13" r=".95" fill="currentColor" stroke="none"/><circle cx="15" cy="13" r=".95" fill="currentColor" stroke="none"/><circle cx="17.2" cy="15.1" r=".95" fill="currentColor" stroke="none"/></svg>';

  /* ================= Game: Builder ================= */
  function iconSvg() {
    var out = '<svg viewBox="0 0 64 64" width="60" height="60">';
    [[32, 46, 26, 225], [32, 35, 20, 262], [32, 25, 15, 300], [32, 16, 10, 330]].forEach(function (b) {
      var x = b[0], y = b[1], w = b[2], h = b[3], q = w / 4, hw = w / 2, th = 8;
      function pg(pts, l) { var c = 'hsl(' + h + ',72%,' + l + '%)'; return '<path d="M' + pts.join('L') + 'Z" fill="' + c + '" stroke="' + c + '" stroke-width="2.4" stroke-linejoin="round"/>'; }
      out += pg([(x - hw) + ',' + y, x + ',' + (y + q), (x + hw) + ',' + y, x + ',' + (y - q)], 64) +
        pg([(x - hw) + ',' + y, x + ',' + (y + q), x + ',' + (y + q + th), (x - hw) + ',' + (y + th)], 42) +
        pg([x + ',' + (y + q), (x + hw) + ',' + y, (x + hw) + ',' + (y + th), x + ',' + (y + q + th)], 32);
    });
    return out + '</svg>';
  }
  var BUILDER_ICON = iconSvg();

  function builder(host, api) {
    var cv = el('canvas'), ctx = cv.getContext('2d'), W = 0, H = 0, S = 30, dpr = 1;
    host.appendChild(cv);
    var sc = el('div', 'sc', '<b>0</b><small>Height</small>'), hint = el('div', 'hint', 'Tap to drop the block'), perf = el('div', 'perf', 'Perfect');
    var hud = el('div', 'hud'), bestPill = el('span', 'btn sm', 'Best ' + api.best()); bestPill.style.pointerEvents = 'none';
    var closeB = el('button', 'btn', 'Close'); closeB.onclick = function () { api.exit(); };
    hud.appendChild(bestPill); hud.appendChild(closeB);
    host.appendChild(sc); host.appendChild(hud); host.appendChild(hint); host.appendChild(perf);
    var scoreEl = sc.firstChild;

    var BASE = 3.2, H1 = 0.62, GAP = 2.2, RANGE = 3.7;
    var tower, mv, cuts, fx, level, combo, camY, camT, state, over, raf = 0, last = 0, dead = false, dropT = 0, spd;
    function hue(n) { return (212 + n * 8) % 360; }
    function reset() {
      tower = [{ x: 0, z: 0, w: BASE, d: BASE, y: 0, hue: hue(0) }]; cuts = []; fx = []; level = 0; combo = 0; camY = camT = 0; state = 'play'; spawn();
      scoreEl.textContent = 0; hint.style.opacity = 1; hint.textContent = 'Tap to drop the block'; if (over) { over.remove(); over = null; }
    }
    function top() { return tower[tower.length - 1]; }
    function spawn() {
      var t = top(), ax = level % 2 === 0 ? 'x' : 'z';
      mv = { ax: ax, w: t.w, d: t.d, x: t.x, z: t.z, y: t.y + H1 + GAP, hue: hue(level + 1), dir: 1, p: -RANGE };
      spd = Math.min(5.2, 2.0 + level * 0.07); mv[ax] = t[ax] + mv.p;
    }
    function resize() {
      var r = host.getBoundingClientRect(); dpr = Math.min(2, window.devicePixelRatio || 1); W = r.width; H = r.height;
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      S = Math.min(W * 0.07, H * 0.062);
    }
    function P(x, y, z) { return [W / 2 + (x - z) * 0.866 * S, H * 0.64 + (x + z) * 0.5 * S - (y - camY) * S]; }
    function col(h, l) { return 'hsl(' + h + ',72%,' + l + '%)'; }
    function box(b, h, alpha) {
      var x0 = b.x - b.w / 2, x1 = b.x + b.w / 2, z0 = b.z - b.d / 2, z1 = b.z + b.d / 2, y0 = b.y, y1 = b.y + (b.h || H1), hh = b.hue;
      var A = P(x0, y1, z0), B = P(x1, y1, z0), C = P(x1, y1, z1), D = P(x0, y1, z1), E = P(x1, y0, z0), F = P(x1, y0, z1), G2 = P(x0, y0, z1);
      if (alpha != null) ctx.globalAlpha = alpha;
      ctx.lineJoin = 'round'; ctx.lineWidth = S * 0.16;
      poly([D, C, F, G2], col(hh, 40));           // front-left face
      poly([B, E, F, C], col(hh, 30));            // right face
      poly([A, B, C, D], col(hh, 62));            // top
      if (alpha != null) ctx.globalAlpha = 1;
    }
    function poly(p, c) { ctx.beginPath(); ctx.moveTo(p[0][0], p[0][1]); for (var i = 1; i < p.length; i++) ctx.lineTo(p[i][0], p[i][1]); ctx.closePath(); ctx.fillStyle = c; ctx.strokeStyle = c; ctx.fill(); ctx.stroke(); }
    function draw() {
      ctx.clearRect(0, 0, W, H);
      var lo = Math.max(0, Math.floor(camY / H1) - 3);
      // shadow-ish soft base pillar
      var b0 = tower[0]; box({ x: b0.x, z: b0.z, w: b0.w, d: b0.d, y: -40, h: 40, hue: b0.hue });
      for (var i = lo; i < tower.length; i++) { var t = tower[i]; if (P(t.x, t.y, t.z)[1] < -S * 3) continue; box(t); }
      if (state !== 'dead' || mv.fall) { if (mv) box(mv); }
      for (i = 0; i < cuts.length; i++) box(cuts[i], 0, Math.max(0, cuts[i].a));
      for (i = 0; i < fx.length; i++) {
        var f = fx[i], t2 = top(), a = P(f.x - f.w / 2, f.y, f.z - f.d / 2), b = P(f.x + f.w / 2, f.y, f.z - f.d / 2), c = P(f.x + f.w / 2, f.y, f.z + f.d / 2), d = P(f.x - f.w / 2, f.y, f.z + f.d / 2);
        var g = f.t; ctx.globalAlpha = Math.max(0, 1 - g * 1.7); ctx.lineWidth = 3; ctx.strokeStyle = '#fff';
        var k = 1 + g * 0.55, cx = (a[0] + c[0]) / 2, cy = (a[1] + c[1]) / 2;
        ctx.beginPath(); [a, b, c, d].forEach(function (q, j) { var X = cx + (q[0] - cx) * k, Y = cy + (q[1] - cy) * k; j ? ctx.lineTo(X, Y) : ctx.moveTo(X, Y); }); ctx.closePath(); ctx.stroke(); ctx.globalAlpha = 1;
      }
    }
    function step(dt) {
      if (state === 'play') {
        mv.p += mv.dir * spd * dt; if (mv.p > RANGE) { mv.p = RANGE; mv.dir = -1; } else if (mv.p < -RANGE) { mv.p = -RANGE; mv.dir = 1; }
        mv[mv.ax] = top()[mv.ax] + mv.p;
      } else if (state === 'drop') {
        dropT += dt; var u = Math.min(1, dropT / 0.13), tgt = top().y + H1; mv.y = tgt + (mv.yStart - tgt) * (1 - u * u);
        if (u >= 1) { mv.y = tgt; land(); }
      }
      camY += (camT - camY) * Math.min(1, dt * 5);
      for (var i = cuts.length - 1; i >= 0; i--) { var c = cuts[i]; c.vy -= 26 * dt; c.y += c.vy * dt; c.a -= dt * 1.1; if (c.a <= 0 || c.y < camY - 22) cuts.splice(i, 1); }
      for (i = fx.length - 1; i >= 0; i--) { fx[i].t += dt * 2.2; if (fx[i].t >= 1) fx.splice(i, 1); }
    }
    function drop() {
      if (state !== 'play') return; state = 'drop'; dropT = 0; mv.yStart = mv.y; hint.style.opacity = 0;
    }
    function land() {
      var t = top(), ax = mv.ax, sz = ax === 'x' ? 'w' : 'd', s = t[sz], delta = mv[ax] - t[ax], ad = Math.abs(delta);
      var lo = Math.max(mv[ax] - s / 2, t[ax] - s / 2), hi = Math.min(mv[ax] + s / 2, t[ax] + s / 2), ov = hi - lo;
      if (ov < 0.06) { // miss
        cuts.push({ x: mv.x, z: mv.z, w: mv.w, d: mv.d, y: mv.y, vy: 0, hue: mv.hue, a: 1 }); mv = { x: 0, z: 0, w: 0, d: 0, y: -99, hue: 0, fall: false }; state = 'dead'; end(); return;
      }
      var nb = { x: t.x, z: t.z, w: t.w, d: t.d, y: t.y + H1, hue: mv.hue };
      if (ad <= 0.14) { // perfect
        combo++; fx.push({ x: t.x, z: t.z, w: t.w, d: t.d, y: nb.y + H1, t: 0 });
        if (combo >= 3) nb[sz] = Math.min(BASE, nb[sz] + 0.22);
        perf.textContent = combo > 1 ? 'Perfect ×' + combo : 'Perfect'; perf.classList.remove('go'); void perf.offsetWidth; perf.classList.add('go'); try { navigator.vibrate && navigator.vibrate(8); } catch (e) { }
      } else {
        combo = 0; nb[ax] = (lo + hi) / 2; nb[sz] = ov;
        var cutC, cutS = ad; cutC = delta > 0 ? hi + cutS / 2 : lo - cutS / 2;
        var cp = { x: mv.x, z: mv.z, w: mv.w, d: mv.d, y: mv.y, vy: 0, hue: mv.hue, a: 1 }; cp[ax] = cutC; cp[sz] = cutS; cuts.push(cp);
      }
      tower.push(nb); level++; scoreEl.textContent = level; camT = nb.y - 0; state = 'play'; spawn();
    }
    function end() {
      var nb = api.setBest(level); bestPill.textContent = 'Best ' + api.best();
      over = el('div', 'over', '<div class="card"><h2>' + (nb && level > 0 ? 'New best!' : 'Tower complete') + '</h2><div class="big">' + level + '</div><small style="color:var(--ink2)">Best ' + api.best() + '</small><div class="row"></div></div>');
      var row = over.querySelector('.row'), a = el('button', 'btn on', 'Play again'), b = el('button', 'btn', 'Close');
      a.onclick = function () { reset(); }; b.onclick = function () { api.exit(); }; row.appendChild(a); row.appendChild(b);
      setTimeout(function () { if (!dead) host.appendChild(over); }, 450);
    }
    function loop(ts) {
      if (dead) return; raf = requestAnimationFrame(loop);
      var dt = Math.min(0.05, (ts - last) / 1000 || 0.016); last = ts; step(dt); draw();
    }
    function onDown(e) { if (e.target.closest && (e.target.closest('.btn') || e.target.closest('.over'))) return; e.preventDefault(); drop(); }
    function onKey(e) { if (e.code === 'Space' || e.key === 'Enter') { e.preventDefault(); if (over) reset(); else drop(); } else if (e.key === 'Escape') api.exit(); }
    function onVis() { if (document.hidden) { cancelAnimationFrame(raf); raf = 0; } else if (!raf && !dead) { last = performance.now(); raf = requestAnimationFrame(loop); } }
    host.addEventListener('pointerdown', onDown); window.addEventListener('keydown', onKey); window.addEventListener('resize', resize); document.addEventListener('visibilitychange', onVis);
    resize(); reset(); last = performance.now(); raf = requestAnimationFrame(loop);
    return {
      stop: function () { dead = true; cancelAnimationFrame(raf); if (state !== 'dead') api.setBest(level); host.removeEventListener('pointerdown', onDown); window.removeEventListener('keydown', onKey); window.removeEventListener('resize', resize); document.removeEventListener('visibilitychange', onVis); },
      _t: function () { return { level: level, state: state, tower: tower, mv: mv, drop: drop, land: land, step: step }; }
    };
  }

  /* ================= shared bits for the calm games ================= */
  var calmCss = '#gc .lsg{position:absolute;left:50%;top:54%;transform:translate(-50%,-50%);display:grid;gap:10px;width:min(86vw,48vh,380px);aspect-ratio:1}' +
    '#gc .lsc{border-radius:24%;padding:0;cursor:pointer;border:var(--S-bd,1px solid var(--edge));background:var(--S-bg,var(--glass));box-shadow:var(--S-sh,var(--shadow));transition:background .2s,box-shadow .2s,transform .12s}#gc .lsc:active{transform:scale(.94)}' +
    '#gc .lsc.lit,#gc .lsc.ok{background:linear-gradient(150deg,hsl(var(--gh,212),64%,74%),hsl(var(--gh,212),58%,54%));border-color:transparent;box-shadow:0 8px 18px hsla(var(--gh,212),55%,45%,.32),inset 0 1px 0 rgba(255,255,255,.55)}#gc .lsc.miss{outline:2px dashed var(--ink2);outline-offset:-5px}' +
    '#gc .lsc.bad{animation:lsshake .34s;background:var(--P-bg,var(--glass2));box-shadow:var(--P-sh,none)}@keyframes lsshake{25%{transform:translateX(-6px)}60%{transform:translateX(6px)}}' +
    'html[data-dyn=black] #gc .lsc.lit,html[data-dyn=black] #gc .lsc.ok{box-shadow:0 0 20px hsla(var(--gh,212),70%,62%,.5),inset 0 1px 0 rgba(255,255,255,.4)}' +
    '#gc .ldots{display:block;margin-top:6px;font-size:13px;letter-spacing:6px;color:var(--ink2);min-height:16px}' +
    '#gc .sc.calm b{font-size:52px}#gc .sc.calm small{display:block}';
  var st2 = document.createElement('style'); st2.textContent = calmCss; document.head.appendChild(st2);

  function shell(host, api, label, hintTxt) {
    var sc = el('div', 'sc calm', '<b>1</b><small>' + label + '</small><span class="ldots"></span>'), hint = el('div', 'hint', hintTxt);
    var hud = el('div', 'hud'), bestPill = el('span', 'btn sm', 'Best ' + api.best()); bestPill.style.pointerEvents = 'none';
    var closeB = el('button', 'btn', 'Close'); closeB.onclick = function () { api.exit(); };
    hud.appendChild(bestPill); hud.appendChild(closeB); host.appendChild(sc); host.appendChild(hud); host.appendChild(hint);
    return { num: sc.firstChild, dots: sc.lastChild, hint: hint, best: function () { bestPill.textContent = 'Best ' + api.best(); } };
  }
  function endCard(host, api, ui, score, again, delay) {
    var nb = api.setBest(score); ui.best();
    var o = el('div', 'over', '<div class="card"><h2>' + (nb && score > 0 ? 'New best!' : 'Well played') + '</h2><div class="big">' + score + '</div><small style="color:var(--ink2)">Best ' + api.best() + '</small><div class="row"></div></div>');
    var row = o.querySelector('.row'), a = el('button', 'btn on', 'Play again'), b = el('button', 'btn', 'Close');
    a.onclick = function () { o.remove(); again(); }; b.onclick = function () { api.exit(); }; row.appendChild(a); row.appendChild(b);
    return setTimeout(function () { host.appendChild(o); }, delay || 300);
  }
  function dotsTxt(on, total) { var s = ''; for (var i = 0; i < total; i++) s += (i < on ? '●' : '○') + (i < total - 1 ? ' ' : ''); return s; }

  /* ================= Game: Light Switch (memory) ================= */
  var LS_ICON = (function () { var s = '<svg viewBox="0 0 64 64" width="60" height="60" fill="none" stroke="currentColor" stroke-width="2.4">', on = { 1: 1, 3: 1, 8: 1 }; for (var i = 0; i < 9; i++) { var x = 8 + (i % 3) * 18, y = 8 + Math.floor(i / 3) * 18; s += '<rect x="' + x + '" y="' + y + '" width="14" height="14" rx="4.5"' + (on[i] ? ' fill="hsl(' + (212 + i * 22) + ',60%,64%)" stroke="none"' : ' fill="currentColor" fill-opacity=".1"') + '/>'; } return s + '</svg>'; })();
  function lightswitch(host, api) {
    var ui = shell(host, api, 'Level', 'Watch the lights, then tap them'), grid = el('div', 'lsg'); host.appendChild(grid);
    var lvl, chances, cells = [], set = {}, need, found, phase, tms = [], dead = false, endT = 0;
    function later(f, ms) { tms.push(setTimeout(f, ms)); }
    function clearT() { tms.forEach(clearTimeout); tms = []; }
    function size(l) { return l <= 3 ? 3 : l <= 7 ? 4 : l <= 12 ? 5 : 6; }
    function build() {
      var g = size(lvl), n = g * g; grid.innerHTML = ''; grid.style.gridTemplateColumns = 'repeat(' + g + ',1fr)'; cells = [];
      for (var i = 0; i < n; i++) { (function (i) { var c = el('button', 'lsc'); c.setAttribute('aria-label', 'Light ' + (i + 1)); c.addEventListener('pointerdown', function (e) { e.preventDefault(); tap(i); }); grid.appendChild(c); cells.push(c); })(i); }
    }
    function round() {
      clearT(); build(); var n = cells.length; need = Math.min(lvl + 2, Math.floor(n * 0.45)); set = {}; found = 0; phase = 'show';
      var k = 0; while (k < need) { var r = Math.floor(Math.random() * n); if (!set[r]) { set[r] = 1; k++; } }
      grid.style.setProperty('--gh', (212 + lvl * 18) % 360); ui.num.textContent = lvl; ui.dots.textContent = dotsTxt(chances, 3); ui.hint.textContent = 'Watch the lights…'; ui.hint.style.opacity = 1;
      later(function () { cells.forEach(function (c, i) { if (set[i]) c.classList.add('lit'); }); }, 500);
      later(function () { cells.forEach(function (c) { c.classList.remove('lit'); }); phase = 'input'; ui.hint.textContent = 'Now tap where they were'; }, 500 + 1000 + need * 160);
    }
    function reset() { clearT(); lvl = 1; chances = 3; round(); }
    function tap(i) {
      if (phase !== 'input' || cells[i].classList.contains('ok') || cells[i].classList.contains('bad')) return;
      if (set[i]) {
        cells[i].classList.add('ok'); try { navigator.vibrate && navigator.vibrate(6); } catch (e) { }
        if (++found === need) { phase = 'wait'; lvl++; ui.hint.textContent = 'Lovely'; later(round, 800); }
      } else {
        cells[i].classList.add('bad'); chances--; ui.dots.textContent = dotsTxt(chances, 3); phase = 'wait'; ui.hint.textContent = chances ? 'Here they were — try again' : '';
        cells.forEach(function (c, j) { if (set[j] && !c.classList.contains('ok')) c.classList.add('lit', 'miss'); });
        if (chances > 0) later(round, 1500); else endT = endCard(host, api, ui, lvl - 1, reset, 1300);
      }
    }
    function onKey(e) { if (e.key === 'Escape') api.exit(); }
    window.addEventListener('keydown', onKey); reset();
    return {
      stop: function () { dead = true; clearT(); clearTimeout(endT); if (phase !== 'wait' || chances > 0) api.setBest(lvl - 1); window.removeEventListener('keydown', onKey); },
      _t: function () { return { lvl: lvl, chances: chances, set: set, phase: phase, tap: tap, cells: cells }; }
    };
  }

  /* ================= Game: Ripple (calm) ================= */
  var RP_ICON = '<svg viewBox="0 0 64 64" width="60" height="60" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="32" cy="32" r="8" stroke="hsl(222,62%,62%)"/><circle cx="32" cy="32" r="16" stroke="hsl(250,56%,68%)" stroke-opacity=".8"/><circle cx="32" cy="32" r="25" stroke="hsl(282,52%,72%)" stroke-opacity=".6"/><circle cx="32" cy="32" r="3.2" fill="hsl(222,62%,62%)" stroke="none"/><circle cx="50" cy="17" r="3" fill="hsl(268,56%,68%)" stroke="none"/><circle cx="14" cy="45" r="3" fill="currentColor" fill-opacity=".3" stroke="none"/></svg>';
  function ripple(host, api) {
    var cv = el('canvas'), ctx = cv.getContext('2d'), W = 0, H = 0, dpr = 1, ink = '#222'; host.appendChild(cv);
    var ui = shell(host, api, 'Level', 'Tap to send a ripple'), MAXR = 170, SPEED = 150;
    var lvl = 1, taps = 0, dots = [], rips = [], state = '', raf = 0, last = 0, dead = false, ac = null, lastNote = 0, endT = 0, winT = 0;
    function resize() {
      var r = host.getBoundingClientRect(), ow = W, oh = H; W = r.width; H = r.height; dpr = Math.min(2, window.devicePixelRatio || 1); cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ink = getComputedStyle(host).color; MAXR = Math.max(110, Math.min(190, Math.min(W, H) * 0.36));
      if (ow && dots) dots.forEach(function (d) { d.x *= W / ow; d.y *= H / oh; }); kick();
    }
    function note(i) {
      var t = performance.now(); if (t - lastNote < 70) return; lastNote = t;
      try {
        if (!ac) ac = new (window.AudioContext || window.webkitAudioContext)(); var o = ac.createOscillator(), g = ac.createGain(), n = ac.currentTime;
        o.type = 'sine'; o.frequency.value = [392, 440, 523, 587, 659, 784][i % 6]; g.gain.setValueAtTime(0, n); g.gain.linearRampToValueAtTime(0.05, n + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, n + 0.6); o.connect(g); g.connect(ac.destination); o.start(); o.stop(n + 0.65);
      } catch (e) { }
    }
    function gen() {
      var K = Math.min(5, 1 + Math.floor((lvl - 1) / 2)), D = Math.min(3 + lvl, 15), top = 150, bot = 90, m = 36, cs = [], i, tries;
      taps = K + 1; dots = []; rips = []; state = 'play';
      for (i = 0; i < K; i++) {
        for (tries = 0; tries < 40; tries++) {
          var p = { x: m + MAXR * 0.5 + Math.random() * Math.max(1, W - 2 * m - MAXR), y: top + MAXR * 0.4 + Math.random() * Math.max(1, H - top - bot - MAXR * 0.8) };
          if (cs.every(function (c) { return Math.hypot(c.x - p.x, c.y - p.y) > MAXR * (tries < 30 ? 1.5 : 0.9); })) { cs.push(p); break; }
        }
        if (cs.length <= i) cs.push({ x: W / 2, y: H / 2 });
      }
      for (i = 0; i < D; i++) {
        var c = cs[i % K];
        for (tries = 0; tries < 30; tries++) {
          var a = Math.random() * 6.283, r = MAXR * (0.2 + Math.random() * 0.62), x = Math.max(m, Math.min(W - m, c.x + Math.cos(a) * r)), y = Math.max(top, Math.min(H - bot, c.y + Math.sin(a) * r));
          if (dots.every(function (d) { return Math.hypot(d.x - x, d.y - y) > 34; }) && Math.hypot(x - c.x, y - c.y) < MAXR * 0.9) { dots.push({ x: x, y: y, lit: 0, t: 1 }); break; }
        }
      }
      ui.num.textContent = lvl; ui.dots.textContent = dotsTxt(taps, K + 1); kick();
    }
    function reset() { clearTimeout(endT); clearTimeout(winT); lvl = 1; ui.hint.style.opacity = 1; gen(); }
    function tap(x, y) {
      if (state !== 'play' || taps <= 0) return; taps--; rips.push({ x: x, y: y, r: 0 }); ui.hint.style.opacity = 0;
      var tot = Math.min(5, 1 + Math.floor((lvl - 1) / 2)) + 1; ui.dots.textContent = dotsTxt(taps, tot); kick();
    }
    function step(dt) {
      var any = false, i, j;
      for (i = rips.length - 1; i >= 0; i--) {
        var q = rips[i]; q.r += SPEED * dt;
        for (j = 0; j < dots.length; j++) { var d = dots[j]; if (!d.lit && q.r >= Math.hypot(d.x - q.x, d.y - q.y)) { d.lit = 1; d.t = 0; note(j); } }
        if (q.r > MAXR) rips.splice(i, 1);
      }
      for (j = 0; j < dots.length; j++) if (dots[j].t < 1) dots[j].t = Math.min(1, dots[j].t + dt * 1.4);
      if (state === 'play') {
        var all = dots.every(function (d) { return d.lit; });
        if (all) { state = 'win'; ui.hint.textContent = 'Lovely'; ui.hint.style.opacity = 1; winT = setTimeout(function () { if (dead) return; lvl++; ui.hint.style.opacity = 0; ui.hint.textContent = 'Tap to send a ripple'; gen(); }, 1000); }
        else if (taps <= 0 && !rips.length) { state = 'over'; endT = endCard(host, api, ui, lvl - 1, reset, 500); }
      }
      return rips.length > 0 || dots.some(function (d) { return d.t < 1; });
    }
    function hc(j, l) { return 'hsl(' + (((212 + lvl * 18) + j * 16) % 360) + ',58%,' + (l || 62) + '%)'; }
    function draw() {
      ctx.clearRect(0, 0, W, H); ctx.strokeStyle = hc(0, 60); ctx.fillStyle = ink; var i;
      for (i = 0; i < rips.length; i++) { var q = rips[i], k = 1 - q.r / MAXR; ctx.lineWidth = 2.4; ctx.globalAlpha = 0.6 * k; ctx.beginPath(); ctx.arc(q.x, q.y, q.r, 0, 6.2832); ctx.stroke(); ctx.lineWidth = 1.4; ctx.globalAlpha = 0.28 * k; ctx.beginPath(); ctx.arc(q.x, q.y, Math.max(0, q.r - 16), 0, 6.2832); ctx.stroke(); }
      for (i = 0; i < dots.length; i++) {
        var d = dots[i];
        if (d.lit) { var e = 1 - Math.pow(1 - d.t, 3), cc = hc(i, 62); ctx.strokeStyle = cc; ctx.fillStyle = cc; ctx.globalAlpha = (1 - d.t) * 0.6; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(d.x, d.y, 10 + 22 * e, 0, 6.2832); ctx.stroke(); ctx.globalAlpha = 0.2; ctx.beginPath(); ctx.arc(d.x, d.y, 20, 0, 6.2832); ctx.fill(); ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(d.x, d.y, 9, 0, 6.2832); ctx.fill(); ctx.strokeStyle = hc(0, 60); ctx.fillStyle = ink; }
        else { ctx.globalAlpha = 0.22; ctx.beginPath(); ctx.arc(d.x, d.y, 9, 0, 6.2832); ctx.fill(); ctx.strokeStyle = ink; ctx.globalAlpha = 0.4; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(d.x, d.y, 15, 0, 6.2832); ctx.stroke(); }
      }
      ctx.globalAlpha = 1;
    }
    function loop(ts) { raf = 0; if (dead) return; var dt = Math.max(0.001, Math.min(0.05, (ts - last) / 1000 || 0.016)); last = ts; var more = step(dt); draw(); if (more) raf = requestAnimationFrame(loop); }
    function kick() { if (!raf && !dead) { last = performance.now(); raf = requestAnimationFrame(loop); } draw(); }
    function onDown(e) { if (e.target.closest && (e.target.closest('.btn') || e.target.closest('.over'))) return; e.preventDefault(); var r = host.getBoundingClientRect(); tap(e.clientX - r.left, e.clientY - r.top); }
    function onKey(e) { if (e.key === 'Escape') api.exit(); }
    host.addEventListener('pointerdown', onDown); window.addEventListener('keydown', onKey); window.addEventListener('resize', resize);
    resize(); reset();
    return {
      stop: function () { dead = true; cancelAnimationFrame(raf); clearTimeout(endT); clearTimeout(winT); if (state !== 'over') api.setBest(lvl - 1); host.removeEventListener('pointerdown', onDown); window.removeEventListener('keydown', onKey); window.removeEventListener('resize', resize); try { ac && ac.close(); } catch (e) { } },
      _t: function () { return { lvl: lvl, taps: taps, dots: dots, rips: rips, state: state, tap: tap, step: step }; }
    };
  }

  var GAMES = [{ id: 'builder', name: 'Builder', tag: 'Stack the blocks', icon: BUILDER_ICON, start: builder },
    { id: 'ripple', name: 'Ripple', tag: 'Light every dot', icon: RP_ICON, start: ripple },
    { id: 'lights', name: 'Light Switch', tag: 'Remember the lights', icon: LS_ICON, start: lightswitch }];
  G.list = GAMES;
  G.h = { el: el, shell: shell, endCard: endCard, dotsTxt: dotsTxt };
  G.add = function (gm) { GAMES.push(gm); };

  function mk() { if (root) return root; root = el('div'); root.id = 'gc'; document.body.appendChild(root); return root; }
  function close() { if (live) { try { live.stop(); } catch (e) { } live = null; } if (root) { root.remove(); root = null; } }
  G.close = close;
  G.open = function () {
    mk(); root.innerHTML = '';
    var h = el('div', 'gh', '<div class="tt"><h1>Game Centre</h1><small>Quick breaks, fully offline</small></div>'), cb = el('button', 'btn', 'Close'); cb.onclick = close; h.appendChild(cb);
    var g = el('div', 'gg');
    GAMES.forEach(function (gm) {
      var c = el('div', 'gcard', '<div class="ic">' + gm.icon + '</div><b>' + gm.name + '</b><small>' + gm.tag + '</small><span class="pill">Best ' + best(gm.id) + '</span>');
      c.onclick = function () { G.play(gm.id); }; g.appendChild(c);
    });
    g.appendChild(el('div', 'gcard soon', '<div class="ic" style="font-size:30px;color:var(--ink2)">+</div><b>More soon</b><small>New games on the way</small>'));
    root.appendChild(h); root.appendChild(g);
  };
  G.play = function (id) {
    var gm = GAMES.filter(function (x) { return x.id === id; })[0]; if (!gm) return; mk(); root.innerHTML = '';
    var host = el('div', 'gplay'); root.appendChild(host);
    live = gm.start(host, { best: function () { return best(id); }, setBest: function (n) { return setBest(id, n); }, exit: function () { if (live) { try { live.stop(); } catch (e) { } live = null; } G.open(); } });
  };
  G._t = function () { return live && live._t && live._t(); };
})();
