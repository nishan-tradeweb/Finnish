/* finnish pro tools: production breakdown, character manager, stats & goals, search, backup, dictation,
   typography, header/footer designer, cover layouts, cinematic read mode, presentation PDF. */
(function () {
  var THK = window.THK, A = THK.app, $ = A.$, $$ = A.$$, el = A.el, esc = A.esc, S = A.S, toast = A.toast, dlg = A.dlg, P = THK.pro = {};
  function cur() { return A.cur; }
  function root() { return document.documentElement; }
  function pill(label, on, fn, cls) { var b = el('button', 'btn' + (on ? ' on' : '') + (cls ? ' ' + cls : ''), esc(A.clean(label))); b.onclick = fn; return b; }
  function row(p, cls) { var r = el('div', 'xrow' + (cls ? ' ' + cls : '')); if (p) p.appendChild(r); return r; }
  function head(p, t, sub) { p.appendChild(el('div', 'xhd', esc(t))); if (sub) p.appendChild(el('div', 'xsub', esc(sub))); }
  function wide(d) { d.classList.add('wide'); return d; }
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function dayKey(t) { var d = new Date(t || Date.now()); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function words(t) { t = String(t || '').trim(); return t ? t.split(/\s+/).length : 0; }
  function csvCell(v) { v = String(v == null ? '' : v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }
  function sync() { if (cur()) { var f = document.activeElement; if (f && f.blur && f.closest && f.closest('.ed')) { var q = f; try { q.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) { } } } }

  /* ============================================================ CSS */
  var css = '' +
    '.dlg.wide{width:min(780px,100%)}.dlg .xrow{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:6px 0}.dlg .xhd{font-weight:700;margin:12px 0 2px;text-align:center}.dlg .xsub{font-size:12.5px;color:var(--ink2);text-align:center;margin-bottom:4px}' +
    '.dlg .xin{width:100%;box-sizing:border-box;padding:10px 14px;border-radius:16px;border:1px solid var(--edge);background:var(--glass);color:var(--ink);font:inherit;margin:4px 0}.dlg textarea.xin{min-height:84px;resize:vertical}' +
    '.dlg .xin::placeholder{color:var(--ink2);opacity:.8}' +
    /* tables & cards inside dialogs */
    '.pcard{border-radius:20px;padding:12px 14px;background:var(--glass);border:1px solid var(--edge);color:var(--ink);margin:6px 0}.pcard b{color:var(--ink)}.pcard small,.pcard .mut{color:var(--ink2)}' +
    '.pcard .top{display:flex;gap:10px;align-items:baseline;justify-content:space-between;flex-wrap:wrap}.pcard .nm{font-weight:700;word-break:break-word}' +
    '.tag{display:inline-block;padding:2px 10px;border-radius:999px;font-size:11.5px;font-weight:600;background:var(--glass2);border:1px solid var(--edge);color:var(--ink);margin:2px 4px 2px 0}' +
    '.tag.day{background:rgba(255,196,60,.28)}.tag.night{background:rgba(70,80,200,.32)}.tag.evening{background:rgba(255,120,90,.28)}' +
    '.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:10px;margin:8px 0}.kpi{border-radius:22px;padding:12px 10px;text-align:center;background:var(--glass);border:1px solid var(--edge);color:var(--ink)}.kpi b{display:block;font-size:24px;line-height:1.2}.kpi span{font-size:12px;color:var(--ink2)}' +
    '.bar{height:12px;border-radius:999px;background:var(--glass);border:1px solid var(--edge);overflow:hidden;margin:6px 0}.bar i{display:block;height:100%;background:var(--grad);border-radius:999px;transition:width .4s}' +
    '.dlg input[type=range]{width:100%;accent-color:var(--acc);margin:4px 0}.slr{display:grid;grid-template-columns:110px 1fr 54px;gap:8px;align-items:center;color:var(--ink);font-size:13.5px}.slr output{text-align:right;color:var(--ink2);font-variant-numeric:tabular-nums}' +
    /* typography live preview */
    '.tp-prev{border-radius:12px;padding:5% 0;font-family:var(--font);font-size:9.5px;line-height:1.4;background:var(--pagec,#fff);color:var(--textc,#000);box-shadow:0 8px 24px rgba(0,0,0,.25);max-height:230px;overflow:hidden;position:relative;margin:4px 0}' +
    '.tp-prev .b{margin:0}.tp-prev .b.scene,.tp-prev .b.char,.tp-prev .b.trans{font-weight:700}.tp-prev .b.scene{text-transform:uppercase}.tp-prev .b.trans{text-align:right}' +
    '.hf-prev{position:relative;aspect-ratio:210/200;border-radius:10px;background:var(--pagec,#fff);color:var(--textc,#000);box-shadow:0 8px 24px rgba(0,0,0,.25);margin:4px auto;max-width:360px;overflow:hidden}.hf-prev i{position:absolute;font:normal 9px var(--ui);opacity:.8;padding:6px 10px;white-space:nowrap;max-width:46%;overflow:hidden;text-overflow:ellipsis}' +
    '.hf-prev .l{left:0}.hf-prev .c{left:50%;transform:translateX(-50%)}.hf-prev .r{right:0}.hf-prev .t{top:0}.hf-prev .u{bottom:0}.hf-prev em{position:absolute;left:14%;right:14%;top:26%;bottom:26%;background:repeating-linear-gradient(transparent 0 7px,rgba(128,128,128,.28) 7px 8px);opacity:.6}' +
    /* overlays (search, cinematic) are always dark glass so they read on every theme */
    '.srch{position:fixed;inset:0;z-index:70;color:var(--ink);animation:fade .18s;--cy:calc(50dvh - 30px);overflow:hidden}.srch.bye{opacity:0;transition:opacity .13s}.srch.has{--cy:calc(env(safe-area-inset-top,0px) + 18px)}.srch.out.has{--cy:calc(env(safe-area-inset-top,0px) + 132px)}' +
    '.srch.in{background:var(--glass);-webkit-backdrop-filter:blur(26px) saturate(1.3);backdrop-filter:blur(26px) saturate(1.3)}' +
    '.srch .sbg{position:absolute;inset:0;background:linear-gradient(140deg,var(--bg1),var(--bg2))}.srch .sbg.img{inset:-40px;background-size:cover;background-position:center;filter:blur(22px) brightness(.82)}' +
    '.srch.wall{--ink:#fff;--ink2:rgba(255,255,255,.78);--glass2:rgba(255,255,255,.18);--edge:rgba(255,255,255,.42)}html[data-wallmode=light] .srch.wall{--ink:#15151d;--ink2:rgba(21,21,29,.7);--glass2:rgba(255,255,255,.55);--edge:rgba(255,255,255,.8)}' +
    '.srch .stop{position:absolute;left:0;right:0;top:calc(env(safe-area-inset-top,0px) + 28px);text-align:center;pointer-events:none}.srch .stop .wm{width:min(54vw,250px)}.srch .stop p{margin:6px 0 0;letter-spacing:.14em;text-transform:uppercase;font-size:12px;font-weight:600;color:var(--ink2)}' +
    '.srch .sbar{position:absolute;left:50%;top:0;width:min(640px,calc(100% - 28px));display:flex;gap:10px;align-items:center;transform:translate(-50%,var(--cy));transition:transform .5s cubic-bezier(.22,.9,.25,1);will-change:transform}' +
    '.srch .sbar input{flex:1;min-width:0;height:56px;padding:0 22px;border-radius:999px;border:1px solid var(--edge);background:var(--glass2);color:var(--ink);font:inherit;font-size:17px;outline:none;-webkit-appearance:none;appearance:none;box-shadow:0 10px 30px rgba(0,0,0,.18),inset 0 1px 0 rgba(255,255,255,.35)}.srch .sbar input::placeholder{color:var(--ink2)}.srch .sbar input::-webkit-search-cancel-button{-webkit-appearance:none}' +
    '.srch .sbar .btn{height:56px;padding:0 20px;flex:0 0 auto}.srch.wall .sbar .btn{background:var(--glass2);color:var(--ink);border:1px solid var(--edge)}' +
    '.srch .shint{position:absolute;left:0;right:0;top:calc(50dvh + 44px);text-align:center;color:var(--ink2);font-size:14px;transition:opacity .25s}.srch.has .shint{opacity:0}' +
    '.srch .ol{position:absolute;left:50%;width:min(640px,calc(100% - 28px));transform:translate(-50%,16px);top:calc(env(safe-area-inset-top,0px) + 88px);bottom:0;overflow:auto;padding:4px 0 40px;opacity:0;pointer-events:none;transition:opacity .2s,transform .4s cubic-bezier(.22,.9,.25,1)}.srch.out .ol{top:calc(env(safe-area-inset-top,0px) + 202px)}.srch.has .ol{opacity:1;transform:translate(-50%,0);pointer-events:auto;transition-delay:.08s}' +
    '.srch .res{border-radius:24px;padding:13px 18px;margin:0 0 10px;background:var(--glass2);border:1px solid var(--edge);color:var(--ink);cursor:pointer}.srch .res b{display:block}.srch .res small{color:var(--ink2)}.srch .res p{margin:4px 0 0;font-size:14px;line-height:1.4;word-break:break-word}.srch mark{background:rgba(255,205,70,.6);color:inherit;border-radius:4px;padding:0 2px}.srch .none{color:var(--ink2);text-align:center;margin-top:26px}' +
    '@media(prefers-reduced-motion:reduce){.srch .sbar,.srch .ol{transition-duration:.01s}}' +
    '.ovl{position:fixed;inset:0;z-index:70;display:flex;flex-direction:column;background:rgba(10,10,24,.62);-webkit-backdrop-filter:blur(26px);backdrop-filter:blur(26px);color:#fff;padding-top:calc(max(8px,env(safe-area-inset-top)) + 8px)}' +
    '.ovl .btn{color:#fff!important;background:rgba(255,255,255,.14)!important;border:1px solid rgba(255,255,255,.34)!important}.ovl .btn.pri,.ovl .btn.on{background:var(--grad)!important;border-color:transparent!important}' +
    '.ovl .oh{display:flex;gap:8px;padding:0 14px 8px;align-items:center}.ovl .oh input{flex:1;min-width:0;padding:11px 16px;border-radius:999px;border:1px solid rgba(255,255,255,.38);background:rgba(255,255,255,.12);color:#fff;font:inherit;font-size:16px;outline:none}.ovl .oh input::placeholder{color:rgba(255,255,255,.6)}' +
    '.ovl .ol{flex:1;overflow:auto;padding:4px 14px 40px}.ovl .res{border-radius:22px;padding:12px 16px;margin:8px 0;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.26);cursor:pointer}.ovl .res b{display:block}.ovl .res small{opacity:.7}.ovl .res p{margin:4px 0 0;font-size:14px;line-height:1.4;opacity:.92;word-break:break-word}.ovl mark{background:rgba(255,205,70,.55);color:#fff;border-radius:4px;padding:0 2px}.ovl .none{opacity:.7;text-align:center;margin-top:30px}' +
    /* cinematic */
    '#cine{--wall:#e8e4db;--wall2:#f1ede5;background:var(--wall);padding:0;align-items:center;justify-content:center;z-index:75;overflow:hidden;touch-action:none;-webkit-user-select:none;user-select:none}html[data-theme=dark] #cine{--wall:#1a1a1d;--wall2:#101012}' +
    '#cine::before{content:"";position:absolute;inset:0;pointer-events:none;background:radial-gradient(110% 80% at 50% 12%,rgba(255,255,255,.34),transparent 62%),radial-gradient(120% 70% at 50% 108%,rgba(60,40,20,.10),transparent 60%)}html[data-theme=dark] #cine::before{background:radial-gradient(110% 80% at 50% 10%,rgba(255,255,255,.07),transparent 62%)}#cine.land{background:linear-gradient(180deg,var(--wall) 0,var(--wall) 74%,var(--wall2) 74%)}' +
    '#cine .stage{position:relative;display:flex;align-items:center;justify-content:center;width:100%;flex:1;min-height:0;padding:calc(max(8px,env(safe-area-inset-top)) + 8px) 12px 84px}#cine.land .stage{padding:20px 40px}' +
    '#cine .bk{position:relative;width:var(--bw);height:var(--ph);perspective:2600px;flex:none}' +
    '#cine .shell{position:absolute;left:-13px;right:-13px;top:-12px;bottom:-14px;border-radius:12px 12px 14px 14px;background:linear-gradient(180deg,#a2713f,#76492a 55%,#5f3a20);box-shadow:0 34px 44px -20px rgba(70,45,20,.55),0 6px 14px rgba(70,45,20,.25),inset 0 1px 0 rgba(255,255,255,.28),inset 0 0 0 1px rgba(0,0,0,.18)}#cine .shell::after{content:"";position:absolute;left:50%;top:0;bottom:0;width:12px;margin-left:-6px;background:linear-gradient(90deg,rgba(0,0,0,.28),rgba(0,0,0,.04) 50%,rgba(0,0,0,.28))}' +
    '#cine .pf{position:absolute;top:0;width:var(--pw);height:var(--ph);overflow:hidden;background:var(--pgc);color:var(--pgt);border-radius:2px 5px 5px 2px;backface-visibility:hidden;-webkit-backface-visibility:hidden;box-shadow:0 0 0 .6px rgba(0,0,0,.16),1px 1px 0 #ebe6dc,2px 2px 0 #d9d3c7,4px 5px 9px rgba(60,45,25,.28)}#cine .pf.l{border-radius:5px 2px 2px 5px;box-shadow:0 0 0 .6px rgba(0,0,0,.16),-1px 1px 0 #ebe6dc,-2px 2px 0 #d9d3c7}#cine .pf.r{box-shadow:0 0 0 .6px rgba(0,0,0,.16),1px 1px 0 #ebe6dc,2px 2px 0 #d9d3c7}#cine .bk.two .pf{box-shadow:0 0 0 .6px rgba(0,0,0,.14)}' +
    '#cine .pf::before{content:"";position:absolute;inset:0;pointer-events:none;opacity:.55;mix-blend-mode:multiply;background-image:url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'180\' height=\'180\'%3E%3Cfilter id=\'n\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'.85\' numOctaves=\'2\' stitchTiles=\'stitch\'/%3E%3CfeColorMatrix values=\'0 0 0 0 .45 0 0 0 0 .4 0 0 0 0 .34 0 0 0 .5 0\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23n)\'/%3E%3C/svg%3E")}#cine .bk.dk .pf::before{opacity:0}#cine .pf::after{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(90deg,rgba(0,0,0,.10),transparent 5%,transparent 94%,rgba(0,0,0,.05))}#cine .pf.l::after{background:linear-gradient(270deg,rgba(0,0,0,.26),rgba(0,0,0,.07) 9%,transparent 22%,transparent 96%,rgba(0,0,0,.06))}#cine .pf.r::after{background:linear-gradient(90deg,rgba(0,0,0,.26),rgba(0,0,0,.07) 9%,transparent 22%,transparent 96%,rgba(0,0,0,.06))}' +
    '#cine .pf .sh{position:absolute;inset:0;background:#000;opacity:0;pointer-events:none;z-index:3}#cine .pf .pn{position:absolute;left:0;right:0;bottom:calc(var(--py) * .38);text-align:center;font:600 calc(var(--fs) * .62) var(--ui,sans-serif);opacity:.42;font-style:normal;text-shadow:var(--tsh)}' +
    '#cine .cs{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:2}#cine .lf{position:absolute;top:0;width:var(--pw);height:var(--ph);transform-style:preserve-3d;transform-origin:left center;will-change:transform;z-index:4}#cine .lf .pf.bkf{left:0;transform:rotateY(180deg)}#cine .lf .pf{left:0}' +
    '#cine .in{position:absolute;left:var(--px);top:var(--py);width:var(--cw);height:var(--ch);overflow:hidden;font-size:var(--fs);line-height:var(--lh);font-family:var(--ff);color:var(--pgt);text-shadow:var(--tsh);z-index:1}#cine .in .b{margin:0 0 .7em;white-space:pre-wrap;word-wrap:break-word;break-inside:avoid}#cine .in>.b:first-child{margin-top:0}#cine .in .b.scene,#cine .in .b.char,#cine .in .b.paren,#cine .in .b.trans{font-weight:700}#cine .in .b.scene{text-transform:uppercase;margin-top:1.1em;break-after:avoid}#cine .in .b.char,#cine .in .b.paren{break-after:avoid;margin-bottom:.1em}#cine .in .b.char{margin-left:38%}#cine .in .b.paren{margin-left:28%;margin-right:28%}#cine .in .b.dial{margin-left:16%;margin-right:16%}#cine .in .b.trans{text-align:right}#cine .in .b.note{display:none}#cine .in .b.two{display:flex}#cine .meas{position:absolute;left:-200vw;top:0;visibility:hidden;pointer-events:none;column-fill:auto}' +
    '#cine .cexit{position:absolute;right:calc(max(12px,env(safe-area-inset-right)) + 6px);top:calc(max(10px,env(safe-area-inset-top)) + 6px);z-index:8;display:none;padding:7px 18px}#cine.land .cexit{display:inline-flex}#cine.land .bar2{display:none}' +
    '#cine .cvp{break-after:column;text-align:center;display:flex;flex-direction:column;justify-content:center;height:100%}#cine .cvp h1{font-size:2em;margin:0 0 .8em;line-height:1.25}#cine .cvp p{margin:.2em 0}' +
    '#cine.fill{background:var(--pgc)}#cine.fill::before{display:none}#cine.fill .stage{padding:0}#cine.fill .shell{display:none}#cine.fill .bk{perspective:1900px}#cine.fill .pf,#cine.fill .pf.l,#cine.fill .pf.r{border-radius:0;box-shadow:none}#cine.fill .pf::before{opacity:.25}#cine .hinge{display:none}#cine.fill.land .hinge{display:block;position:absolute;top:0;bottom:0;left:50%;width:26px;margin-left:-13px;pointer-events:none;z-index:6;background:linear-gradient(90deg,transparent,rgba(0,0,0,.16) 42%,rgba(0,0,0,.30) 50%,rgba(0,0,0,.16) 58%,transparent)}#cine.fill.land{background:var(--pgc)}#cine.cover .bar2{padding:6px 8px;gap:5px;max-width:98vw}#cine.cover .bar2 .btn{padding:5px 11px;font-size:12px}#cine.cover .bar2 span{min-width:52px}' +
    '#cine .bar2{position:absolute;left:50%;bottom:calc(max(10px,env(safe-area-inset-bottom)) + 10px);transform:translateX(-50%);display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:center;padding:8px 12px;border-radius:30px;background:rgba(20,18,40,.7);border:1px solid rgba(255,255,255,.3);-webkit-backdrop-filter:blur(22px);backdrop-filter:blur(22px);transition:opacity .3s,transform .3s;max-width:94vw}#cine .bar2.hide{opacity:0;pointer-events:none;transform:translate(-50%,14px)}#cine .bar2 span{min-width:74px;text-align:center;font-variant-numeric:tabular-nums;opacity:.9}' +
    /* only-one-character filter chip */
    '#onlyChip{position:fixed;left:50%;transform:translateX(-50%);top:calc(max(8px,env(safe-area-inset-top)) + 64px);z-index:55;display:none;gap:8px;align-items:center;padding:6px 8px 6px 16px;border-radius:999px;background:rgba(20,18,40,.82);color:#fff;border:1px solid rgba(255,255,255,.34);-webkit-backdrop-filter:blur(16px);backdrop-filter:blur(16px);box-shadow:0 8px 24px rgba(0,0,0,.3)}html.only #onlyChip{display:flex}#onlyChip .btn{color:#fff!important;background:var(--grad)!important;border-color:transparent!important;padding:6px 14px}' +
    '#page .b.hid{display:none!important}' +
    /* cover layouts in the editor */
    '#cover .cfx{font-size:.8em;opacity:.8;margin-top:.8em;text-align:center;white-space:pre-wrap}#cover .cft{display:flex;justify-content:space-between;gap:16px;width:100%;margin-top:auto;padding-top:2em;font-size:.78em;text-align:left;white-space:pre-wrap;opacity:.85}#cover .cft .r{text-align:right}' +
    '#cover.cv-industry{justify-content:flex-start;padding-top:clamp(40px,14vw,120px)}#cover.cv-industry .ct{text-transform:uppercase;letter-spacing:.06em;font-size:1.7em}#cover.cv-modern{align-items:flex-start;text-align:left;justify-content:flex-end;border-left:clamp(8px,2vw,16px) solid var(--acc)}#cover.cv-modern .ct{font-size:2.4em}#cover.cv-modern .cl{justify-content:flex-start}#cover.cv-modern .clogo{margin-left:0}' +
    '#cover.has-foot{justify-content:flex-start}' +
    '.cvsw{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:4px 0 10px}.cvsw .sw{width:34px;height:34px;border-radius:50%;border:2px solid rgba(128,128,128,.35);padding:0;cursor:pointer;background:transparent;font:600 10px var(--ui);color:inherit}.cvsw .sw.on{outline:2.5px solid var(--acc,#3b5bdb);outline-offset:2px}.cvsw .sw.cin{overflow:hidden}.cvsw .sw.auto{width:auto;border-radius:999px;padding:0 12px}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  /* ============================================================ typography (editor side) */
  var typoStyle = document.createElement('style'); typoStyle.id = 'typoCss'; document.head.appendChild(typoStyle);
  function pageWmm(d) { return parseFloat(THK.paperOf(d).w) || 210; }
  function typoEditorCss(d, scope) { // percentages so it follows the page width on any screen
    var T = THK.typoOf(d); if (!T) return ''; var W = pageWmm(d), m = T.m, cw = Math.max(40, W - m.l - m.r), c = '';
    function pc(mm, base) { return Math.max(0, Math.min(90, mm / base * 100)).toFixed(2) + '%'; }
    c += scope + '{line-height:' + T.lh + '}';
    if (d.fmt !== 'two') Object.keys(T.el).forEach(function (k) { var e = T.el[k]; c += scope + '.std .b.' + k + '{margin-left:' + pc(e.l, cw) + '!important;margin-right:' + pc(e.r, cw) + '!important;margin-top:' + e.sb + 'em!important}'; });
    if (d.fmt !== 'two') c += scope + '.std .b.char:not([class*="al-"]),' + scope + '.std .b.paren:not([class*="al-"]){text-align:left}';
    return c;
  }
  P.apply = function (d) {
    var T = THK.typoOf(d), pg = $('#page'), s = '';
    if (T) { s = typoEditorCss(d, '#page'); var W = pageWmm(d); pg.style.paddingTop = (T.m.t / W * 100).toFixed(2) + '%'; pg.style.paddingLeft = (T.m.l / W * 100).toFixed(2) + '%'; pg.style.paddingRight = (T.m.r / W * 100).toFixed(2) + '%'; }
    else { pg.style.paddingTop = pg.style.paddingLeft = pg.style.paddingRight = ''; }
    typoStyle.textContent = s;
  };

  /* ============================================================ typography designer */
  var ELN = [['scene', 'Scene heading'], ['action', 'Action'], ['char', 'Character'], ['paren', 'Parenthetical'], ['dial', 'Dialogue'], ['trans', 'Transition']];
  P.typoDlg = function () {
    var c = cur(); if (!c) return; var body = el('div', ''), tab = 'page';
    c.typo = c.typo || {}; var prev = el('div', 'tp-prev std'); prev.id = 'tpPrev'; body.appendChild(prev); body.appendChild(el('div', 'xsub', c.fmt === 'two' ? 'Two Column layout: line spacing and page margins apply. Indents are for the Standard layout.' : 'The preview follows the real page proportions.'));
    var tabs = row(body), panel = el('div', ''); body.appendChild(panel);
    function T() { return THK.typoOf(c) || THK.typoOf({ typo: {}, fmt: c.fmt }); }
    function save() { A.applyLook(); A.dirty(); paint(); }
    function paint() {
      var t = THK.typoOf(c) || THK.typoOf({ typo: {}, fmt: c.fmt }), W = pageWmm(c), cw = Math.max(40, W - t.m.l - t.m.r);
      prev.style.fontFamily = 'var(--font)'; prev.style.lineHeight = t.lh; prev.style.paddingLeft = (t.m.l / W * 100) + '%'; prev.style.paddingRight = (t.m.r / W * 100) + '%'; prev.style.paddingTop = Math.min(10, t.m.t / W * 100) + '%'; prev.style.paddingBottom = '3%';
      var smp = [['scene', 'INT. HOUSE – DAY'], ['action', 'Rain taps the window. Ravi stands at the door, thinking.'], ['char', 'RAVI'], ['paren', '(quietly)'], ['dial', 'I thought you had already left.'], ['char', 'MEERA'], ['dial', 'Not without saying goodbye.'], ['trans', 'CUT TO:']];
      prev.innerHTML = smp.map(function (s) { var e = t.el[s[0]]; return '<div class="b ' + s[0] + '" style="margin-left:' + Math.min(90, e.l / cw * 100) + '%;margin-right:' + Math.min(90, e.r / cw * 100) + '%;margin-top:' + e.sb + 'em;' + (s[0] === 'char' || s[0] === 'paren' ? 'text-align:left' : '') + '">' + esc(s[1]) + '</div>'; }).join('');
    }
    function slider(p, label, get, set, min, max, step, unit) {
      var r = el('div', 'slr'), o = el('output', '', ''), i = el('input'); i.type = 'range'; i.min = min; i.max = max; i.step = step; i.value = get(); o.textContent = get() + unit;
      i.oninput = function () { set(+i.value); o.textContent = i.value + unit; save(); }; r.appendChild(el('span', '', esc(label))); r.appendChild(i); r.appendChild(o); p.appendChild(r);
    }
    function setM(k, v) { c.typo.m = c.typo.m || {}; c.typo.m[k] = v; }
    function setE(k, f, v) { c.typo.el = c.typo.el || {}; c.typo.el[k] = c.typo.el[k] || {}; c.typo.el[k][f] = v; }
    function draw() {
      tabs.innerHTML = ''; panel.innerHTML = '';
      [['page', 'Page']].concat(c.fmt === 'two' ? [] : ELN).forEach(function (t) { tabs.appendChild(pill(t[1], tab === t[0], function () { tab = t[0]; draw(); })); });
      var t = THK.typoOf(c) || THK.typoOf({ typo: {}, fmt: c.fmt });
      if (tab === 'page') {
        slider(panel, 'Line spacing', function () { return t.lh; }, function (v) { c.typo.lh = v; }, 1, 2.4, 0.05, '×');
        slider(panel, 'Top margin', function () { return t.m.t; }, function (v) { setM('t', v); }, 8, 45, 1, ' mm');
        slider(panel, 'Bottom margin', function () { return t.m.b; }, function (v) { setM('b', v); }, 8, 45, 1, ' mm');
        slider(panel, 'Left margin', function () { return t.m.l; }, function (v) { setM('l', v); }, 8, 50, 1, ' mm');
        slider(panel, 'Right margin', function () { return t.m.r; }, function (v) { setM('r', v); }, 8, 50, 1, ' mm');
      } else {
        var e = t.el[tab];
        slider(panel, 'Left indent', function () { return e.l; }, function (v) { setE(tab, 'l', v); }, 0, 90, 1, ' mm');
        slider(panel, 'Right indent', function () { return e.r; }, function (v) { setE(tab, 'r', v); }, 0, 90, 1, ' mm');
        slider(panel, 'Space before', function () { return e.sb; }, function (v) { setE(tab, 'sb', v); }, 0, 3, 0.25, ' line');
      }
    }
    draw(); paint();
    dlg('Typography', body, [{ l: 'Reset to standard', fn: function () { delete c.typo; A.applyLook(); A.dirty(); toast('Standard spacing restored'); } }, { l: 'Done', cls: 'pri' }]).classList.add('wide');
  };

  /* ============================================================ header & footer designer */
  P.hfDlg = function () {
    var c = cur(); if (!c) return; c.hf = c.hf || {}; var body = el('div', '');
    var prev = el('div', 'hf-prev'); body.appendChild(prev);
    function paint() {
      var s = THK.hfSlots(c), pnf = c.hf.pnf || 'n', h = '<em></em>', pos = { 'top-left': 'l t', 'top-center': 'c t', 'top-right': 'r t', 'bottom-left': 'l u', 'bottom-center': 'c u', 'bottom-right': 'r u' };
      Object.keys(s).forEach(function (k) { h += '<i class="' + pos[k] + '">' + esc(s[k].map(function (p) { return p.n ? (pnf === 'page' ? 'Page 7' : pnf === 'dot' ? '7.' : '7') : p.t; }).join('  ·  ')) + '</i>'; });
      prev.innerHTML = h;
    }
    function save() { A.dirty(); paint(); }
    head(body, 'Page number');
    var r1 = row(body), r2 = row(body), r3 = row(body);
    var POS = [['top-center', 'Top centre'], ['top-right', 'Top right'], ['bottom-center', 'Bottom centre'], ['bottom-right', 'Bottom right'], ['off', 'None']], FMT = [['n', '7'], ['dot', '7.'], ['page', 'Page 7']];
    function draw() {
      r1.innerHTML = ''; r2.innerHTML = ''; r3.innerHTML = '';
      POS.forEach(function (p) { r1.appendChild(pill(p[1], (c.hf.pn || 'top-center') === p[0], function () { c.hf.pn = p[0]; save(); draw(); })); });
      FMT.forEach(function (p) { r2.appendChild(pill(p[1], (c.hf.pnf || 'n') === p[0], function () { c.hf.pnf = p[0]; save(); draw(); })); });
      r3.appendChild(pill('Title on every page', c.hf.title !== false, function () { c.hf.title = c.hf.title === false; save(); draw(); }));
      r3.appendChild(pill('Writer name on every page', !!c.hf.name, function () { c.hf.name = !c.hf.name; save(); draw(); }));
      r3.appendChild(pill('Draft date on every page', !!c.hf.date, function () { c.hf.date = !c.hf.date; save(); draw(); }));
    }
    draw();
    head(body, 'Texts', 'Header text shows at the top right; footer text at the bottom centre');
    function inp(ph, key, root2) { var i = el('input', 'xin'); i.placeholder = ph; i.value = (root2 ? c : c.hf)[key] || ''; i.oninput = function () { var v = i.value.trim(); if (v) (root2 ? c : c.hf)[key] = v; else delete (root2 ? c : c.hf)[key]; save(); }; body.appendChild(i); }
    inp('Header text, e.g. Production No. 1 – Draft 3', 'hdr', true); inp('Footer text, e.g. Confidential', 'foot'); inp('Draft date text (leave empty for today)', 'dateText');
    paint();
    dlg('Header & footer', body, [{ l: 'Reset', fn: function () { delete c.hf; delete c.hdr; A.dirty(); toast('Header and footer reset'); } }, { l: 'Done', cls: 'pri' }]).classList.add('wide');
  };

  /* ============================================================ cover: layouts, logo, contact, draft, based-on */
  P.coverExtras = function (cv, d) {
    cv.classList.toggle('has-foot', !!(d.contact || d.draft));
    if (d.basedOn) cv.appendChild(el('div', 'cfx', esc(d.basedOn)));
    if (d.contact || d.draft) { var f = el('div', 'cft'); f.appendChild(el('div', 'l', esc(d.contact || ''))); f.appendChild(el('div', 'r', esc(d.draft || ''))); cv.appendChild(f); }
  };
  THK.x.coverDlg = P.coverDlg = function () {
    var c = cur(); if (!c) return; var b = el('div', ''), CV = THK.cv;
    function opt(k, v) { c.cvo = c.cvo || {}; if (v === '' || v == null || v === false) delete c.cvo[k]; else c.cvo[k] = v; if (!Object.keys(c.cvo).length) delete c.cvo; A.renderAll(); A.dirty(); paint(); }
    function ov(k) { return (c.cvo || {})[k] || ''; }
    /* live preview – same classes and rules as the real cover */
    var pv = el('div', 'cvp'); pv.id = 'cover';
    function paintPv() {
      pv.innerHTML = ''; THK.cv.apply(pv, c);
      pv.appendChild(el('div', 'ct', esc(c.title || 'The Main Title')));
      var L = CV.labels(c); [[L.w, c.writer || 'Name'], [L.d, c.director || 'Name']].forEach(function (r) { var l = el('div', 'cl'); l.appendChild(el('b', '', esc(r[0]))); l.appendChild(el('span', '', esc(r[1]))); pv.appendChild(l); });
    }
    b.appendChild(pv);
    var host = el('div', ''); b.appendChild(host);
    function seg(label, key, items, sub) {
      head(host, label, sub); var r = row(host);
      items.forEach(function (it) { r.appendChild(pill(it[1], ov(key) === it[0], function () { opt(key, it[0]); })); });
    }
    function paint() {
      paintPv(); host.innerHTML = '';
      head(host, 'Style', 'Shown in the editor and on the exported PDF'); var r = row(host);
      CV.STYLES.forEach(function (s) { r.appendChild(pill(s[1], (c.cv || 'classic') === s[0], function () { c.cv = s[0]; A.renderAll(); A.dirty(); paint(); })); });
      head(host, 'Accent colour', 'Used for rules, bands, frames and bars'); var cr = el('div', 'cvsw'); host.appendChild(cr);
      var auto = el('button', 'sw auto' + (!ov('acc') ? ' on' : ''), 'Auto'); auto.onclick = function () { opt('acc', ''); }; cr.appendChild(auto);
      CV.SWATCHES.forEach(function (h) { var s = el('button', 'sw' + (ov('acc') === h ? ' on' : '')); s.style.background = h; s.setAttribute('aria-label', h); s.onclick = function () { opt('acc', h); }; cr.appendChild(s); });
      var ci = el('input', 'sw cin'); ci.type = 'color'; ci.value = ov('acc') || '#3b5bdb'; ci.onchange = function () { opt('acc', ci.value); }; cr.appendChild(ci);
      head(host, 'Title'); var tr = row(host);
      CV.SIZES.forEach(function (s) { tr.appendChild(pill(s[1], (ov('size') || 'm') === s[0], function () { opt('size', s[0] === 'm' ? '' : s[0]); })); });
      tr.appendChild(pill('Capitals', !!ov('up'), function () { opt('up', !ov('up')); })); tr.appendChild(pill('Wide spacing', !!ov('wide'), function () { opt('wide', !ov('wide')); }));
      seg('Alignment', 'al', [['', 'Style default'], ['left', 'Left'], ['center', 'Centre'], ['right', 'Right']]);
      seg('Position on the page', 'v', [['', 'Style default'], ['top', 'Top'], ['mid', 'Middle'], ['low', 'Lower']]);
      seg('Line under the title', 'rule', [['', 'Style default'], ['none', 'None'], ['line', 'Thin'], ['double', 'Double'], ['thick', 'Thick'], ['dots', 'Dotted']]);
      seg('Frame', 'fr', [['', 'Style default'], ['none', 'None'], ['thin', 'Thin'], ['double', 'Double']]);
      seg('Name labels', 'lbl', [['', 'Style default'], ['by', 'Written by'], ['plain', 'Writer :']]);
      head(host, 'Details', 'Draft number, source and contact appear in the cover’s bottom corners, as on industry title pages');
      function inp(ph, key, multi) { var i = el(multi ? 'textarea' : 'input', 'xin'); i.placeholder = ph; i.value = c[key] || ''; i.oninput = function () { var v = i.value.trim(); if (v) c[key] = i.value; else delete c[key]; A.renderAll(); A.dirty(); }; host.appendChild(i); }
      inp('Draft, e.g. First draft · Draft 2', 'draft'); inp('Based on…, e.g. Based on the novel “…” by …', 'basedOn'); inp('Contact – name, email, phone (bottom left)', 'contact', true);
      head(host, 'Logo or image', 'Optional – appears above the title (small pictures work best)'); var lr = row(host);
      lr.appendChild(pill(c.logo ? 'Change image…' : 'Add image…', false, function () {
        var f = el('input'); f.type = 'file'; f.accept = 'image/*';
        f.onchange = function () {
          var file = f.files[0]; if (!file) return; var img = new Image(), u = URL.createObjectURL(file);
          img.onload = function () { var k = Math.min(1, 520 / Math.max(img.width, img.height)), cv = document.createElement('canvas'); cv.width = Math.round(img.width * k); cv.height = Math.round(img.height * k); cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height); var d = cv.toDataURL('image/png'); if (d.length > 450000) d = cv.toDataURL('image/jpeg', .85); c.logo = d; URL.revokeObjectURL(u); A.renderAll(); A.dirty(); paint(); };
          img.onerror = function () { toast('Could not read that image'); }; img.src = u;
        }; f.click();
      }));
      if (c.logo) lr.appendChild(pill('Remove image', false, function () { delete c.logo; A.renderAll(); A.dirty(); paint(); toast('Image removed'); }));
    }
    paint();
    dlg('Cover', b, [{ l: 'Reset design', fn: function () { delete c.cvo; c.cv = 'classic'; A.renderAll(); A.dirty(); toast('Cover design reset'); } }, { l: 'Done', cls: 'pri' }]).classList.add('wide');
  };

  /* ============================================================ production breakdown */
  function todLabel(t) { return ({ day: 'Day', night: 'Night', evening: 'Evening', other: 'Time not set' })[t] || t; }
  function castOf(s) { return s.chars.join(', '); }
  function pg1(x) { return (Math.round(x * 10) / 10).toFixed(1); }
  var RPT_CSS = function (d) {
    var P0 = THK.paperOf(d);
    return '@page{size:' + P0.w + ' ' + P0.h + ';margin:14mm 12mm}*{box-sizing:border-box}html,body{margin:0;background:#fff;color:#111;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{font-family:' + THK.fontStack(d.font) + ';font-size:9.5pt;line-height:1.35}' +
      'h1{font-size:17pt;margin:0 0 1mm}h2{font-size:11.5pt;margin:6mm 0 2mm;padding-bottom:1.5mm;border-bottom:1.2pt solid #5b4bff;color:#2b2670;break-after:avoid}.sub{color:#555;margin:0 0 4mm;font-size:9pt}.sum{display:flex;gap:6mm;flex-wrap:wrap;margin:0 0 3mm}.sum div{padding:2mm 4mm;border:.6pt solid #bbb;border-radius:3mm}.sum b{font-size:13pt;display:block}' +
      'table{width:100%;border-collapse:collapse;margin:0 0 3mm}th,td{border:.5pt solid #999;padding:1.6mm 2mm;vertical-align:top;text-align:left}th{background:#ece9ff;font-size:8.5pt}tr{break-inside:avoid}td.n{width:9mm;text-align:center;font-weight:700}td.b{height:9mm}.mut{color:#666}.pill{display:inline-block;padding:0 2mm;border-radius:2mm;font-size:8pt;border:.5pt solid #999}.shot td{height:8mm}.sc{break-inside:avoid;margin-bottom:5mm}';
  };
  function scheduleHtml(d, A0) {
    var h = '<h1>' + esc(d.title || 'Untitled') + ' – Shooting schedule</h1><p class="sub">Grouped by location, then by time of day · prepared ' + esc(THK.todayStr()) + '</p>' +
      '<div class="sum"><div><b>' + A0.scenes.length + '</b>scenes</div><div><b>' + A0.locs.length + '</b>locations</div><div><b>' + A0.chars.length + '</b>characters</div><div><b>' + pg1(A0.pages) + '</b>est. pages</div></div>';
    A0.locs.forEach(function (l) {
      var list = l.scenes.map(function (n) { return A0.scenes[n - 1]; }).sort(function (a, b) { var o = { day: 0, evening: 1, night: 2, other: 3 }; return o[a.tod] - o[b.tod] || a.n - b.n; });
      h += '<h2>' + esc(l.name) + ' <span class="mut">· ' + l.scenes.length + ' scene' + (l.scenes.length > 1 ? 's' : '') + ' · ' + pg1(l.pages) + ' pg</span></h2><table><tr><th>Sc.</th><th>I/E</th><th>Time</th><th>Heading</th><th>Cast</th><th>Pg</th><th>Notes</th></tr>' +
        list.map(function (s) { return '<tr><td class="n">' + s.n + '</td><td>' + esc(s.ie || '–') + '</td><td>' + todLabel(s.tod) + '</td><td>' + esc(s.head) + '</td><td>' + esc(castOf(s)) + '</td><td>' + pg1(s.pages) + '</td><td class="b"></td></tr>'; }).join('') + '</table>';
    });
    h += '<h2>Cast</h2><table><tr><th>Character</th><th>Scenes</th><th>Lines</th><th>Scene numbers</th></tr>' + A0.chars.map(function (c) { return '<tr><td>' + esc(c.name) + '</td><td>' + c.sceneList.length + '</td><td>' + c.lines + '</td><td>' + c.sceneList.join(', ') + '</td></tr>'; }).join('') + '</table>';
    return h;
  }
  function shotHtml(d, A0) {
    var h = '<h1>' + esc(d.title || 'Untitled') + ' – Shot list</h1><p class="sub">' + A0.scenes.length + ' scenes · prepared ' + esc(THK.todayStr()) + '</p>';
    A0.scenes.forEach(function (s) {
      h += '<div class="sc"><h2>Scene ' + s.n + ' · ' + esc(s.head) + '</h2><p class="sub"><span class="pill">' + todLabel(s.tod) + '</span> ' + (s.chars.length ? 'Cast: ' + esc(castOf(s)) : '') + '</p>' + (s.action.length ? '<p>' + esc(s.action.slice(0, 2).join(' ').slice(0, 260)) + '</p>' : '') +
        '<table class="shot"><tr><th style="width:12mm">Shot</th><th style="width:24mm">Type</th><th style="width:20mm">Lens</th><th>Description</th><th style="width:32mm">Notes</th></tr>' + [1, 2, 3].map(function (i) { return '<tr><td class="n">' + s.n + String.fromCharCode(64 + i) + '</td><td></td><td></td><td></td><td></td></tr>'; }).join('') + '</table></div>';
    });
    return h;
  }
  function reportPdf(kind) {
    var d = cur(), A0 = THK.analyze(d), body = kind === 'shot' ? shotHtml(d, A0) : scheduleHtml(d, A0);
    THK.printRaw(THK.shell(d, RPT_CSS(d), body, [d.font]), d, (d.title || 'script') + (kind === 'shot' ? ' – shot list' : ' – schedule'));
  }
  function breakdownCsv() {
    var d = cur(), A0 = THK.analyze(d), rows = [['Scene', 'INT/EXT', 'Location', 'Time', 'Heading', 'Characters', 'Est. pages']];
    A0.scenes.forEach(function (s) { rows.push([s.n, s.ie, s.loc, todLabel(s.tod), s.head, castOf(s), pg1(s.pages)]); });
    A.deliver((d.title || 'script').replace(/[\\\/:*?"<>|\n]+/g, ' ').trim() + ' - breakdown.csv', 'text/csv', '﻿' + rows.map(function (r) { return r.map(csvCell).join(','); }).join('\r\n'));
  }
  P.breakdown = function () {
    var c = cur(); if (!c) return; sync(); var A0 = THK.analyze(c), tab = 'scenes', body = el('div', ''), tabs = row(body), box = el('div', ''); body.appendChild(box);
    var k = el('div', 'kpis'); k.innerHTML = '<div class="kpi"><b>' + A0.scenes.length + '</b><span>scenes</span></div><div class="kpi"><b>' + A0.locs.length + '</b><span>locations</span></div><div class="kpi"><b>' + A0.chars.length + '</b><span>characters</span></div><div class="kpi"><b>' + pg1(A0.pages) + '</b><span>est. pages</span></div>'; body.insertBefore(k, tabs);
    function draw() {
      tabs.innerHTML = ''; box.innerHTML = '';
      [['scenes', 'Scenes'], ['locs', 'Locations'], ['cast', 'Cast'], ['time', 'Day / Night']].forEach(function (t) { tabs.appendChild(pill(t[1], tab === t[0], function () { tab = t[0]; draw(); })); });
      if (!A0.scenes.length) { box.appendChild(el('div', 'xsub', 'No scene headings yet – add scenes (INT. / EXT.) and the breakdown fills itself.')); return; }
      if (tab === 'scenes') A0.scenes.forEach(function (s) { var x = el('div', 'pcard'); x.innerHTML = '<div class="top"><span class="nm">' + s.n + '. ' + esc(s.head) + '</span><small>' + pg1(s.pages) + ' pg</small></div><div><span class="tag ' + s.tod + '">' + todLabel(s.tod) + '</span>' + (s.ie ? '<span class="tag">' + esc(s.ie) + '</span>' : '') + '</div>' + (s.chars.length ? '<div class="mut">' + esc(castOf(s)) + '</div>' : ''); x.style.cursor = 'pointer'; x.onclick = function () { $$('.scrim').forEach(function (z) { z.remove(); }); setTimeout(function () { A.focusBlock(s.id, 0); }, 60); }; box.appendChild(x); });
      if (tab === 'locs') A0.locs.forEach(function (l) { var x = el('div', 'pcard'); x.innerHTML = '<div class="top"><span class="nm">' + esc(l.name) + '</span><small>' + l.scenes.length + ' scene' + (l.scenes.length > 1 ? 's' : '') + ' · ' + pg1(l.pages) + ' pg</small></div><div>' + (l.day ? '<span class="tag day">Day ' + l.day + '</span>' : '') + (l.evening ? '<span class="tag evening">Evening ' + l.evening + '</span>' : '') + (l.night ? '<span class="tag night">Night ' + l.night + '</span>' : '') + (l.other ? '<span class="tag">Not set ' + l.other + '</span>' : '') + '</div><div class="mut">Scenes ' + l.scenes.join(', ') + '</div>'; box.appendChild(x); });
      if (tab === 'cast') { if (!A0.chars.length) box.appendChild(el('div', 'xsub', 'No characters yet.')); A0.chars.forEach(function (ch) { var x = el('div', 'pcard'); x.innerHTML = '<div class="top"><span class="nm">' + esc(ch.name) + '</span><small>' + ch.lines + ' lines · ' + ch.sceneList.length + ' scenes</small></div><div class="mut">Scenes ' + ch.sceneList.join(', ') + '</div>'; box.appendChild(x); }); }
      if (tab === 'time') { var by = { day: [], evening: [], night: [], other: [] }; A0.scenes.forEach(function (s) { by[s.tod].push(s.n); }); ['day', 'evening', 'night', 'other'].forEach(function (t) { if (!by[t].length) return; var x = el('div', 'pcard'); x.innerHTML = '<div class="top"><span class="nm"><span class="tag ' + t + '">' + todLabel(t) + '</span></span><small>' + by[t].length + ' scene' + (by[t].length > 1 ? 's' : '') + '</small></div><div class="mut">Scenes ' + by[t].join(', ') + '</div>'; box.appendChild(x); }); }
    }
    draw();
    var d = dlg('Production breakdown', body, [{ l: 'Close' }, { l: 'CSV', fn: function () { breakdownCsv(); } }, { l: 'Shot list PDF', fn: function () { reportPdf('shot'); } }, { l: 'Schedule PDF', cls: 'pri', fn: function () { reportPdf('sched'); } }]); wide(d);
  };

  /* ============================================================ character manager */
  function nameOfBlock(b) { return b.t === 'char' ? THK.analyze._clean(b.x) : ''; }
  THK.analyze._clean = function (t) { return String(t || '').replace(/\(.*?\)/g, '').replace(/\b(CONT'?D\.?|V\.?O\.?|O\.?S\.?|O\.?C\.?)\b/ig, '').replace(/[:.\s]+$/, '').replace(/\s+/g, ' ').trim().toUpperCase(); };
  function reEsc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function renameChar(oldN, newN, alsoText) {
    var c = cur(); A.snap(); var n = 0; newN = newN.trim();
    c.blocks.forEach(function (b) {
      if (b.t === 'char') { var m = /^\s*([^()]*?)\s*((?:\(.*)?)$/.exec(b.x || ''); if (m && THK.analyze._clean(m[1]) === oldN) { b.x = newN + (m[2] ? ' ' + m[2] : ''); if (b.fm) delete b.fm.x; n++; } }
      else if (alsoText && b.t !== 'scene' && b.x) { var re = new RegExp(/[A-Za-z]/.test(oldN) ? '\\b' + reEsc(oldN) + '\\b' : reEsc(oldN), 'ig'); if (re.test(b.x)) { b.x = b.x.replace(re, newN); if (b.fm) delete b.fm.x; n++; } }
    });
    A.renderAll(); A.dirty(); toast(n ? 'Updated ' + n + ' place' + (n > 1 ? 's' : '') : 'Nothing changed'); return n;
  }
  /* "show only this character" */
  var onlyName = '', onlyChip = el('div', ''); onlyChip.id = 'onlyChip'; document.body.appendChild(onlyChip);
  function applyOnly() {
    var c = cur(); if (!onlyName || !c) return; var keep = {}, sc = null, scHas = false, scBlocks = [];
    function flush() { if (sc && scHas) { keep[sc.id] = 1; } }
    var who = '';
    c.blocks.forEach(function (b) { if (b.t === 'scene') { flush(); sc = b; scHas = false; who = ''; return; } if (b.t === 'char') { who = THK.analyze._clean(b.x); if (who === onlyName) { scHas = true; keep[b.id] = 1; } return; } if (b.t === 'paren' || b.t === 'dial') { if (who === onlyName) keep[b.id] = 1; return; } who = ''; });
    flush();
    $$('#page .b').forEach(function (w) { w.classList.toggle('hid', !keep[w.dataset.id]); });
  }
  P.only = function (name) {
    onlyName = name; root().classList.add('only'); onlyChip.innerHTML = ''; onlyChip.appendChild(el('span', '', 'Only ' + esc(name)));
    onlyChip.appendChild(pill('Show all', true, function () { P.onlyOff(); }, 'pri')); applyOnly();
  };
  P.onlyOff = function () { onlyName = ''; root().classList.remove('only'); $$('#page .b.hid').forEach(function (w) { w.classList.remove('hid'); }); };
  (function () { var pg = $('#page'); if (pg) new MutationObserver(function () { if (onlyName) applyOnly(); }).observe(pg, { childList: true }); })();
  function sidesPdf(name) {
    var c = cur(), out = [], scene = null, sceneHas = false, buf = [], who = '', lastSpk = null;
    function clone(b) { return JSON.parse(JSON.stringify(b)); }
    function grey(b) { var n = clone(b); n.fm = { x: [{ s: 0, e: (n.x || '').length, c: '#8a8a8a' }] }; return n; }
    function flush() { if (scene && sceneHas) { out.push(clone(scene)); buf.forEach(function (b) { out.push(b); }); } scene = null; buf = []; sceneHas = false; lastSpk = null; who = ''; }
    c.blocks.forEach(function (b) {
      if (b.t === 'scene') { flush(); scene = b; return; }
      if (!scene) return;
      if (b.t === 'char') { who = THK.analyze._clean(b.x); if (who === name) { sceneHas = true; if (lastSpk && !lastSpk.used) { buf.push(grey(lastSpk.c), grey(lastSpk.d)); lastSpk.used = true; } buf.push(clone(b)); } else lastSpk = { c: b, d: null, used: false }; return; }
      if (b.t === 'paren') { if (who === name) buf.push(clone(b)); return; }
      if (b.t === 'dial') { if (who === name) buf.push(clone(b)); else if (lastSpk && !lastSpk.d) lastSpk.d = b; return; }
      who = '';
    });
    flush();
    if (!out.length) return toast('No lines found for ' + name);
    var d2 = Object.assign({}, c, { blocks: out, title: 'Sides – ' + name, hdr: c.title || '', wm: undefined, logo: undefined });
    THK.printScript(d2, { cover: false });
  }
  P.characters = function () {
    var c = cur(); if (!c) return; sync(); var A0 = THK.analyze(c), body = el('div', '');
    body.appendChild(el('div', 'xsub', 'Rename or merge characters everywhere, show only one character’s lines, or export “sides” (just their scenes and lines, with the cue line before each).'));
    if (!A0.chars.length) body.appendChild(el('div', 'xsub', 'No characters yet – add a Character line before dialogue.'));
    var d;
    A0.chars.forEach(function (ch) {
      var x = el('div', 'pcard'); x.innerHTML = '<div class="top"><span class="nm">' + esc(ch.name) + '</span><small>' + ch.lines + ' lines · ' + ch.words + ' words · ' + ch.sceneList.length + ' scenes</small></div>';
      var r = row(x);
      r.appendChild(pill('Rename', false, function () {
        var i = el('input', 'xin'); i.value = ch.name; var lab = el('label', ''); lab.style.cssText = 'display:flex;gap:8px;align-items:center;margin-top:8px;color:var(--ink)'; var ck = el('input'); ck.type = 'checkbox'; lab.appendChild(ck); lab.appendChild(document.createTextNode(' Also change the name inside action and dialogue text')); var bb = el('div', ''); bb.appendChild(i); bb.appendChild(lab);
        dlg('Rename ' + ch.name, bb, [{ l: 'Cancel' }, { l: 'Rename', cls: 'pri', fn: function () { if (!i.value.trim()) return false; d.close(); renameChar(ch.name, i.value.trim().toUpperCase(), ck.checked); setTimeout(P.characters, 80); } }]);
      }));
      r.appendChild(pill('Merge into…', false, function () {
        var others = A0.chars.filter(function (o) { return o.name !== ch.name; }); if (!others.length) return toast('No other character to merge with');
        var bb = el('div', ''), rr = row(bb); var dd = dlg('Merge ' + ch.name + ' into', bb, [{ l: 'Cancel' }]);
        others.forEach(function (o) { rr.appendChild(pill(o.name, false, function () { dd.close(); d.close(); renameChar(ch.name, o.name, false); setTimeout(P.characters, 80); })); });
      }));
      r.appendChild(pill('Only this character', false, function () { d.close(); P.only(ch.name); }));
      r.appendChild(pill('Sides PDF', false, function () { sidesPdf(ch.name); }));
      body.appendChild(x);
    });
    d = dlg('Characters', body, [{ l: 'Close', cls: 'pri' }]); wide(d);
  };

  /* ============================================================ stats & writing goals */
  function goal() { return S.goal || 250; }
  function totalWords(c) { return c.blocks.reduce(function (n, b) { return n + words(b.x) + words(b.x2); }, 0); }
  P.track = function (c) {
    if (!c || !c.blocks) return; S.wlog = S.wlog || {}; S.wlast = S.wlast || {}; var t = totalWords(c), id = c.id;
    if (S.wlast[id] == null) { S.wlast[id] = t; return; }
    var dlt = t - S.wlast[id]; S.wlast[id] = t; if (dlt > 0 && dlt < 5000) { var k = dayKey(); S.wlog[k] = (S.wlog[k] || 0) + dlt; var ks = Object.keys(S.wlog).sort(); while (ks.length > 120) delete S.wlog[ks.shift()]; A.saveS(); }
  };
  function streak() { var n = 0, d = new Date(), g = goal(), log = S.wlog || {}; if ((log[dayKey(d)] || 0) < g) d.setDate(d.getDate() - 1); while ((log[dayKey(d)] || 0) >= g) { n++; d.setDate(d.getDate() - 1); } return n; }
  P.stats = function () {
    var c = cur(); if (!c) return; sync(); var A0 = THK.analyze(c), body = el('div', ''), g = goal(), today = (S.wlog || {})[dayKey()] || 0;
    var longest = A0.scenes.slice().sort(function (a, b) { return b.pages - a.pages; }).slice(0, 4), avg = A0.scenes.length ? A0.pages / A0.scenes.length : 0;
    var mins = Math.round(A0.minutes), tm = mins >= 60 ? Math.floor(mins / 60) + ' h ' + (mins % 60) + ' min' : mins + ' min';
    var k = el('div', 'kpis'); k.innerHTML = '<div class="kpi"><b>' + pg1(A0.pages) + '</b><span>pages</span></div><div class="kpi"><b>' + tm + '</b><span>running time</span></div><div class="kpi"><b>' + A0.scenes.length + '</b><span>scenes</span></div><div class="kpi"><b>' + A0.words + '</b><span>words</span></div><div class="kpi"><b>' + pg1(avg) + '</b><span>avg scene (pg)</span></div><div class="kpi"><b>' + streak() + '</b><span>day streak</span></div>'; body.appendChild(k);
    body.appendChild(el('div', 'xsub', 'Pages and running time are estimates (about one minute per page). Malayalam text is counted slightly wider.'));
    head(body, 'Today', today + ' of ' + g + ' words'); var bar = el('div', 'bar'); bar.innerHTML = '<i style="width:' + Math.min(100, today / g * 100) + '%"></i>'; body.appendChild(bar);
    var gr = row(body); gr.appendChild(el('span', 'mut', 'Daily goal')); [100, 250, 500, 1000].forEach(function (v) { gr.appendChild(pill(v + ' words', g === v, function () { S.goal = v; A.saveS(); $$('.scrim').forEach(function (z) { z.remove(); }); P.stats(); })); });
    head(body, 'Last 7 days'); var wk = el('div', ''); wk.style.cssText = 'display:flex;gap:6px;align-items:flex-end;height:70px;justify-content:center'; var mx = 1, days = [];
    for (var i = 6; i >= 0; i--) { var dt = new Date(); dt.setDate(dt.getDate() - i); var v = (S.wlog || {})[dayKey(dt)] || 0; days.push([dt, v]); mx = Math.max(mx, v, g); }
    days.forEach(function (x) { var col = el('div', ''); col.style.cssText = 'flex:1;max-width:44px;text-align:center;font-size:10.5px;color:var(--ink2)'; col.innerHTML = '<div style="height:' + Math.max(3, x[1] / mx * 52) + 'px;border-radius:8px;background:' + (x[1] >= g ? 'var(--grad)' : 'var(--glass2)') + ';border:1px solid var(--edge)" title="' + x[1] + ' words"></div>' + ['S', 'M', 'T', 'W', 'T', 'F', 'S'][x[0].getDay()]; wk.appendChild(col); }); body.appendChild(wk);
    head(body, 'Dialogue and action'); var tot = Math.max(1, A0.dialW + A0.actW), dp = Math.round(A0.dialW / tot * 100); var b2 = el('div', 'bar'); b2.innerHTML = '<i style="width:' + dp + '%"></i>'; body.appendChild(b2); body.appendChild(el('div', 'xsub', dp + '% dialogue · ' + (100 - dp) + '% action'));
    if (longest.length) { head(body, 'Longest scenes'); longest.forEach(function (s) { var x = el('div', 'pcard'); x.innerHTML = '<div class="top"><span class="nm">' + s.n + '. ' + esc(s.head) + '</span><small>' + pg1(s.pages) + ' pg</small></div>'; body.appendChild(x); }); }
    dlg('Stats & goals', body, [{ l: 'Close', cls: 'pri' }]).classList.add('wide');
  };

  /* ============================================================ search across all scripts */
  P.search = function () {
    var inside = document.documentElement.dataset.scr === 'app', walled = !inside && document.documentElement.dataset.wall === 'on';
    var o = el('div', 'srch ' + (inside ? 'in' : 'out') + (walled ? ' wall' : '')); o.id = 'srch'; document.body.appendChild(o);
    if (!inside) {
      var bg = el('div', 'sbg'); if (walled) { var wl = $('#wall'); bg.style.backgroundImage = wl.style.backgroundImage; bg.classList.add('img'); } o.appendChild(bg);
      o.appendChild(el('div', 'stop', '<div class="wm" role="img" aria-label="finnish"></div><p>Mobile screenplay writer</p>'));
    }
    var bar = el('div', 'sbar'), inp = el('input'); inp.placeholder = 'Search every script'; inp.type = 'search'; inp.autocomplete = 'off'; inp.setAttribute('enterkeyhint', 'search'); bar.appendChild(inp); bar.appendChild(pill('Close', false, function () { close(); })); o.appendChild(bar);
    var hint = el('div', 'shint', 'Searches every script saved on this device'); o.appendChild(hint);
    var ol = el('div', 'ol'); o.appendChild(ol); var docs = [], t = 0;
    function close() { if (o.__c) return; o.__c = 1; o.classList.add('bye'); setTimeout(function () { o.remove(); }, 140); document.removeEventListener('keydown', ek); }
    function ek(e) { if (e.key === 'Escape') close(); } document.addEventListener('keydown', ek);
    function hl(text, q) { var i = text.toLowerCase().indexOf(q), a = Math.max(0, i - 40), z = Math.min(text.length, i + q.length + 70); return (a ? '…' : '') + esc(text.slice(a, i)) + '<mark>' + esc(text.slice(i, i + q.length)) + '</mark>' + esc(text.slice(i + q.length, z)) + (z < text.length ? '…' : ''); }
    function run() {
      var q = inp.value.trim().toLowerCase(); ol.innerHTML = ''; o.classList.toggle('has', q.length >= 2); if (q.length < 2) return;
      var n = 0; var curDoc = cur();
      docs.forEach(function (d) {
        if (curDoc && d.id === curDoc.id) d = curDoc; var scene = '';
        if ((d.title || '').toLowerCase().indexOf(q) >= 0 && n < 80) { n++; ol.appendChild(res(d, null, 'Title', d.title || 'Untitled', q)); }
        (d.blocks || []).forEach(function (b) {
          if (b.t === 'scene') scene = ((b.x || '') + (b.x2 ? ' – ' + b.x2 : '')).trim();
          var tx = (b.x || '') + (b.x2 ? ' ' + b.x2 : ''); if (n >= 80 || b.t === 'note' && false) return; if (tx.toLowerCase().indexOf(q) < 0) return; n++; ol.appendChild(res(d, b, scene, tx, q));
        });
      });
      if (!n) ol.appendChild(el('div', 'none', 'Nothing found for “' + esc(inp.value.trim()) + '”.'));
      else if (n >= 80) ol.appendChild(el('div', 'none', 'Showing the first 80 matches – type more to narrow it down.'));
    }
    function res(d, b, ctx, text, q) { var r = el('div', 'res'); r.innerHTML = '<b>' + esc(d.title || 'Untitled') + '</b><small>' + esc(b ? (ctx || 'Before first scene') : 'Script title') + '</small><p>' + hl(text, q) + '</p>'; r.onclick = function () { close(); var go = function () { if (b) setTimeout(function () { A.focusBlock(b.id, 0); }, 150); }; if (cur() && cur().id === d.id) go(); else { A.openDoc(A.norm(JSON.parse(JSON.stringify(d)))); go(); } }; return r; }
    A.persist && cur() && A.persist(); setTimeout(function () { A.DB.all().then(function (ds) { docs = ds; run(); }); }, cur() ? 120 : 0); if (!cur()) A.DB.all().then(function (ds) { docs = ds; run(); });
    inp.oninput = function () { clearTimeout(t); t = setTimeout(run, 160); }; setTimeout(function () { inp.focus(); }, 80); run();
  };

  /* ============================================================ backup & restore */
  function bk() { return S.bk = S.bk || { every: 7, last: 0 }; }
  function allDocs() { return A.DB.all(); }
  P.backupNow = function () {
    allDocs().then(function (ds) {
      if (cur()) { var cd = JSON.parse(JSON.stringify(cur())); ds = ds.filter(function (d) { return d.id !== cd.id; }).concat([cd]); }
      if (!ds.length) return toast('Nothing to back up yet');
      var json = JSON.stringify({ app: 'finnish', v: 2, backup: true, when: Date.now(), docs: ds });
      bk().last = Date.now(); A.saveS(); A.deliver('finnish-backup-' + dayKey() + '.finnish', 'application/json', json);
    });
  };
  P.restore = function () {
    var i = el('input'); i.type = 'file'; i.accept = '*/*';
    i.onchange = function () {
      var f = i.files[0]; if (!f) return; var rd = new FileReader(); rd.onerror = function () { toast('Could not read the file'); };
      rd.onload = function () {
        var o; try { o = JSON.parse(String(rd.result)); } catch (e) { return toast('That is not a finnish backup'); } if (!o || o.app !== 'finnish' || !o.docs || !o.docs.length) return toast('That is not a finnish backup');
        allDocs().then(function (ds) {
          var have = {}; ds.forEach(function (d) { have[d.id] = d; }); var add = 0, keep = 0;
          return Promise.all(o.docs.map(function (d) { var n = A.norm(d), h = have[n.id]; if (h && h.updated >= n.updated) { keep++; return null; } add++; return A.DB.put(n); })).then(function () { toast(add + ' script' + (add === 1 ? '' : 's') + ' restored' + (keep ? ' · ' + keep + ' already up to date' : '')); if (!cur()) A.renderHome(); });
        });
      }; rd.readAsText(f);
    }; i.click();
  };
  P.backupDlg = function () {
    var b = el('div', ''); b.appendChild(el('p', '', 'Save all your scripts into one backup file. In the save window you can choose <b>Google Drive</b>, another cloud app, or any folder. Restoring merges the file back and never replaces a newer version you already have.'));
    var r = row(b); r.appendChild(pill('Back up all scripts now', true, function () { P.backupNow(); }, 'pri')); r.appendChild(pill('Restore from a backup…', false, P.restore));
    head(b, 'Backup reminder', 'The app cannot upload by itself while you are signed out of Google, so it reminds you instead'); var rr = row(b);
    function draw() { rr.innerHTML = ''; [[0, 'Off'], [1, 'Every day'], [7, 'Every week'], [30, 'Every month']].forEach(function (x) { rr.appendChild(pill(x[1], bk().every === x[0], function () { bk().every = x[0]; A.saveS(); draw(); })); }); }
    draw(); var last = bk().last; b.appendChild(el('div', 'xsub', last ? 'Last backup: ' + new Date(last).toLocaleString() : 'No backup made yet.'));
    dlg('Backup', b, [{ l: 'Close', cls: 'pri' }]);
  };
  P.boot = function () {
    var k = bk(); if (!k.every) return; var due = (Date.now() - (k.last || 0)) > k.every * 864e5; if (!due) return;
    allDocs().then(function (ds) {
      if (!ds.length) return; if (!k.last) { k.last = Date.now(); A.saveS(); return; }
      dlg('Time for a backup', '<p>Your scripts have not been backed up for ' + Math.max(1, Math.round((Date.now() - k.last) / 864e5)) + ' day(s). A backup file protects them if this device is lost.</p>', [{ l: 'Later', fn: function () { k.last = Date.now() - (k.every - 1) * 864e5; A.saveS(); } }, { l: 'Back up now', cls: 'pri', fn: function () { P.backupNow(); } }]);
    });
  };

  /* ============================================================ voice dictation */
  var LT = THK.LOC, lastEd = null;
  document.addEventListener('focusin', function (e) { var t = e.target; if (t && t.closest && t.closest('#page') && t.classList.contains('ed')) lastEd = t; });
  var dictBusy = false, dictPos = null;
  function insertAtCaret(text) {
    var ed = lastEd && document.body.contains(lastEd) ? lastEd : null, c = cur();
    if (!ed && c) ed = $('#page .b:last-child .ed');
    if (!ed) return toast('Tap where you want the text first');
    ed.focus();
    try { if (dictPos != null && ed === dictTarget) A.setCaret(ed, dictPos); else if (!getSelection().rangeCount || !ed.contains(getSelection().anchorNode)) A.setCaret(ed, 1e9); } catch (e) { }
    var at = A.getCaret(ed), prev = ed.textContent.charAt(at - 1); text = text.trim(); if (!text) return;
    if (prev && !/\s/.test(prev) && !/^[,.;:!?।]/.test(text)) text = ' ' + text;
    A.tl.buf = ''; A.tl.len = 0; document.execCommand('insertText', false, text + ' '); A.tl.buf = ''; A.tl.len = 0; dictPos = null; dictTarget = null;
  }
  var dictTarget = null, spBtn = null;
  function spState(on) { dictBusy = on; if (spBtn) { spBtn.classList.toggle('on', on); spBtn.textContent = on ? 'Listening…' : 'Speak'; } }
  P.dictate = function () {
    var c = cur(); if (!c) return toast('Open a script first'); if (dictBusy) return;
    var L = THK.lang(c.lang), lang = LT[c.lang] || 'en-IN', FP = THK.fp(), f = FP && FP.dictate ? FP : null, ae = document.activeElement;
    if (ae && ae.classList && ae.classList.contains('ed') && ae.closest('#page')) lastEd = ae;
    dictTarget = lastEd && document.body.contains(lastEd) ? lastEd : null; dictPos = dictTarget ? A.getCaret(dictTarget) : null;
    if (f) { spState(true); return f.dictate({ lang: lang, prompt: 'Speak in ' + L.name }).then(function (r) { spState(false); if (r && r.text) insertAtCaret(r.text); else toast('Nothing was heard'); }).catch(function (e) { spState(false); if (!e || !/cancel/i.test(String(e.message || e))) toast('Speech recognition for ' + L.name + ' is not available on this device – install its voice in Google speech settings'); }); }
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return toast('Speaking to type needs the Android app or a browser with speech recognition');
    var rec = new SR(); rec.lang = lang; rec.interimResults = false; rec.maxAlternatives = 1; spState(true);
    rec.onresult = function (e) { insertAtCaret(e.results[0][0].transcript); }; rec.onerror = function () { spState(false); toast('Could not hear anything'); }; rec.onend = function () { spState(false); };
    try { rec.start(); } catch (er) { spState(false); toast('Speaking could not start'); }
  };
  P.speakBtn = function () {
    spBtn = el('button', 'btn' + (dictBusy ? ' on' : ''), dictBusy ? 'Listening…' : 'Speak'); spBtn.title = 'Speak to type – writes in the language chosen at the right end';
    spBtn.onmousedown = function (e) { e.preventDefault(); }; spBtn.onclick = function () { P.dictate(); }; return spBtn;
  };

  /* ============================================================ cinematic read mode */
  P.cine = function () {
    var c = cur(); if (!c) return; sync(); var o = el('div', 'ovl'); o.id = 'cine'; document.body.appendChild(o);
    var stage = el('div', 'stage'), bk = el('div', 'bk'), meas = el('div', 'meas in'), fs = S.cineSz || 17, barT = 0, raf = 0, lt = 0;
    var land = false, fill = false, pw = 0, ph = 0, pages = 1, pageHTML = [], blockPage = [], firstBlk = [], tall = false, pos = 0, turn = null, g = null, lum = 1;
    stage.appendChild(bk); o.appendChild(stage); o.appendChild(meas);
    var bar = el('div', 'bar2'), lab = el('span', '', ''), exitB = pill('Exit', true, close, 'pri cexit'); o.appendChild(bar); o.appendChild(exitB);
    function X(h, f) { return f && f.length ? THK.richHtml(h, f) : esc(h); }
    function build() {
      var h = '<div class="cvp"><h1>' + X(c.title || 'Untitled', (c.cfm || {}).title) + '</h1>' + (c.writer ? '<p>' + esc(c.writer) + '</p>' : '') + (c.director ? '<p>' + esc(c.director) + '</p>' : '') + '</div>';
      c.blocks.forEach(function (b) { if (b.t === 'note') return; var x = b.x || ''; if (!x.trim() && !(b.x2 || '').trim()) return; var fm = (b.fm || {}).x, t = x; if (b.t === 'paren') { t = '(' + x.replace(/^\(|\)$/g, '') + ')'; fm = null; } else if (b.t === 'scene' && b.x2) { t = x + ' – ' + b.x2; fm = null; } h += '<div class="b ' + b.t + '"' + (b.al ? ' style="text-align:' + b.al + '"' : '') + '>' + X(t, fm) + '</div>'; });
      meas.innerHTML = h;
    }
    function lumOf(col) { var t = document.createElement('i'); t.style.color = col; document.body.appendChild(t); var m = (getComputedStyle(t).color || '').match(/\d+(\.\d+)?/g) || [255, 255, 255]; t.remove(); return (0.299 * m[0] + 0.587 * m[1] + 0.114 * m[2]) / 255; }
    function insets() { var t = document.createElement('div'); t.style.cssText = 'position:fixed;left:0;top:0;visibility:hidden;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left)'; document.body.appendChild(t); var q = getComputedStyle(t), r = { t: parseFloat(q.paddingTop) || 0, r: parseFloat(q.paddingRight) || 0, b: parseFloat(q.paddingBottom) || 0, l: parseFloat(q.paddingLeft) || 0 }; t.remove(); return r; }
    function segs() { try { if (matchMedia('(horizontal-viewport-segments: 2)').matches) return 2; } catch (e) { } try { var sg = window.visualViewport && visualViewport.segments; if (sg && sg.length > 1) return sg.length; } catch (e) { } return 1; }
    function layout() {
      var anchorBlk = firstBlk[Math.min(pages - 1, land ? pos * 2 : pos)] || 0, P0 = THK.paperOf(c), asp = parseFloat(P0.w) / parseFloat(P0.h), top = Math.max(8, parseInt(getComputedStyle(o).paddingTop) || 8);
      var W = innerWidth, H = innerHeight, mn = Math.min(W, H), mx = Math.max(W, H), sq = W / H, ins = insets();
      var cover = mx <= 440, fold = !cover && (segs() > 1 || (mn >= 520 && mn <= 1000 && sq >= 0.78 && sq <= 1.3 && mx <= 1100));
      var phoneLand = !cover && !fold && W > H * 1.02 && H < 600, twoFill = fold || phoneLand, portPhone = !cover && !twoFill && W < 600;
      fill = cover || twoFill || portPhone; var oldLand = !fill && (W > H * 1.02 && H < 900 || W > H * 1.3);
      land = twoFill || oldLand; o.classList.toggle('land', land); o.classList.toggle('fill', fill); o.classList.toggle('cover', cover); o.classList.toggle('fold', fold);
      var px, py;
      if (fill) { pw = Math.floor(twoFill ? W / 2 : W); ph = Math.floor(H); px = Math.max(14, pw * 0.07, ins.l, ins.r); py = Math.max(14, ph * 0.045) + Math.max(ins.t, ins.b * 0.6); }
      else {
        var vw = land ? W - 100 : W - 24, vh = land ? H - 60 : H - top - 96;
        pw = Math.min(land ? vw / 2 : vw, vh * asp); ph = pw / asp; pw = Math.floor(pw); ph = Math.floor(ph); px = pw * 0.1; py = ph * 0.07;
      }
      var fsE = fs * Math.max(0.6, Math.min(1.25, pw / 390)), pc = c.pageColor || '#ffffff', tc = c.textColor || '#000000', tt = (c.typo && c.typo.lh) || (THK.typoOf(c) || { lh: 1.5 }).lh;
      lum = lumOf(pc); var dark = lum < 0.45, S0 = o.style;
      S0.setProperty('--pw', pw + 'px'); S0.setProperty('--ph', ph + 'px'); S0.setProperty('--bw', (land ? pw * 2 : pw) + 'px'); S0.setProperty('--px', px + 'px'); S0.setProperty('--py', py + 'px'); S0.setProperty('--cw', (pw - 2 * px) + 'px'); S0.setProperty('--ch', (ph - 2 * py) + 'px');
      S0.setProperty('--fs', fsE + 'px'); S0.setProperty('--lh', tt); S0.setProperty('--ff', THK.fontStack(c.font)); S0.setProperty('--pgc', pc); S0.setProperty('--pgt', tc);
      S0.setProperty('--tsh', dark ? '0 -1px 0 rgba(0,0,0,.75),0 1px 0 rgba(255,255,255,.14)' : '0 1px 0 rgba(255,255,255,.95),0 -.6px 0 rgba(0,0,0,.3)');
      bk.classList.toggle('dk', dark);
      meas.style.cssText = 'width:' + (pw - 2 * px) + 'px;height:' + (ph - 2 * py) + 'px;column-width:' + (pw - 2 * px) + 'px;column-gap:' + (2 * px) + 'px;column-fill:auto;font-size:' + fsE + 'px;line-height:' + tt + ';font-family:' + THK.fontStack(c.font) + ';left:-200vw;top:0;position:absolute;visibility:hidden';
      var kids = [].slice.call(meas.children), chH = ph - 2 * py; pageHTML = []; blockPage = []; firstBlk = []; tall = false;
      kids.forEach(function (k, i) { var p = Math.max(0, Math.floor((k.offsetLeft + 2) / pw)); if (k.offsetHeight > chH + 2) tall = true; blockPage[i] = p; if (firstBlk[p] == null) firstBlk[p] = i; pageHTML[p] = (pageHTML[p] || '') + k.outerHTML; });
      pages = Math.max(1, Math.round((meas.scrollWidth + 2 * px) / pw), pageHTML.length); for (var i = 0; i < pages; i++) { if (pageHTML[i] == null) pageHTML[i] = ''; if (firstBlk[i] == null) firstBlk[i] = firstBlk[i - 1] || 0; }
      var np = blockPage[Math.min(anchorBlk, blockPage.length - 1)] || 0; pos = land ? Math.ceil(np / 2) : np; pos = Math.max(0, Math.min(npos() - 1, pos));
      turn = null; cancelAnimationFrame(raf); idle();
    }
    function npos() { return land ? Math.ceil((pages - 1) / 2) + 1 : pages; }
    function face(p, side) {
      var f = el('div', 'pf' + (side ? ' ' + side : ''));
      if (p >= 0 && p < pages) {
        var inner; if (tall) { inner = '<div class="in" style="overflow:visible"></div>'; } else inner = '<div class="in">' + pageHTML[p] + '</div>';
        f.innerHTML = inner + (p > 0 ? '<i class="pn">' + p + '</i>' : '');
        if (tall) { var cl = meas.cloneNode(true); cl.className = 'in'; cl.style.cssText = 'position:absolute;left:0;top:0;visibility:visible;width:' + (pw - 0.2 * pw) + 'px;height:' + (ph * 0.86) + 'px;column-width:' + (pw * 0.8) + 'px;column-gap:' + (pw * 0.2) + 'px;column-fill:auto;transform:translateX(' + (-p * pw) + 'px)'; f.firstChild.appendChild(cl); }
      }
      f.appendChild(el('i', 'sh')); return f;
    }
    function put(node, left) { node.style.left = left + 'px'; bk.appendChild(node); return node; }
    function idle() {
      bk.innerHTML = ''; bk.classList.toggle('two', land);
      if (land) { bk.appendChild(el('div', 'shell')); put(face(2 * pos - 1, 'l'), 0); put(face(2 * pos, 'r'), pw); bk.appendChild(el('div', 'hinge')); lab.textContent = ''; }
      else { put(face(pos), 0); lab.textContent = pos + 1 + ' / ' + pages; }
    }
    /* ---- page turning: the leaf follows the finger, can be stopped anywhere and let go ---- */
    function spineX() { return land ? pw : 0; }
    function startTurn(dir) {
      if (turn) return false; var n = pos + dir; if (n < 0 || n > npos() - 1) return false;
      bk.innerHTML = ''; var lf = el('div', 'lf'), cs = el('div', 'cs'), fr, bf;
      if (land) {
        bk.appendChild(el('div', 'shell'));
        if (dir > 0) { put(face(2 * pos - 1, 'l'), 0); put(face(2 * pos + 2, 'r'), pw); fr = face(2 * pos, 'r'); bf = face(2 * pos + 1, 'l bkf'); }
        else { put(face(2 * pos - 3, 'l'), 0); put(face(2 * pos, 'r'), pw); fr = face(2 * pos - 2, 'r'); bf = face(2 * pos - 1, 'l bkf'); }
        lf.style.left = pw + 'px';
      } else {
        if (dir > 0) { put(face(pos + 1), 0); fr = face(pos); } else { put(face(pos), 0); fr = face(pos - 1); }
        bf = face(-1); bf.className = 'pf bkf'; bf.style.left = '0'; lf.style.left = '0';
      }
      fr.className = fr.className.replace(/\bbkf\b/, ''); lf.appendChild(fr); lf.appendChild(bf); bk.appendChild(cs); bk.appendChild(lf); if (land) bk.appendChild(el('div', 'hinge'));
      turn = { dir: dir, u: dir > 0 ? 0 : 1, lf: lf, cs: cs, fr: fr.lastChild, bf: bf.lastChild }; paint(); return true;
    }
    function paint() {
      var u = turn.u, a = -180 * u, sp = spineX(), ex = sp + pw * Math.cos(u * Math.PI), s = Math.sin(u * Math.PI);
      turn.lf.style.transform = 'rotateY(' + a.toFixed(2) + 'deg)';
      turn.fr.style.opacity = u < 0.5 ? (u * 2 * 0.26).toFixed(3) : 0; turn.bf.style.opacity = u > 0.5 ? ((1 - u) * 2 * 0.26).toFixed(3) : 0;
      var al = (0.34 * s).toFixed(3), w = pw * 0.28;
      turn.cs.style.background = u < 0.5 ? 'linear-gradient(90deg,rgba(0,0,0,' + al + ') ' + ex + 'px,transparent ' + (ex + w) + 'px),linear-gradient(90deg,transparent ' + (ex - w * 0.35) + 'px,rgba(255,255,255,' + (0.22 * s).toFixed(3) + ') ' + ex + 'px,transparent ' + (ex + 2) + 'px)' : (land ? 'linear-gradient(270deg,rgba(0,0,0,' + al + ') ' + (bk.offsetWidth - ex) + 'px,transparent ' + (bk.offsetWidth - ex + w) + 'px)' : 'none');
      turn.cs.style.opacity = 1;
    }
    function settle(done) {
      var d = turn.dir; turn = null; if (done) pos += d; idle();
    }
    function animateTo(target, rel, fast) {
      cancelAnimationFrame(raf); var u0 = turn.u, t0 = 0, dist = Math.abs(target - u0), dur = (rel ? 200 : 300) + 380 * dist; if (fast) dur = Math.max(170, dur * 0.6);
      raf = requestAnimationFrame(function step(now) {
        if (!turn) return; if (!t0) t0 = now; var k = Math.min(1, (now - t0) / dur), e = rel ? 1 - Math.pow(1 - k, 3) : (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2); turn.u = u0 + (target - u0) * e; paint();
        if (k < 1) raf = requestAnimationFrame(step); else settle(turn.dir > 0 ? target === 1 : target === 0);
      });
    }
    function nav(dir) { if (turn || !startTurn(dir)) return; animateTo(dir > 0 ? 1 : 0); }
    function edgeOf(u) { return spineX() + pw * Math.cos(u * Math.PI); }
    function showBar() { if (land) return; bar.classList.remove('hide'); clearTimeout(barT); barT = setTimeout(function () { bar.classList.add('hide'); }, 3500); }
    bar.appendChild(pill('Previous', false, function () { nav(-1); showBar(); })); bar.appendChild(lab); bar.appendChild(pill('Next', false, function () { nav(1); showBar(); }));
    bar.appendChild(pill('A−', false, function () { fs = Math.max(12, fs - 1); S.cineSz = fs; A.saveS(); relayout(); showBar(); })); bar.appendChild(pill('A+', false, function () { fs = Math.min(32, fs + 1); S.cineSz = fs; A.saveS(); relayout(); showBar(); }));
    bar.appendChild(pill('Close', true, close, 'pri'));
    function relayout() { cancelAnimationFrame(raf); build(); layout(); }
    function close() { cancelAnimationFrame(raf); o.remove(); document.removeEventListener('keydown', ek); removeEventListener('resize', rz); clearTimeout(barT); clearTimeout(rzT); }
    function ek(e) { if (e.key === 'Escape') close(); else if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') { nav(1); e.preventDefault(); } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { nav(-1); e.preventDefault(); } } document.addEventListener('keydown', ek);
    var rzT = 0, rz = function () { clearTimeout(rzT); rzT = setTimeout(function () { if (document.body.contains(o)) { cancelAnimationFrame(raf); layout(); } }, 140); }; addEventListener('resize', rz);
    stage.addEventListener('pointerdown', function (e) {
      if (e.target.closest('.bar2,.cexit')) return; try { stage.setPointerCapture(e.pointerId); } catch (x) { }
      cancelAnimationFrame(raf); var now = performance.now(); g = { x0: e.clientX, y0: e.clientY, moved: !!turn, s: [[e.clientX, now]], e0: turn ? edgeOf(turn.u) : 0, dead: false };
    });
    stage.addEventListener('pointermove', function (e) {
      if (!g || g.dead) return; var dx = e.clientX - g.x0, now = performance.now(); g.s.push([e.clientX, now]); while (g.s.length > 5) g.s.shift();
      if (!turn) {
        if (Math.abs(dx) < 8) return; if (Math.abs(e.clientY - g.y0) > Math.abs(dx) * 1.4) { g.dead = true; return; }
        if (!startTurn(dx < 0 ? 1 : -1)) { g.dead = true; return; } g.moved = true; g.x0 = e.clientX; g.e0 = edgeOf(turn.u); dx = 0;
      }
      var sp = spineX(), edge = Math.max(sp - pw, Math.min(sp + pw, g.e0 + dx)); turn.u = Math.acos(Math.max(-1, Math.min(1, (edge - sp) / pw))) / Math.PI; paint();
    });
    function release(e, cancel) {
      if (!g) return; var gg = g; g = null; try { stage.releasePointerCapture(e.pointerId); } catch (x) { }
      if (gg.dead) { if (turn) animateTo(turn.dir > 0 ? 0 : 1, true); return; }
      if (!gg.moved) { if (cancel) return; var r = bk.getBoundingClientRect(), x = e.clientX; if (land) { if (x < r.left + r.width * 0.45) nav(-1); else if (x > r.left + r.width * 0.55) nav(1); } else { var fx = x / innerWidth; if (fx < 0.33) nav(-1); else if (fx > 0.67) nav(1); else if (bar.classList.contains('hide')) showBar(); else bar.classList.add('hide'); } showBar(); return; }
      if (!turn) return; var s0 = gg.s[0], s1 = gg.s[gg.s.length - 1], vx = (s1[1] - s0[1]) > 5 ? (s1[0] - s0[0]) / (s1[1] - s0[1]) : 0, done;
      if (turn.dir > 0) done = vx > 0.4 ? false : (turn.u > 0.5 || (vx < -0.4 && turn.u > 0.06)); else done = vx < -0.4 ? false : (turn.u < 0.5 || (vx > 0.4 && turn.u < 0.94));
      animateTo(turn.dir > 0 ? (done ? 1 : 0) : (done ? 0 : 1), true, Math.abs(vx) > 0.8); showBar();
    }
    stage.addEventListener('pointerup', function (e) { release(e, false); }); stage.addEventListener('pointercancel', function (e) { release(e, true); });
    build(); setTimeout(function () { layout(); showBar(); }, 30);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { if (document.body.contains(o)) { cancelAnimationFrame(raf); layout(); } });
  };

  /* ============================================================ presentation PDF */
  P.present = function () {
    var c = cur(); if (!c) return; sync(); if (!c.blocks.some(function (b) { return b.t === 'scene' && (b.x || '').trim(); })) toast('Tip: scene headings fill the contents page');
    THK.printScript(c, { cover: true, toc: true, accent: S.accent || '#5b4bff' });
  };

  /* ============================================================ hubs, menu, commands */
  function hub(title, intro, groups) {
    var b = el('div', ''); if (intro) b.appendChild(el('p', '', intro));
    groups.forEach(function (g) { if (g.h) head(b, g.h); var r = row(b); g.items.forEach(function (it) { r.appendChild(pill(it[0], false, function () { $$('.scrim').forEach(function (z) { z.remove(); }); setTimeout(it[1], 60); })); }); });
    dlg(title, b, [{ l: 'Close', cls: 'pri' }]);
  }
  P.production = function () { hub('Production', 'Tools for planning the shoot and working with your cast.', [{ items: [['Breakdown & schedule', P.breakdown], ['Characters', P.characters], ['Stats & goals', P.stats], ['Search all scripts', P.search]] }]); };
  P.design = function () { hub('Page design', 'How your script looks on paper.', [{ items: [['Edit cover page', P.coverDlg], ['Paper size', THK.x.paperDlg], ['Typography', P.typoDlg], ['Header & footer', P.hfDlg], ['Watermark', THK.x.wmDlg]] }, { h: 'Export', items: [['Presentation PDF', P.present]] }]); };
  P.menu = function () {
    return {
      production: { l: 'Production…', fn: P.production }, design: { l: 'Page design…', fn: P.design }, cine: { l: 'Cinematic read', fn: P.cine },
      dictate: { l: 'Speak to type', fn: P.dictate }, search: { l: 'Search all scripts…', fn: P.search }, backup: { l: 'Backup & restore…', fn: P.backupDlg }
    };
  };
  P.cmds = function () { return [['Production breakdown', P.breakdown], ['Character manager', P.characters], ['Stats & writing goals', P.stats], ['Search all scripts', P.search], ['Backup & restore', P.backupDlg], ['Speak to type', P.dictate], ['Typography', P.typoDlg], ['Header & footer', P.hfDlg], ['Edit cover page', P.coverDlg], ['Cinematic read', P.cine], ['Presentation PDF', P.present], ['Show all characters (end filter)', P.onlyOff]]; };
  P.opened = function (c) { P.onlyOff(); if (c) { S.wlast = S.wlast || {}; if (S.wlast[c.id] == null) { S.wlast[c.id] = totalWords(c); } } };
  /* writing-goal tracking rides on the existing autosave hook */
  var v0 = THK.x.version; THK.x.version = function (c) { try { v0(c); } catch (e) { } P.track(c); };
  /* customise sheet gets a shortcut row */
  var cd0 = THK.x.customDlg; THK.x.customDlg = function () { cd0(); };
})();
