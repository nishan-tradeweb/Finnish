/* Proofread – finds mistakes in a script of any of the 25 languages and lets you fix each one: spelling look-alikes, repeated words, extra marks,
   unclosed brackets, character names spelled two ways, scenes with no transition, dialogue without a character, and a few English grammar slips.
   Works offline; when online it also asks Google for spelling suggestions. Fixing the last mistake closes the window. */
(function () {
  'use strict';
  var A = THK.app, el = A.el, esc = A.esc, PF = THK.proof = {};
  var NOSPACE = { zh: 1, ja: 1, th: 1 }, SPACEBEFORE = { fr: 1 };
  var WORD = /[\p{L}\p{M}\p{N}]+(?:['’][\p{L}]+)?/gu;
  var KIND = { spell: 'Spelling', repeat: 'Repeated word', marks: 'Extra marks', bracket: 'Brackets', name: 'Character names', trans: 'Transitions', struct: 'Structure', gram: 'Grammar' };
  var EN_TYPO = { teh: 'the', recieve: 'receive', recieved: 'received', seperate: 'separate', definately: 'definitely', occured: 'occurred', untill: 'until', wich: 'which', thier: 'their', becuase: 'because', alot: 'a lot', 'dont': "don't", 'cant': "can't", 'wont': "won't", 'didnt': "didn't", 'doesnt': "doesn't", 'isnt': "isn't", 'im': "I'm", 'ive': "I've" };
  var ignored = {}, googleOk = null, googleMap = {};

  function lev(a, b, max) { /* Damerau-Levenshtein with early exit */
    var la = a.length, lb = b.length; if (Math.abs(la - lb) > max) return max + 1; var p = null, pp = null, r;
    for (var i = 0; i <= la; i++) { r = [i]; var mn = i; for (var j = 1; j <= lb; j++) { if (!i) { r[j] = j; continue; } var c = a[i - 1] === b[j - 1] ? 0 : 1, v = Math.min(p[j] + 1, r[j - 1] + 1, p[j - 1] + c); if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) v = Math.min(v, pp[j - 2] + 1); r[j] = v; if (v < mn) mn = v; } if (mn > max) return max + 1; pp = p; p = r; }
    return r[lb];
  }
  function nameOf(b) { return (b.x || '').replace(/\(.*?\)/g, '').replace(/[:：]\s*$/, '').replace(/\s+/g, ' ').trim(); }
  function ctx(s, a, e) { var b = Math.max(0, a - 22), f = Math.min(s.length, e + 22); return (b ? '…' : '') + esc(s.slice(b, a)) + '<mark>' + esc(s.slice(a, e) || '·') + '</mark>' + esc(s.slice(e, f)) + (f < s.length ? '…' : ''); }

  /* ---------- analysis ---------- */
  function analyse(d) {
    var out = [], lang = d.lang || 'en', bl = d.blocks, key = function (k, id, t) { return k + '|' + id + '|' + t; };
    function add(o) { if (ignored[o.key]) return; out.push(o); }
    /* names */
    var names = {}, order = [];
    bl.forEach(function (b) { if (b.t === 'char') { var n = nameOf(b); if (!n) return; var k = n.toLowerCase(); if (!names[k]) { names[k] = { n: n, c: 0, forms: {} }; order.push(k); } names[k].c++; names[k].forms[n] = (names[k].forms[n] || 0) + 1; } });
    var done = {};
    order.forEach(function (k1, i) {
      order.forEach(function (k2, j) {
        if (j <= i || done[k1] === k2 || k1.length < 3) return; var a = names[k1], b = names[k2], ml = Math.min(k1.length, k2.length), mx = ml >= 8 ? 2 : 1;
        var ph = function (x) { return x.replace(/[\s.\-]/g, '').replace(/(.)\1+/g, '$1').replace(/[eyj]/g, 'i').replace(/[ou]/g, 'o').replace(/w/g, 'v').replace(/(.)h/g, '$1'); }, same = ph(k1) === ph(k2), dist = lev(k1, k2, mx);
        if (same || (ml >= 4 && dist <= mx)) {
          var keep = a.c >= b.c ? a : b, other = keep === a ? b : a;
          var topF = function (o) { return Object.keys(o.forms).sort(function (x, y) { return o.forms[y] - o.forms[x]; })[0]; };
          var kk = key('name', other.n.toLowerCase(), keep.n.toLowerCase());
          add({ kind: 'name', key: kk, bi: bl.findIndex(function (b) { return b.t === 'char' && nameOf(b).toLowerCase() === other.n.toLowerCase(); }), msg: '“' + topF(other) + '” (' + other.c + '×) and “' + topF(keep) + '” (' + keep.c + '×) look like the same character', html: esc(topF(other)) + ' → ' + esc(topF(keep)),
            fixes: [{ l: 'Use “' + topF(keep) + '” everywhere', fn: function () { rename(other.n, topF(keep)); } }, { l: 'Use “' + topF(other) + '” everywhere', fn: function () { rename(keep.n, topF(other)); } }], custom: function (v) { rename(other.n, v); rename(keep.n, v); } });
        }
      });
    });
    /* word frequency for spelling look-alikes */
    var freq = {}, spaced = !NOSPACE[lang], nameSet = {}; order.forEach(function (k) { k.split(/\s+/).forEach(function (w) { nameSet[w] = 1; }); });
    if (spaced) bl.forEach(function (b) { if (b.t === 'char' || b.t === 'scene' || b.t === 'img') return; var m, s = b.x || ''; WORD.lastIndex = 0; while ((m = WORD.exec(s))) { var w = m[0].toLowerCase(); freq[w] = (freq[w] || 0) + 1; } });
    var idx = {}, fw = Object.keys(freq).filter(function (w) { return freq[w] >= 3 && w.length >= 4 && w.length <= 24 && !/\d/.test(w); });
    fw.forEach(function (w) { var ks = [w]; for (var i = 0; i < w.length; i++) ks.push(w.slice(0, i) + w.slice(i + 1)); ks.forEach(function (k) { (idx[k] = idx[k] || []).push(w); }); });
    var rareHits = {};
    function nearWord(w) {
      var ks = [w]; for (var i = 0; i < w.length; i++) ks.push(w.slice(0, i) + w.slice(i + 1)); var best = null, seen = {};
      ks.forEach(function (k) { (idx[k] || []).forEach(function (c) { if (c === w || seen[c]) return; seen[c] = 1; if (lev(w, c, 1) <= 1 && (!best || freq[c] > freq[best])) best = c; }); }); return best;
    }
    /* per-block rules */
    bl.forEach(function (b, bi) {
      if (b.t === 'img') return; var s = b.x || '', fld = 'x';
      var fields = [['x', s]]; if (b.x2) fields.push(['x2', b.x2]);
      fields.forEach(function (F) {
        var f = F[0], t = F[1]; if (!t) return;
        function mk(kind, a, e, msg, fixes, sev) { add({ kind: kind, key: key(kind, b.id + f, t.slice(a, e) + a), bi: bi, f: f, a: a, e: e, msg: msg, html: ctx(t, a, e), fixes: fixes, custom: function (v) { edit(b.id, f, a, e, v); } }); }
        var m;
        /* double spaces */
        var re = / {2,}/g; while ((m = re.exec(t))) if (m.index > 0 && m.index + m[0].length < t.length) mk('marks', m.index, m.index + m[0].length, 'Extra spaces', [fixTo(b.id, f, m.index, m.index + m[0].length, ' ', 'Single space')]);
        /* trailing spaces */
        if (/ +$/.test(t) && b.t !== 'paren') { var tm = t.match(/ +$/); mk('marks', t.length - tm[0].length, t.length, 'Space at the end of the line', [fixTo(b.id, f, t.length - tm[0].length, t.length, '', 'Remove')]); }
        /* repeated marks */
        re = /([,;:!?،؛؟।॥।])\1+|\.{4,}|\.\.(?!\.)|[!?]{2,}|[,.]\s*[,.](?!\.)|[~^|\\`]+/g;
        while ((m = re.exec(t))) { var mm = m[0]; if (/^[!?]{2,}$/.test(mm) && /^[!?]+$/.test(mm) && (/\?!|!\?/.test(mm) && mm.length === 2)) continue; if (/^\.{3}$/.test(mm)) continue;
          var fx = /^\.\./.test(mm) ? '…' : mm[0] === '~' || mm[0] === '^' || mm[0] === '|' || mm[0] === '\\' || mm[0] === '`' ? '' : mm[0]; var alt = /^\.\.+$/.test(mm) ? '.' : null;
          var fixes = [fixTo(b.id, f, m.index, m.index + mm.length, fx, fx ? 'Use “' + fx + '”' : 'Remove')]; if (alt && alt !== fx) fixes.push(fixTo(b.id, f, m.index, m.index + mm.length, alt, 'Use “.”'));
          mk('marks', m.index, m.index + mm.length, 'Unwanted extra marks', fixes); }
        /* space before punctuation / missing space after */
        if (!SPACEBEFORE[lang] && !NOSPACE[lang]) { re = /\s+([,.;:!?،؛؟।])(?!\.)/g; while ((m = re.exec(t))) mk('marks', m.index, m.index + m[0].length, 'Space before “' + m[1] + '”', [fixTo(b.id, f, m.index, m.index + m[0].length, m[1], 'Remove the space')]); }
        if (!NOSPACE[lang]) { re = /([\p{L}\p{M}])([,;!?،؛؟।])(?=[\p{L}\p{M}])/gu; while ((m = re.exec(t))) mk('marks', m.index + 1, m.index + 2, 'No space after “' + m[2] + '”', [fixTo(b.id, f, m.index + 1, m.index + 2, m[2] + ' ', 'Add a space')]); }
        /* brackets & quotes */
        if (b.t !== 'scene') {
          var tt = b.t === 'paren' ? t.replace(/^\(|\)$/g, '') : t, off = b.t === 'paren' && /^\(/.test(t) ? 1 : 0, st = [], PA = { '(': ')', '[': ']', '{': '}', '“': '”', '‘': '’', '«': '»' };
          for (var i = 0; i < tt.length; i++) { var c = tt[i]; if (PA[c]) st.push([c, i]); else if (')]}”’»'.indexOf(c) >= 0 && !(c === '’' && /[\p{L}]/u.test(tt[i - 1] || '') && /[\p{L}]/u.test(tt[i + 1] || ''))) { if (st.length && PA[st[st.length - 1][0]] === c) st.pop(); else mk('bracket', i + off, i + off + 1, 'Closing “' + c + '” has no opening', [fixTo(b.id, f, i + off, i + off + 1, '', 'Remove it'), fixTo(b.id, f, 0, 0, { '’': '‘', '”': '“', ')': '(', ']': '[', '}': '{', '»': '«' }[c], 'Add the opening at the start')]); } }
          st.forEach(function (o) { var cl = PA[o[0]]; if (o[0] === '‘' && /[\p{L}]/u.test(tt[o[1] - 1] || '')) return; mk('bracket', o[1] + off, o[1] + off + 1, 'Opening “' + o[0] + '” is never closed', [fixTo(b.id, f, t.length, t.length, cl, 'Close it at the end'), fixTo(b.id, f, o[1] + off, o[1] + off + 1, '', 'Remove it')]); });
          var q = (tt.match(/"/g) || []).length; if (q % 2) { var qi = tt.lastIndexOf('"'); mk('bracket', qi + off, qi + off + 1, 'A quotation mark " is not closed', [fixTo(b.id, f, t.length, t.length, '"', 'Close it at the end'), fixTo(b.id, f, qi + off, qi + off + 1, '', 'Remove it')]); }
        }
        /* repeated word */
        if (spaced && b.t !== 'scene') { re = /([\p{L}\p{M}\p{N}]+)([\s,]+)\1(?![\p{L}\p{M}\p{N}])/giu; while ((m = re.exec(t))) { if (m[1].length < 2 && !/\p{L}{2}/u.test(m[1])) continue; if (/^\d+$/.test(m[1])) continue; if (/^(no|yes|ha|ho|oh|ah|hey|go|come|wait|stop|please|never|very|so|ok|okay|run|bye|na|ayyo|aiyo|haha|ney|da|di)$/i.test(m[1]) && /,/.test(m[2])) continue; mk('repeat', m.index, m.index + m[0].length, 'The word “' + m[1] + '” is repeated', [fixTo(b.id, f, m.index, m.index + m[0].length, m[1], 'Keep one “' + m[1] + '”')]); } }
        /* english grammar */
        if (lang === 'en' && (b.t === 'action' || b.t === 'dial' || b.t === 'shot')) {
          re = /(^|[\s(“"])i(?=[\s,.!?'’]|$)/g; while ((m = re.exec(t))) mk('gram', m.index + m[1].length, m.index + m[1].length + 1, '“i” should be capital “I”', [fixTo(b.id, f, m.index + m[1].length, m.index + m[1].length + 1, 'I', 'Use “I”')]);
          re = /\b(a)\s+([aeiou]\w+)/gi; while ((m = re.exec(t))) { if (/^(uni|use|eur|one|ubi|uti|usu)/i.test(m[2])) continue; mk('gram', m.index, m.index + m[1].length, 'Use “' + (m[1] === 'A' ? 'An' : 'an') + '” before “' + m[2] + '”', [fixTo(b.id, f, m.index, m.index + m[1].length, m[1] === 'A' ? 'An' : 'an', 'Use “' + (m[1] === 'A' ? 'An' : 'an') + '”')]); }
          re = /(^|[.!?]\s+)([a-z])/g; if (b.t !== 'shot') while ((m = re.exec(t))) { var st0 = m.index + m[1].length; if (m.index === 0 && /^[a-z]/.test(t) && b.t === 'dial' && false) continue; mk('gram', st0, st0 + 1, 'A sentence should start with a capital letter', [fixTo(b.id, f, st0, st0 + 1, m[2].toUpperCase(), 'Capitalise')]); }
          re = /[A-Za-z']+/g; while ((m = re.exec(t))) { var lw = m[0].toLowerCase(); if (EN_TYPO[lw] && !(lw === 'im' || lw === 'ive') ) mk('spell', m.index, m.index + m[0].length, 'Spelling: “' + m[0] + '”', [fixTo(b.id, f, m.index, m.index + m[0].length, /^[A-Z]/.test(m[0]) ? EN_TYPO[lw][0].toUpperCase() + EN_TYPO[lw].slice(1) : EN_TYPO[lw], 'Use “' + EN_TYPO[lw] + '”')]); }
          if (b.t === 'scene' && !/^(INT|EXT|I\/E|INT\.\/EXT)/i.test(t.replace(/^\s*\d+[.\s]*/, ''))) { }
        }
        /* look-alike spelling */
        if (spaced && b.t !== 'char' && b.t !== 'scene') { re = WORD; re.lastIndex = 0; while ((m = re.exec(t))) { var w = m[0].toLowerCase(); if (freq[w] !== 1 || w.length < 4 || /\d/.test(w) || nameSet[w] || (lang === 'en' && EN_TYPO[w])) continue; var nw = nearWord(w); if (nw) { var rep = /^\p{Lu}/u.test(m[0]) ? nw[0].toUpperCase() + nw.slice(1) : nw; mk('spell', m.index, m.index + m[0].length, 'Possible spelling mistake: “' + m[0] + '”', [fixTo(b.id, f, m.index, m.index + m[0].length, rep, 'Use “' + rep + '”')]); rareHits[w] = 1; } } }
        /* google suggestions (filled in earlier by PF.google) */
        if (googleOk && spaced && b.t !== 'char' && b.t !== 'scene') { re = WORD; re.lastIndex = 0; while ((m = re.exec(t))) { var g = googleMap[m[0]]; if (g && g.length && !rareHits[m[0].toLowerCase()]) mk('spell', m.index, m.index + m[0].length, 'Google suggests another spelling for “' + m[0] + '”', g.slice(0, 4).map(function (sg) { return fixTo(b.id, f, m.index, m.index + m[0].length, sg, 'Use “' + sg + '”'); })); } }
      });
      /* structure */
      var nx = bl[bi + 1];
      if (b.t === 'char' && (!nx || (nx.t !== 'dial' && nx.t !== 'paren')) && nameOf(b)) add({ kind: 'struct', key: key('struct', b.id, 'nodial'), bi: bi, msg: 'A character name with no dialogue after it', html: esc(nameOf(b)), fixes: [{ l: 'Add a dialogue line', fn: function () { insertAfter(b.id, { t: 'dial', x: '' }); } }, { l: 'Delete this name', fn: function () { removeBlock(b.id); } }] });
      if (b.t === 'dial' && (b.x || '').trim()) { var pv = bl[bi - 1]; if (!pv || (pv.t !== 'char' && pv.t !== 'paren' && pv.t !== 'dial')) add({ kind: 'struct', key: key('struct', b.id, 'nochar'), bi: bi, msg: 'Dialogue with no character name above it', html: esc((b.x || '').slice(0, 60)), fixes: [{ l: 'Turn into action', fn: function () { A.setType(b, 'action'); } }, { l: 'Add a character name', fn: function () { insertBefore(b.id, { t: 'char', x: '' }); } }] }); }
      if (b.t === 'scene' && lang === 'en' && (b.x || '').trim() && !/^\s*(\d+[.\s]+)?(INT|EXT|I\/E|EST)\b/i.test(b.x)) add({ kind: 'struct', key: key('struct', b.id, 'head'), bi: bi, msg: 'Scene heading should begin with INT. or EXT.', html: esc(b.x), fixes: [{ l: 'Add “INT. ”', fn: function () { edit(b.id, 'x', 0, 0, 'INT. '); } }, { l: 'Add “EXT. ”', fn: function () { edit(b.id, 'x', 0, 0, 'EXT. '); } }] });
    });
    /* transitions */
    var scenes = [], tr = 0;
    bl.forEach(function (b, i) { if (b.t === 'scene' && (b.x || '').trim()) scenes.push(i); });
    var missing = [];
    for (var s = 1; s < scenes.length; s++) { var has = false; for (var j = scenes[s - 1] + 1; j < scenes[s]; j++) if (bl[j].t === 'trans' && (bl[j].x || '').trim()) has = true; if (has) tr++; else missing.push(scenes[s]); }
    if (scenes.length > 1 && tr > 0 && missing.length) {
      if (tr / (scenes.length - 1) >= 0.25) missing.forEach(function (i) { add({ kind: 'trans', key: key('trans', bl[i].id, 'm'), bi: i, msg: 'No transition before this scene', html: esc(bl[i].x), fixes: [{ l: 'Add CUT TO:', fn: function () { insertBefore(bl[i].id, { t: 'trans', x: 'CUT TO:' }); } }, { l: 'Add DISSOLVE TO:', fn: function () { insertBefore(bl[i].id, { t: 'trans', x: 'DISSOLVE TO:' }); } }] }); });
      else add({ kind: 'trans', key: key('trans', 'all', String(missing.length)), bi: missing[0], msg: missing.length + ' scene changes have no transition (' + tr + ' have one)', html: 'Most scenes change without a transition, which is fine for many scripts.', fixes: [{ l: 'Add CUT TO: to all of them', fn: function () { missing.slice().reverse().forEach(function (i) { insertBefore(bl[i].id, { t: 'trans', x: 'CUT TO:' }, 1); }); A.renderAll(); A.snap(); A.dirty(); } }] });
    }
    out.sort(function (a, b) { return a.bi - b.bi || (a.a || 0) - (b.a || 0); });
    return out;
  }

  /* ---------- edits ---------- */
  function cur() { return A.cur; }
  function blk(id) { return cur().blocks.filter(function (b) { return b.id === id; })[0]; }
  function redraw(b) { var w = A.blockEl(b.id); if (!w) return; ['x', 'x2'].forEach(function (f) { var e = w.querySelector('.ed[data-f="' + f + '"]'); if (!e) return; var v = b[f] || '', runs = b.fm && b.fm[f]; if (b.t === 'paren' && f === 'x') { A.drawRich(e, '(' + v + ')', []); } else A.drawRich(e, v, runs); }); }
  function edit(id, f, a, e, v, noSnap) {
    var b = blk(id); if (!b) return; if (!noSnap) A.snap(); var t = b[f] || '', delta = v.length - (e - a);
    if (b.t === 'paren' && f === 'x' && /^\(/.test(t) === false && false) { }
    b[f] = t.slice(0, a) + v + t.slice(e);
    if (b.fm && b.fm[f]) b.fm[f] = b.fm[f].map(function (r) { var ns = r.s <= a ? r.s : (r.s >= e ? r.s + delta : a), ne = r.e <= a ? r.e : (r.e >= e ? r.e + delta : a + v.length); return Object.assign({}, r, { s: ns, e: Math.max(ns, ne) }); }).filter(function (r) { return r.e > r.s; });
    redraw(b); if (!noSnap) { A.snap(); A.dirty(); }
  }
  function fixTo(id, f, a, e, v, label) { return { l: label, fn: function () { edit(id, f, a, e, v); } }; }
  function rename(from, to) { A.snap(); cur().blocks.forEach(function (b) { if (b.t === 'char' && nameOf(b).toLowerCase() === from.toLowerCase()) { var old = b.x || ''; b.x = old.replace(nameOf(b), to); if (b.fm) delete b.fm.x; redraw(b); } }); A.snap(); A.dirty(); A.refreshSide(); }
  function insertAfter(id, nb) { A.snap(); nb.id = A.uid(); var i = A.idxOf(id); cur().blocks.splice(i + 1, 0, nb); A.renderAll(); A.snap(); A.dirty(); }
  function insertBefore(id, nb, batch) { if (!batch) A.snap(); nb.id = A.uid(); var i = A.idxOf(id); cur().blocks.splice(i, 0, nb); if (!batch) { A.renderAll(); A.snap(); A.dirty(); } }
  function removeBlock(id) { A.snap(); var i = A.idxOf(id); cur().blocks.splice(i, 1); if (!cur().blocks.length) cur().blocks.push({ id: A.uid(), t: 'action', x: '' }); A.renderAll(); A.snap(); A.dirty(); }

  /* ---------- Google spelling (optional, online) ---------- */
  var GLANG = { ml: 'ml', en: 'en', hi: 'hi', ta: 'ta', te: 'te', kn: 'kn', mr: 'mr', bn: 'bn', gu: 'gu', pa: 'pa', ar: 'ar', de: 'de', fr: 'fr', it: 'it', es: 'es', ru: 'ru', tr: 'tr', id: 'id', ko: 'ko', ja: 'ja', zh: 'zh-CN', th: 'th', tl: 'tl' };
  PF.google = function (d) {
    var lang = GLANG[d.lang]; if (!lang || NOSPACE[d.lang] || navigator.onLine === false) return Promise.resolve(false);
    var seen = {}, words = []; d.blocks.forEach(function (b) { if (b.t === 'char' || b.t === 'scene' || b.t === 'img') return; var m, s = b.x || ''; WORD.lastIndex = 0; while ((m = WORD.exec(s))) { if (m[0].length > 2 && !/\d/.test(m[0]) && !seen[m[0]] && !(m[0] in googleMap)) { seen[m[0]] = 1; words.push(m[0]); } } });
    words = words.slice(0, 600); if (!words.length) return Promise.resolve(googleOk === true);
    var chunks = []; for (var i = 0; i < words.length; i += 150) chunks.push(words.slice(i, i + 150));
    var any = false, ctl = new AbortController(), tm = setTimeout(function () { ctl.abort(); }, 9000);
    return chunks.reduce(function (p, ch) {
      return p.then(function () {
        var xml = '<?xml version="1.0" encoding="utf-8"?><spellrequest textalreadyclipped="0" ignoredups="1" ignoredigits="1" ignoreallcaps="1" ignorecase="0"><text>' + ch.map(function (w) { return esc(w); }).join(' ') + '</text></spellrequest>';
        return fetch('https://www.google.com/tbproxy/spell?lang=' + lang + '&hl=' + lang, { method: 'POST', body: xml, signal: ctl.signal }).then(function (r) { if (!r.ok) throw 0; return r.text(); }).then(function (x) {
          any = true; var re = /<c o="(\d+)" l="(\d+)"[^>]*>([^<]*)<\/c>/g, m, txt = ch.join(' ');
          while ((m = re.exec(x))) { var wd = txt.substr(+m[1], +m[2]); googleMap[wd] = m[3].split('\t').map(function (s) { return s.trim(); }).filter(Boolean); }
          ch.forEach(function (w) { if (!(w in googleMap)) googleMap[w] = []; });
        });
      });
    }, Promise.resolve()).then(function () { clearTimeout(tm); googleOk = any; return any; }, function () { clearTimeout(tm); googleOk = googleOk === true; return googleOk; });
  };

  /* ---------- window ---------- */
  PF.open = function () {
    var d = cur(); if (!d) return; ignored = {}; googleMap = {}; googleOk = null; var filter = '', shown = 40, note = '';
    var wrap = el('div', 'pfw'), head = el('div', 'pfhead'), chips = el('div', 'pfchips'), list = el('div', 'pdflist pflist'), foot = el('div', 'pfnote');
    wrap.appendChild(head); wrap.appendChild(chips); wrap.appendChild(list); wrap.appendChild(foot);
    var dl = A.dlg('Proofread', wrap, [{ l: 'Close' }, { l: 'Fix all marks & spaces', fn: function () { fixSafe(); return false; } }], { nofocus: true });
    dl.classList.add('pfdlg');
    function fixSafe() {
      var n = 0, guard = 0; A.snap();
      for (;;) { var it = analyse(cur()).filter(function (o) { return o.kind === 'marks' && o.fixes && o.fixes.length; })[0]; if (!it || guard++ > 800) break; var b = blk(cur().blocks[it.bi].id); it.fixes[0].fn(); n++; }
      A.toastIn(n ? n + ' fixed' : 'Nothing to fix automatically'); draw();
    }
    function draw() {
      var all = analyse(cur()), cnt = {}; all.forEach(function (o) { cnt[o.kind] = (cnt[o.kind] || 0) + 1; });
      if (!all.length) { dl.close(); A.toastIn('No mistakes left ✓'); return; }
      head.innerHTML = '<b>' + all.length + '</b> thing' + (all.length === 1 ? '' : 's') + ' to check';
      chips.innerHTML = ''; [['', 'All ' + all.length]].concat(Object.keys(cnt).map(function (k) { return [k, KIND[k] + ' ' + cnt[k]]; })).forEach(function (c) { var b = el('button', 'btn' + (filter === c[0] ? ' on' : ''), esc(c[1])); b.onclick = function () { filter = c[0]; shown = 40; draw(); }; chips.appendChild(b); });
      var rows = all.filter(function (o) { return !filter || o.kind === filter; }); list.innerHTML = '';
      rows.slice(0, shown).forEach(function (o) {
        var r = el('div', 'pfrow'); r.appendChild(el('div', 'pfmsg', '<span class="pftag">' + KIND[o.kind] + '</span> ' + esc(o.msg)));
        r.appendChild(el('div', 'pfctx', o.html));
        var fx = el('div', 'pffix'); (o.fixes || []).forEach(function (f) { var b = el('button', 'btn pri', esc(f.l)); b.onclick = function () { f.fn(); draw(); }; fx.appendChild(b); });
        var cu = el('button', 'btn', 'Custom…'); cu.onclick = function () {
          var row = el('div', 'pfcust'), inp = el('input'); inp.type = 'text'; inp.value = o.kind === 'name' ? '' : (o.f ? (blk(cur().blocks[o.bi].id)[o.f] || '').slice(o.a, o.e) : ''); inp.placeholder = 'Type the correction';
          var ok = el('button', 'btn pri', 'Apply'); ok.onclick = function () { if (o.custom) { o.custom(inp.value); } draw(); }; row.appendChild(inp); row.appendChild(ok); r.appendChild(row); cu.disabled = true; setTimeout(function () { inp.focus(); }, 30);
        }; fx.appendChild(cu);
        var ig = el('button', 'btn', 'Ignore'); ig.onclick = function () { ignored[o.key] = 1; draw(); }; fx.appendChild(ig);
        var go = el('button', 'btn', 'Go to line'); go.onclick = function () { dl.close(); var id = cur().blocks[o.bi] && cur().blocks[o.bi].id; if (id) A.focusBlock(id, o.a || 0, o.f || 'x'); }; fx.appendChild(go);
        r.appendChild(fx); list.appendChild(r);
      });
      if (rows.length > shown) { var more = el('button', 'btn', 'Show ' + Math.min(40, rows.length - shown) + ' more'); more.onclick = function () { shown += 40; draw(); }; list.appendChild(more); }
      foot.textContent = note;
    }
    draw();
    if (navigator.onLine !== false && GLANG[d.lang]) { note = 'Asking Google for spelling suggestions…'; foot.textContent = note; PF.google(d).then(function (ok) { note = ok ? 'Google spelling suggestions included.' : 'Offline checks only (Google spelling was not available).'; if (document.body.contains(wrap)) draw(); }); }
    else { note = 'Offline checks only – connect to the internet for Google spelling suggestions.'; foot.textContent = note; }
  };
  var st = document.createElement('style'); st.textContent = '.pfdlg{max-width:min(96vw,560px)}.pfhead{font-size:15px;margin-bottom:6px}.pfchips{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px}.pfchips .btn{padding:5px 12px;font-size:12px}.pfchips .btn.on{background:#5e6cf2;color:#fff}' +
    '.pflist{max-height:52vh;overflow:auto}.pfrow{padding:10px 2px;border-bottom:1px solid rgba(128,128,128,.25)}.pfmsg{font-size:13.5px;font-weight:600}.pftag{font-size:10.5px;text-transform:uppercase;letter-spacing:.04em;padding:2px 7px;border-radius:99px;background:rgba(94,108,242,.18);margin-right:4px;font-weight:700}' +
    '.pfctx{font-size:13px;opacity:.85;margin:5px 0;word-break:break-word}.pfctx mark{background:rgba(255,170,60,.5);color:inherit;border-radius:4px;padding:0 2px}.pffix{display:flex;gap:6px;flex-wrap:wrap}.pffix .btn{padding:5px 12px;font-size:12px}.pfcust{display:flex;gap:6px;margin-top:6px;width:100%}.pfcust input{flex:1;min-width:0;padding:7px 12px;border-radius:99px;border:1px solid rgba(128,128,128,.4);background:transparent;color:inherit;font:inherit}.pfnote{font-size:12px;opacity:.7;margin-top:8px}';
  document.head.appendChild(st);
})();
