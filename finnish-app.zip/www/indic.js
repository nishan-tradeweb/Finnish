/* Phonetic (English-letter) typing for Tamil, Telugu, Kannada, Hindi, Marathi, Bengali, Gujarati, Punjabi, Assamese and Bhojpuri.
   Malayalam has its own engine in translit.js. To tune a language, edit LANG below (base, schwa, fallbacks). */
(function () {
  var THK = window.THK = window.THK || {};
  var LANG = {
    ta: { base: 0x0B80, schwa: false, noV: true, fb: { kh: 'k', g: 'k', gh: 'k', chh: 'ch', jh: 'j', Th: 'T', D: 'T', Dh: 'T', th: 't', d: 't', dh: 't', ph: 'p', b: 'p', bh: 'p', f: 'p' } },
    te: { base: 0x0C00, schwa: false, fb: { zh: 'L' } },
    kn: { base: 0x0C80, schwa: false, fb: { zh: 'L' } },
    hi: { base: 0x0900, schwa: true, noShort: true, fb: { zh: 'L' } },
    mr: { base: 0x0900, schwa: true, noShort: true, fb: { zh: 'L' } },
    bn: { base: 0x0980, schwa: true, noShort: true, fb: { v: 'b', w: 'b', zh: 'l', L: 'l' } },
    gu: { base: 0x0A80, schwa: true, noShort: true, fb: { zh: 'L' } },
    pa: { base: 0x0A00, schwa: true, noShort: true, fb: { zh: 'L', Sh: 'sh', R: 'r' } },
    as: { base: 0x0980, schwa: true, noShort: true, fb: { zh: 'l', L: 'l' }, cs: { r: 0x70, R: 0x70, w: 0x71, v: 0x71 } },
    bho: { base: 0x0900, schwa: true, noShort: true, fb: { zh: 'L' } }
  };
  var CONS = { k: 0x15, kh: 0x16, g: 0x17, gh: 0x18, ng: 0x19, ch: 0x1A, c: 0x1A, chh: 0x1B, j: 0x1C, jh: 0x1D, nj: 0x1E, ny: 0x1E, T: 0x1F, Th: 0x20, D: 0x21, Dh: 0x22, N: 0x23, t: 0x24, th: 0x25, d: 0x26, dh: 0x27, n: 0x28,
    p: 0x2A, ph: 0x2B, f: 0x2B, b: 0x2C, bh: 0x2D, m: 0x2E, y: 0x2F, r: 0x30, R: 0x31, l: 0x32, L: 0x33, zh: 0x34, v: 0x35, w: 0x35, sh: 0x36, Sh: 0x37, s: 0x38, h: 0x39, z: 0x1C, q: 0x15, x: -1 };
  var VOW = { a: [0x05, 0], aa: [0x06, 0x3E], A: [0x06, 0x3E], i: [0x07, 0x3F], ii: [0x08, 0x40], ee: [0x08, 0x40], I: [0x08, 0x40], u: [0x09, 0x41], uu: [0x0A, 0x42], oo: [0x0A, 0x42], U: [0x0A, 0x42],
    e: [0x0E, 0x46], E: [0x0F, 0x47], ai: [0x10, 0x48], o: [0x12, 0x4A], O: [0x13, 0x4B], au: [0x14, 0x4C], ou: [0x14, 0x4C], Ri: [0x0B, 0x43] };
  var CT = ['chh', 'ch', 'kh', 'gh', 'jh', 'ng', 'nj', 'ny', 'Th', 'Dh', 'th', 'dh', 'ph', 'bh', 'zh', 'sh', 'Sh', 'k', 'g', 'c', 'j', 'T', 'D', 'N', 't', 'd', 'n', 'p', 'f', 'b', 'm', 'y', 'r', 'R', 'l', 'L', 'v', 'w', 's', 'h', 'z', 'q', 'x'];
  var VT = ['Ri', 'aa', 'ai', 'au', 'ou', 'ee', 'ii', 'oo', 'uu', 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'];
  function make(lang) {
    var L = LANG[lang]; if (!L) return null; var B = L.base, VIR = String.fromCharCode(B + 0x4D);
    function cons(tok) {
      var t = tok; if (L.cs && L.cs[t] != null) return L.cs[t]; if (L.fb[t]) t = L.fb[t]; var o = CONS[t];
      if (L.noV && (t === 'v' || t === 'w')) o = 0x35;
      return o;
    }
    function vowel(tok) { var v = VOW[tok]; if (L.noShort) { if (tok === 'e') v = VOW.E; if (tok === 'o') v = VOW.O; } if (lang === 'ta' && tok === 'Ri') return null; return v; }
    function mC(s, i) { for (var k = 0; k < CT.length; k++) { var t = CT[k]; if (s.substr(i, t.length) === t) return t; } return null; }
    function mV(s, i) { for (var k = 0; k < VT.length; k++) { var t = VT[k]; if (s.substr(i, t.length) === t) return t; } return null; }
    return function (buf) {
      var out = '', i = 0, n = buf.length;
      while (i < n) {
        var c = mC(buf, i);
        if (c) {
          i += c.length;
          if (c === 'x') out += String.fromCharCode(B + 0x15) + VIR + String.fromCharCode(B + 0x37); else out += String.fromCharCode(B + cons(c));
          var v = mV(buf, i), vv = v && vowel(v);
          if (v && vv) { i += v.length; if (vv[1]) out += String.fromCharCode(B + vv[1]); continue; }
          if (mC(buf, i)) { out += VIR; continue; }
          if (i >= n && !L.schwa) out += VIR;
          continue;
        }
        var w = mV(buf, i), wv = w && vowel(w);
        if (w && wv) { i += w.length; out += String.fromCharCode(B + wv[0]); continue; }
        var ch = buf.charAt(i++);
        if (ch === 'M') out += String.fromCharCode(B + 2); else if (ch === 'H') out += String.fromCharCode(B + 3); else out += ch;
      }
      return out;
    };
  }
  var cache = {};
  THK.IT = { fn: function (lang) { return cache[lang] || (cache[lang] = make(lang) || function (s) { return s; }); } };
})();
