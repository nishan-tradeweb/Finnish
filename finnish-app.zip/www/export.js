/* Export / import helpers: PDF (via the browser's print engine, so Malayalam shaping is perfect), Fountain. */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {};
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function uid() { return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4); }

  /* ---------------------------------------------------------------- Fountain */
  THK.toFountain = function (d, withTitle) {
    var out = [];
    if (withTitle) {
      out.push('Title: ' + (d.title || 'Untitled'));
      if (d.credit) out.push('Credit: ' + d.credit);
      if (d.author) out.push('Author: ' + d.author);
      if (d.draft) out.push('Draft date: ' + d.draft);
      if (d.contact) out.push('Contact:\n    ' + d.contact.replace(/\n/g, '\n    '));
      out.push('');
    }
    var blank = function () { if (out.length && out[out.length - 1] !== '') out.push(''); };
    var sn = 0;
    d.blocks.forEach(function (b) {
      if (b.t === 'scene') sn++;
      var x = b.x.trim(); if (!x) return;
      if (b.t === 'scene') { x = THK.stripSn(x); blank(); out.push((/^(INT|EXT|EST|I\/E|INT\.?\/EXT)[. \/]/i.test(x) ? '' : '.') + x.toUpperCase() + ' #' + sn + '#'); out.push(''); }
      else if (b.t === 'char') { blank(); out.push('@' + x.toUpperCase()); }
      else if (b.t === 'paren') out.push('(' + x + ')');
      else if (b.t === 'dial') { out.push(x); out.push(''); }
      else if (b.t === 'trans') { blank(); out.push('> ' + x.toUpperCase()); out.push(''); }
      else if (b.t === 'shot') { blank(); out.push('!' + x.toUpperCase()); out.push(''); }
      else if (b.t === 'note') { blank(); out.push('[[' + x + ']]'); out.push(''); }
      else { var ct = THK.el && THK.el.get(d, b.t); if (ct) x = ct.pre + (ct.up ? x.toUpperCase() : x) + ct.suf; blank(); out.push('!' + x); out.push(''); }
    });
    return out.join('\n').replace(/\n{3,}/g, '\n\n').trim() + '\n';
  };

  THK.parseFountain = function (text) {
    text = text.replace(/\r/g, '').replace(/^﻿/, '');
    var blocks = [], add = function (t, x) { x = x.trim(); if (t === 'scene') x = THK.stripSn(x).trim(); if (x) blocks.push({ id: uid(), t: t, x: x }); };
    var paras = text.split(/\n{2,}/);
    if (paras.length && /^[A-Za-z][A-Za-z ]*:/.test(paras[0].split('\n')[0]) && !/^(INT|EXT)/i.test(paras[0])) paras.shift();
    paras.forEach(function (p) {
      var lines = p.split('\n').map(function (l) { return l.replace(/\s+$/, ''); }).filter(function (l) { return l.trim() !== ''; });
      if (!lines.length) return;
      var f = lines[0].trim();
      if (/^\[\[.*\]\]$/.test(p.trim())) return add('note', p.trim().slice(2, -2));
      if (f[0] === '.' && f[1] !== '.') { add('scene', f.slice(1)); lines.slice(1).forEach(function (l) { add('action', l); }); return; }
      if (/^(INT|EXT|EST|I\/E|INT\.?\/EXT)[. \/]/i.test(f)) { add('scene', f); lines.slice(1).forEach(function (l) { add('action', l); }); return; }
      if (f[0] === '>' && f.slice(-1) !== '<') return add('trans', f.slice(1));
      if (/^[A-Z0-9 ()'.\-]+TO:$/.test(f)) return add('trans', f);
      if (f[0] === '!') { lines.forEach(function (l) { add('action', l.replace(/^!/, '')); }); return; }
      var isChar = f[0] === '@' || (lines.length > 1 && /[A-Z]/.test(f) && f === f.toUpperCase() && !/[a-z]/.test(f));
      if (isChar) {
        add('char', f.replace(/^@/, ''));
        lines.slice(1).forEach(function (l) { l = l.trim(); if (/^\(.*\)$/.test(l)) add('paren', l.slice(1, -1)); else add('dial', l); });
        return;
      }
      lines.forEach(function (l) { add('action', l.replace(/^>\s*|\s*<$/g, '')); });
    });
    return blocks;
  };

  /* ---------------------------------------------------------------- PDF (print engine => correct Malayalam shaping) */
  THK.PAPER = { a4: { w: '210mm', h: '297mm', n: 'A4' }, letter: { w: '215.9mm', h: '279.4mm', n: 'Letter' }, legal: { w: '215.9mm', h: '355.6mm', n: 'Legal' }, a5: { w: '148mm', h: '210mm', n: 'A5' } };
  THK.paperOf = function (d) { if (d.paper === 'custom') return { w: (d.pw || 210) + 'mm', h: (d.ph || 297) + 'mm', n: 'Custom' }; return THK.PAPER[d.paper] || THK.PAPER.a4; };
  THK.paperPx = function (d) { return Math.round(parseFloat(THK.paperOf(d).w) * 96 / 25.4); };
  /* ---- languages and fonts. To add or tune a language later, edit THK.LANGS and the FONT_ROWS table only. ---- */
  THK.LANGS = [
    { id: 'en', short: 'EN', name: 'English', native: 'English', def: 'CourierPrime', sample: 'Aa', bcp: 'en' },
    { id: 'ml', short: 'ML', name: 'Malayalam', native: 'മലയാളം', def: 'Manjari', translit: true, sample: 'അ', bcp: 'ml' },
    { id: 'ta', short: 'TA', name: 'Tamil', native: 'தமிழ்', def: 'NotoSansTA', translit: true, sample: 'அ', bcp: 'ta' },
    { id: 'te', short: 'TE', name: 'Telugu', native: 'తెలుగు', def: 'NotoSansTE', translit: true, sample: 'అ', bcp: 'te' },
    { id: 'kn', short: 'KN', name: 'Kannada', native: 'ಕನ್ನಡ', def: 'NotoSansKN', translit: true, sample: 'ಅ', bcp: 'kn' },
    { id: 'hi', short: 'HI', name: 'Hindi', native: 'हिन्दी', def: 'NotoSansDV', translit: true, sample: 'अ', bcp: 'hi' },
    { id: 'mr', short: 'MR', name: 'Marathi', native: 'मराठी', def: 'NotoSansDV', translit: true, sample: 'अ', bcp: 'mr' },
    { id: 'bn', short: 'BN', name: 'Bengali', native: 'বাংলা', def: 'NotoSansBN', translit: true, sample: 'অ', bcp: 'bn' },
    { id: 'gu', short: 'GU', name: 'Gujarati', native: 'ગુજરાતી', def: 'NotoSansGU', translit: true, sample: 'અ', bcp: 'gu' },
    { id: 'pa', short: 'PA', name: 'Punjabi', native: 'ਪੰਜਾਬੀ', def: 'NotoSansPA', translit: true, sample: 'ਅ', bcp: 'pa' },
    { id: 'as', short: 'AS', name: 'Assamese', native: 'অসমীয়া', def: 'NotoSansBN', translit: true, sample: 'অ', bcp: 'as' },
    { id: 'bho', short: 'BHO', name: 'Bhojpuri', native: 'भोजपुरी', def: 'NotoSansDV', translit: true, sample: 'अ', bcp: 'hi' },
    { id: 'th', short: 'TH', name: 'Thai', native: 'ไทย', def: 'Sarabun', sample: 'ก', bcp: 'th' },
    { id: 'tl', short: 'TL', name: 'Tagalog', native: 'Tagalog', def: 'CourierPrime', sample: 'Aa', bcp: 'fil' },
    { id: 'tr', short: 'TR', name: 'Turkish', native: 'Türkçe', def: 'CourierPrime', sample: 'Aa', bcp: 'tr' },
    { id: 'ru', short: 'RU', name: 'Russian', native: 'Русский', def: 'Cousine', sample: 'Аа', bcp: 'ru' },
    { id: 'id', short: 'ID', name: 'Indonesian', native: 'Bahasa Indonesia', def: 'CourierPrime', sample: 'Aa', bcp: 'id' },
    { id: 'ar', short: 'AR', name: 'Arabic', native: 'العربية', def: 'NotoNaskhAR', rtl: true, sample: 'أ', bcp: 'ar' },
    { id: 'zh', short: 'ZH', name: 'Mandarin Chinese', native: '中文（普通话）', def: 'NotoSansSC', sample: '文', bcp: 'zh-CN' },
    { id: 'de', short: 'DE', name: 'German', native: 'Deutsch', def: 'CourierPrime', sample: 'Aa', bcp: 'de' },
    { id: 'fr', short: 'FR', name: 'French', native: 'Français', def: 'CourierPrime', sample: 'Aa', bcp: 'fr' },
    { id: 'it', short: 'IT', name: 'Italian', native: 'Italiano', def: 'CourierPrime', sample: 'Aa', bcp: 'it' },
    { id: 'es', short: 'ES', name: 'Spanish', native: 'Español', def: 'CourierPrime', sample: 'Aa', bcp: 'es' },
    { id: 'ko', short: 'KO', name: 'Korean', native: '한국어', def: 'NotoSansKR', sample: '한', bcp: 'ko' },
    { id: 'ja', short: 'JA', name: 'Japanese', native: '日本語', def: 'NotoSansJP', sample: 'あ', bcp: 'ja' }
  ];
  /* speech locale per language (used by Speak to type and Read aloud) */
  THK.LOC = { en: /^en/i.test((typeof navigator !== 'undefined' && navigator.language) || '') ? navigator.language : 'en-US', ml: 'ml-IN', ta: 'ta-IN', te: 'te-IN', kn: 'kn-IN', hi: 'hi-IN', mr: 'mr-IN', bn: 'bn-IN', gu: 'gu-IN', pa: 'pa-IN', as: 'as-IN', bho: 'hi-IN',
    th: 'th-TH', tl: 'fil-PH', tr: 'tr-TR', ru: 'ru-RU', id: 'id-ID', ar: 'ar-SA', zh: 'zh-CN', de: 'de-DE', fr: 'fr-FR', it: 'it-IT', es: 'es-ES', ko: 'ko-KR', ja: 'ja-JP' };
  /* country -> languages, for the two-step language picker (English is always one tap away at the top) */
  THK.COUNTRIES = [
    ['India', ['ml', 'ta', 'te', 'kn', 'hi', 'mr', 'bn', 'gu', 'pa', 'as', 'bho', 'en']],
    ['United States', ['en', 'es']], ['United Kingdom', ['en']], ['Canada', ['en', 'fr']], ['Australia', ['en']],
    ['Germany', ['de']], ['France', ['fr']], ['Italy', ['it']], ['Spain', ['es']], ['Turkey', ['tr']], ['Russia', ['ru']],
    ['China', ['zh']], ['Japan', ['ja']], ['South Korea', ['ko']], ['Thailand', ['th']], ['Philippines', ['tl', 'en']], ['Indonesia', ['id']],
    ['Saudi Arabia & Arab world', ['ar']]
  ];
  // [id, label, css stack, Google Fonts family (empty = not on Google / bundled), languages ("all" or comma list), type: b = body only, d = title/display only, x = both]
  var FONT_ROWS = [
    ['Manjari', 'Manjari', "'Manjari Local','Manjari'", 'Manjari:wght@400;700', 'ml', 'x'],
    ['Meera', 'Meera', "'Meera'", '', 'ml', 'x'],
    ['Rachana', 'Rachana', "'Rachana'", '', 'ml', 'x'],
    ['Dyuthi', 'Dyuthi', "'Dyuthi'", '', 'ml', 'x'],
    ['Chilanka', 'Chilanka', "'Chilanka Local','Chilanka'", 'Chilanka', 'ml', 'x'],
    ['Gayathri', 'Gayathri', "'Gayathri Local','Gayathri'", 'Gayathri:wght@400;700', 'ml', 'x'],
    ['NotoSans', 'Noto Sans Malayalam', "'Noto Sans Malayalam'", 'Noto+Sans+Malayalam:wght@400;700', 'ml', 'b'],
    ['NotoSerif', 'Noto Serif Malayalam', "'Noto Serif Malayalam'", 'Noto+Serif+Malayalam:wght@400;700', 'ml', 'x'],
    ['AnekML', 'Anek Malayalam', "'Anek Malayalam'", 'Anek+Malayalam:wght@400;700', 'ml', 'x'],
    ['BalooChettan', 'Baloo Chettan 2', "'Baloo Chettan 2'", 'Baloo+Chettan+2:wght@400;700', 'ml', 'x'],
    ['CourierPrime', 'Courier Prime', "'Courier Prime Local','Courier Prime','Courier New',monospace", 'Courier+Prime:wght@400;700', 'en,de,fr,it,es,id,tl,tr', 'x'],
    ['CourierNew', 'Courier New', "'Courier New',Courier,monospace", '', 'en,de,fr,it,es,id,tl,tr,ru', 'b'],
    ['Times', 'Times New Roman', "'Times New Roman',Times,serif", '', 'en,de,fr,it,es,id,tl,tr,ru', 'b'],
    ['Arial', 'Arial', "Arial,Helvetica,sans-serif", '', 'en,de,fr,it,es,id,tl,tr,ru', 'b'],
    ['Merriweather', 'Merriweather', "'Merriweather'", 'Merriweather:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'x'],
    ['Lora', 'Lora', "'Lora'", 'Lora:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'x'],
    ['Roboto', 'Roboto', "'Roboto'", 'Roboto:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'b'],
    ['OpenSans', 'Open Sans', "'Open Sans'", 'Open+Sans:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'b'],
    ['SourceSerif', 'Source Serif 4', "'Source Serif 4'", 'Source+Serif+4:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'b'],
    ['RobotoMono', 'Roboto Mono', "'Roboto Mono'", 'Roboto+Mono:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'b'],
    ['Inter', 'Inter', "'Inter'", 'Inter:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'b'],
    ['Playfair', 'Playfair Display', "'Playfair Display'", 'Playfair+Display:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'd'],
    ['Cinzel', 'Cinzel', "'Cinzel'", 'Cinzel:wght@400;700', 'en,de,fr,it,es,id,tl', 'd'],
    ['Cormorant', 'Cormorant Garamond', "'Cormorant Garamond'", 'Cormorant+Garamond:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'd'],
    ['Abril', 'Abril Fatface', "'Abril Fatface'", 'Abril+Fatface', 'en,de,fr,it,es,id,tl', 'd'],
    ['Bebas', 'Bebas Neue', "'Bebas Neue'", 'Bebas+Neue', 'en,de,fr,it,es,id,tl', 'd'],
    ['Oswald', 'Oswald', "'Oswald'", 'Oswald:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'd'],
    ['Anton', 'Anton', "'Anton'", 'Anton', 'en,de,fr,it,es,id,tl', 'd'],
    ['Lobster', 'Lobster', "'Lobster'", 'Lobster', 'en,de,fr,it,es,id,tl,tr,ru', 'd'],
    ['Pacifico', 'Pacifico', "'Pacifico'", 'Pacifico', 'en,de,fr,it,es,id,tl,tr,ru', 'd'],
    ['Dancing', 'Dancing Script', "'Dancing Script'", 'Dancing+Script:wght@400;700', 'en,de,fr,it,es,id,tl,tr', 'd'],
    ['GreatVibes', 'Great Vibes', "'Great Vibes'", 'Great+Vibes', 'en,de,fr,it,es,id,tl', 'd'],
    ['Satisfy', 'Satisfy', "'Satisfy'", 'Satisfy', 'en,de,fr,it,es,id,tl,tr', 'd'],
    ['Righteous', 'Righteous', "'Righteous'", 'Righteous', 'en,de,fr,it,es,id,tl', 'd'],
    ['Caveat', 'Caveat', "'Caveat'", 'Caveat:wght@400;700', 'en,de,fr,it,es,id,tl,tr,ru', 'd'],
    ['Orbitron', 'Orbitron', "'Orbitron'", 'Orbitron:wght@400;700', 'en,de,fr,it,es,id,tl', 'd'],
    ['SpecialElite', 'Special Elite', "'Special Elite'", 'Special+Elite', 'en,de,fr,it,es,id,tl', 'd'],
    ['Bangers', 'Bangers', "'Bangers'", 'Bangers', 'en,de,fr,it,es,id,tl', 'd'],
    ['PermanentMarker', 'Permanent Marker', "'Permanent Marker'", 'Permanent+Marker', 'en,de,fr,it,es,id,tl', 'd'],
    // ---- other languages (downloaded into the app at build time, see scripts/fetch-fonts.mjs) ----
    ['NotoSansTA', 'Noto Sans Tamil', "'Noto Sans Tamil'", 'Noto+Sans+Tamil:wght@400;700', 'ta', 'x'],
    ['NotoSerifTA', 'Noto Serif Tamil', "'Noto Serif Tamil'", 'Noto+Serif+Tamil:wght@400;700', 'ta', 'x'],
    ['HindMadurai', 'Hind Madurai', "'Hind Madurai'", 'Hind+Madurai', 'ta', 'x'],
    ['Catamaran', 'Catamaran', "'Catamaran'", 'Catamaran:wght@400;700', 'ta', 'x'],
    ['MuktaMalar', 'Mukta Malar', "'Mukta Malar'", 'Mukta+Malar', 'ta', 'x'],
    ['BalooThambi2', 'Baloo Thambi 2', "'Baloo Thambi 2'", 'Baloo+Thambi+2', 'ta', 'x'],
    ['AnekTamil', 'Anek Tamil', "'Anek Tamil'", 'Anek+Tamil:wght@400;700', 'ta', 'x'],
    ['Pavanam', 'Pavanam', "'Pavanam'", 'Pavanam', 'ta', 'x'],
    ['Kavivanar', 'Kavivanar', "'Kavivanar'", 'Kavivanar', 'ta', 'd'],
    ['MeeraInimai', 'Meera Inimai', "'Meera Inimai'", 'Meera+Inimai', 'ta', 'x'],
    ['TiroTamil', 'Tiro Tamil', "'Tiro Tamil'", 'Tiro+Tamil', 'ta', 'x'],
    ['Arima', 'Arima', "'Arima'", 'Arima:wght@400;700', 'ta', 'x'],
    ['NotoSansTE', 'Noto Sans Telugu', "'Noto Sans Telugu'", 'Noto+Sans+Telugu:wght@400;700', 'te', 'x'],
    ['NotoSerifTE', 'Noto Serif Telugu', "'Noto Serif Telugu'", 'Noto+Serif+Telugu:wght@400;700', 'te', 'x'],
    ['HindGuntur', 'Hind Guntur', "'Hind Guntur'", 'Hind+Guntur', 'te', 'x'],
    ['AnekTelugu', 'Anek Telugu', "'Anek Telugu'", 'Anek+Telugu:wght@400;700', 'te', 'x'],
    ['Mallanna', 'Mallanna', "'Mallanna'", 'Mallanna', 'te', 'x'],
    ['Mandali', 'Mandali', "'Mandali'", 'Mandali', 'te', 'x'],
    ['Gidugu', 'Gidugu', "'Gidugu'", 'Gidugu', 'te', 'x'],
    ['Ramabhadra', 'Ramabhadra', "'Ramabhadra'", 'Ramabhadra', 'te', 'x'],
    ['Suranna', 'Suranna', "'Suranna'", 'Suranna', 'te', 'x'],
    ['NTR', 'NTR', "'NTR'", 'NTR', 'te', 'x'],
    ['Dhurjati', 'Dhurjati', "'Dhurjati'", 'Dhurjati', 'te', 'x'],
    ['Peddana', 'Peddana', "'Peddana'", 'Peddana', 'te', 'x'],
    ['TiroTelugu', 'Tiro Telugu', "'Tiro Telugu'", 'Tiro+Telugu', 'te', 'x'],
    ['LakkiReddy', 'Lakki Reddy', "'Lakki Reddy'", 'Lakki+Reddy', 'te', 'x'],
    ['NotoSansKN', 'Noto Sans Kannada', "'Noto Sans Kannada'", 'Noto+Sans+Kannada:wght@400;700', 'kn', 'x'],
    ['NotoSerifKN', 'Noto Serif Kannada', "'Noto Serif Kannada'", 'Noto+Serif+Kannada:wght@400;700', 'kn', 'x'],
    ['BalooTamma2', 'Baloo Tamma 2', "'Baloo Tamma 2'", 'Baloo+Tamma+2', 'kn', 'x'],
    ['AnekKannada', 'Anek Kannada', "'Anek Kannada'", 'Anek+Kannada:wght@400;700', 'kn', 'x'],
    ['TiroKannada', 'Tiro Kannada', "'Tiro Kannada'", 'Tiro+Kannada', 'kn', 'x'],
    ['Gubbi', 'Gubbi', "'Gubbi'", 'Gubbi', 'kn', 'x'],
    ['Hubballi', 'Hubballi', "'Hubballi'", 'Hubballi', 'kn', 'x'],
    ['NotoSansBN', 'Noto Sans Bengali', "'Noto Sans Bengali'", 'Noto+Sans+Bengali:wght@400;700', 'bn,as', 'x'],
    ['NotoSerifBN', 'Noto Serif Bengali', "'Noto Serif Bengali'", 'Noto+Serif+Bengali:wght@400;700', 'bn,as', 'x'],
    ['HindSiliguri', 'Hind Siliguri', "'Hind Siliguri'", 'Hind+Siliguri', 'bn,as', 'x'],
    ['AnekBangla', 'Anek Bangla', "'Anek Bangla'", 'Anek+Bangla:wght@400;700', 'bn,as', 'x'],
    ['BalooDa2', 'Baloo Da 2', "'Baloo Da 2'", 'Baloo+Da+2', 'bn,as', 'x'],
    ['Atma', 'Atma', "'Atma'", 'Atma', 'bn', 'x'],
    ['Galada', 'Galada', "'Galada'", 'Galada', 'bn', 'd'],
    ['Mina', 'Mina', "'Mina'", 'Mina', 'bn', 'x'],
    ['TiroBangla', 'Tiro Bangla', "'Tiro Bangla'", 'Tiro+Bangla', 'bn', 'x'],
    ['NotoSansDV', 'Noto Sans Devanagari', "'Noto Sans Devanagari'", 'Noto+Sans+Devanagari:wght@400;700', 'hi,mr,bho', 'x'],
    ['NotoSerifDV', 'Noto Serif Devanagari', "'Noto Serif Devanagari'", 'Noto+Serif+Devanagari:wght@400;700', 'hi,mr,bho', 'x'],
    ['Hind', 'Hind', "'Hind'", 'Hind', 'hi,mr,bho', 'x'],
    ['Mukta', 'Mukta', "'Mukta'", 'Mukta', 'hi,mr,bho', 'x'],
    ['Poppins', 'Poppins', "'Poppins'", 'Poppins', 'hi,mr,bho', 'x'],
    ['Kalam', 'Kalam', "'Kalam'", 'Kalam', 'hi,mr,bho', 'x'],
    ['Martel', 'Martel', "'Martel'", 'Martel', 'hi,mr,bho', 'x'],
    ['Eczar', 'Eczar', "'Eczar'", 'Eczar', 'hi,mr,bho', 'x'],
    ['Laila', 'Laila', "'Laila'", 'Laila', 'hi,mr,bho', 'x'],
    ['Palanquin', 'Palanquin', "'Palanquin'", 'Palanquin', 'hi,mr,bho', 'x'],
    ['Rajdhani', 'Rajdhani', "'Rajdhani'", 'Rajdhani', 'hi,mr,bho', 'x'],
    ['Khand', 'Khand', "'Khand'", 'Khand', 'hi,mr,bho', 'x'],
    ['Sarpanch', 'Sarpanch', "'Sarpanch'", 'Sarpanch', 'hi,mr,bho', 'x'],
    ['Yantramanav', 'Yantramanav', "'Yantramanav'", 'Yantramanav', 'hi,mr,bho', 'x'],
    ['Amiko', 'Amiko', "'Amiko'", 'Amiko', 'hi,mr,bho', 'x'],
    ['Cambay', 'Cambay', "'Cambay'", 'Cambay', 'hi,mr,bho', 'x'],
    ['Sahitya', 'Sahitya', "'Sahitya'", 'Sahitya', 'hi,mr,bho', 'x'],
    ['Karma', 'Karma', "'Karma'", 'Karma', 'hi,mr,bho', 'x'],
    ['NotoSansGU', 'Noto Sans Gujarati', "'Noto Sans Gujarati'", 'Noto+Sans+Gujarati:wght@400;700', 'gu', 'x'],
    ['NotoSerifGU', 'Noto Serif Gujarati', "'Noto Serif Gujarati'", 'Noto+Serif+Gujarati:wght@400;700', 'gu', 'x'],
    ['HindVadodara', 'Hind Vadodara', "'Hind Vadodara'", 'Hind+Vadodara', 'gu', 'x'],
    ['BalooBhai2', 'Baloo Bhai 2', "'Baloo Bhai 2'", 'Baloo+Bhai+2', 'gu', 'x'],
    ['AnekGujarati', 'Anek Gujarati', "'Anek Gujarati'", 'Anek+Gujarati:wght@400;700', 'gu', 'x'],
    ['MuktaVaani', 'Mukta Vaani', "'Mukta Vaani'", 'Mukta+Vaani', 'gu', 'x'],
    ['Rasa', 'Rasa', "'Rasa'", 'Rasa:wght@400;700', 'gu', 'x'],
    ['Farsan', 'Farsan', "'Farsan'", 'Farsan', 'gu', 'd'],
    ['Shrikhand', 'Shrikhand', "'Shrikhand'", 'Shrikhand', 'gu', 'd'],
    ['KumarOne', 'Kumar One', "'Kumar One'", 'Kumar+One', 'gu', 'd'],
    ['NotoSansPA', 'Noto Sans Gurmukhi', "'Noto Sans Gurmukhi'", 'Noto+Sans+Gurmukhi:wght@400;700', 'pa', 'x'],
    ['NotoSerifPA', 'Noto Serif Gurmukhi', "'Noto Serif Gurmukhi'", 'Noto+Serif+Gurmukhi:wght@400;700', 'pa', 'x'],
    ['AnekGurmukhi', 'Anek Gurmukhi', "'Anek Gurmukhi'", 'Anek+Gurmukhi:wght@400;700', 'pa', 'x'],
    ['BalooPaaji2', 'Baloo Paaji 2', "'Baloo Paaji 2'", 'Baloo+Paaji+2', 'pa', 'x'],
    ['MuktaMahee', 'Mukta Mahee', "'Mukta Mahee'", 'Mukta+Mahee', 'pa', 'x'],
    ['Sarabun', 'Sarabun', "'Sarabun'", 'Sarabun', 'th', 'x'],
    ['NotoSansTH', 'Noto Sans Thai', "'Noto Sans Thai'", 'Noto+Sans+Thai:wght@400;700', 'th', 'x'],
    ['NotoSerifTH', 'Noto Serif Thai', "'Noto Serif Thai'", 'Noto+Serif+Thai:wght@400;700', 'th', 'x'],
    ['Prompt', 'Prompt', "'Prompt'", 'Prompt', 'th', 'x'],
    ['Kanit', 'Kanit', "'Kanit'", 'Kanit', 'th', 'x'],
    ['Niramit', 'Niramit', "'Niramit'", 'Niramit', 'th', 'x'],
    ['K2D', 'K2D', "'K2D'", 'K2D', 'th', 'x'],
    ['Krub', 'Krub', "'Krub'", 'Krub', 'th', 'x'],
    ['Mitr', 'Mitr', "'Mitr'", 'Mitr', 'th', 'x'],
    ['Pridi', 'Pridi', "'Pridi'", 'Pridi', 'th', 'x'],
    ['Taviraj', 'Taviraj', "'Taviraj'", 'Taviraj', 'th', 'x'],
    ['Trirong', 'Trirong', "'Trirong'", 'Trirong', 'th', 'x'],
    ['Mali', 'Mali', "'Mali'", 'Mali', 'th', 'x'],
    ['Athiti', 'Athiti', "'Athiti'", 'Athiti', 'th', 'x'],
    ['BaiJamjuree', 'Bai Jamjuree', "'Bai Jamjuree'", 'Bai+Jamjuree', 'th', 'x'],
    ['Maitree', 'Maitree', "'Maitree'", 'Maitree', 'th', 'x'],
    ['NotoNaskhAR', 'Noto Naskh Arabic', "'Noto Naskh Arabic'", 'Noto+Naskh+Arabic:wght@400;700', 'ar', 'x'],
    ['NotoSansAR', 'Noto Sans Arabic', "'Noto Sans Arabic'", 'Noto+Sans+Arabic:wght@400;700', 'ar', 'x'],
    ['NotoKufiAR', 'Noto Kufi Arabic', "'Noto Kufi Arabic'", 'Noto+Kufi+Arabic:wght@400;700', 'ar', 'x'],
    ['Amiri', 'Amiri', "'Amiri'", 'Amiri', 'ar', 'x'],
    ['Cairo', 'Cairo', "'Cairo'", 'Cairo:wght@400;700', 'ar', 'x'],
    ['Tajawal', 'Tajawal', "'Tajawal'", 'Tajawal', 'ar', 'x'],
    ['Almarai', 'Almarai', "'Almarai'", 'Almarai', 'ar', 'x'],
    ['Lateef', 'Lateef', "'Lateef'", 'Lateef', 'ar', 'x'],
    ['ScheherazadeNew', 'Scheherazade New', "'Scheherazade New'", 'Scheherazade+New', 'ar', 'x'],
    ['MarkaziText', 'Markazi Text', "'Markazi Text'", 'Markazi+Text:wght@400;700', 'ar', 'x'],
    ['ElMessiri', 'El Messiri', "'El Messiri'", 'El+Messiri:wght@400;700', 'ar', 'x'],
    ['Changa', 'Changa', "'Changa'", 'Changa:wght@400;700', 'ar', 'x'],
    ['Harmattan', 'Harmattan', "'Harmattan'", 'Harmattan', 'ar', 'x'],
    ['IBMPlexSansAR', 'IBM Plex Sans Arabic', "'IBM Plex Sans Arabic'", 'IBM+Plex+Sans+Arabic', 'ar', 'x'],
    ['ArefRuqaa', 'Aref Ruqaa', "'Aref Ruqaa'", 'Aref+Ruqaa', 'ar', 'x'],
    ['ReemKufi', 'Reem Kufi', "'Reem Kufi'", 'Reem+Kufi:wght@400;700', 'ar', 'x'],
    ['Cousine', 'Cousine', "'Cousine'", 'Cousine:wght@400;700', 'ru,en,de,fr,it,es,id,tl,tr', 'x'],
    ['PTMono', 'PT Mono', "'PT Mono'", 'PT+Mono', 'ru', 'x'],
    ['FiraMono', 'Fira Mono', "'Fira Mono'", 'Fira+Mono', 'ru', 'x'],
    ['IBMPlexMono', 'IBM Plex Mono', "'IBM Plex Mono'", 'IBM+Plex+Mono', 'ru', 'x'],
    ['PTSerif', 'PT Serif', "'PT Serif'", 'PT+Serif', 'ru', 'x'],
    ['PTSans', 'PT Sans', "'PT Sans'", 'PT+Sans', 'ru', 'x'],
    ['NotoSerifRU', 'Noto Serif', "'Noto Serif'", 'Noto+Serif:wght@400;700', 'ru', 'x'],
    ['NotoSansRU', 'Noto Sans', "'Noto Sans'", 'Noto+Sans:wght@400;700', 'ru', 'x'],
    ['SourceSans', 'Source Sans 3', "'Source Sans 3'", 'Source+Sans+3:wght@400;700', 'ru', 'x'],
    ['FiraSans', 'Fira Sans', "'Fira Sans'", 'Fira+Sans', 'ru', 'x'],
    ['NotoSansSC', 'Noto Sans SC', "'Noto Sans SC'", 'Noto+Sans+SC', 'zh', 'x'],
    ['NotoSerifSC', 'Noto Serif SC', "'Noto Serif SC'", 'Noto+Serif+SC', 'zh', 'x'],
    ['ZCOOLXiaoWei', 'ZCOOL XiaoWei', "'ZCOOL XiaoWei'", 'ZCOOL+XiaoWei', 'zh', 'x'],
    ['ZCOOLKuaiLe', 'ZCOOL KuaiLe', "'ZCOOL KuaiLe'", 'ZCOOL+KuaiLe', 'zh', 'd'],
    ['MaShanZheng', 'Ma Shan Zheng', "'Ma Shan Zheng'", 'Ma+Shan+Zheng', 'zh', 'x'],
    ['LongCang', 'Long Cang', "'Long Cang'", 'Long+Cang', 'zh', 'x'],
    ['NotoSansJP', 'Noto Sans JP', "'Noto Sans JP'", 'Noto+Sans+JP', 'ja', 'x'],
    ['NotoSerifJP', 'Noto Serif JP', "'Noto Serif JP'", 'Noto+Serif+JP', 'ja', 'x'],
    ['MPlus1p', 'M PLUS 1p', "'M PLUS 1p'", 'M+PLUS+1p', 'ja', 'x'],
    ['SawarabiMincho', 'Sawarabi Mincho', "'Sawarabi Mincho'", 'Sawarabi+Mincho', 'ja', 'x'],
    ['SawarabiGothic', 'Sawarabi Gothic', "'Sawarabi Gothic'", 'Sawarabi+Gothic', 'ja', 'x'],
    ['KosugiMaru', 'Kosugi Maru', "'Kosugi Maru'", 'Kosugi+Maru', 'ja', 'x'],
    ['ZenKakuGothicNew', 'Zen Kaku Gothic New', "'Zen Kaku Gothic New'", 'Zen+Kaku+Gothic+New', 'ja', 'x'],
    ['NotoSansKR', 'Noto Sans KR', "'Noto Sans KR'", 'Noto+Sans+KR', 'ko', 'x'],
    ['NotoSerifKR', 'Noto Serif KR', "'Noto Serif KR'", 'Noto+Serif+KR', 'ko', 'x'],
    ['NanumGothic', 'Nanum Gothic', "'Nanum Gothic'", 'Nanum+Gothic', 'ko', 'x'],
    ['NanumMyeongjo', 'Nanum Myeongjo', "'Nanum Myeongjo'", 'Nanum+Myeongjo', 'ko', 'x'],
    ['NanumGothicCoding', 'Nanum Gothic Coding', "'Nanum Gothic Coding'", 'Nanum+Gothic+Coding', 'ko', 'x'],
    ['GowunDodum', 'Gowun Dodum', "'Gowun Dodum'", 'Gowun+Dodum', 'ko', 'x'],
    ['GowunBatang', 'Gowun Batang', "'Gowun Batang'", 'Gowun+Batang', 'ko', 'x'],
    ['NotoSansTC', 'Noto Sans TC', "'Noto Sans TC'", 'Noto+Sans+TC', 'zh', 'x'],
    ['NotoSerifTC', 'Noto Serif TC', "'Noto Serif TC'", 'Noto+Serif+TC', 'zh', 'x'],
    ['ZCOOLQingKe', 'ZCOOL QingKe HuangYou', "'ZCOOL QingKe HuangYou'", 'ZCOOL+QingKe+HuangYou', 'zh', 'd'],
    ['ZhiMangXing', 'Zhi Mang Xing', "'Zhi Mang Xing'", 'Zhi+Mang+Xing', 'zh', 'd'],
    ['LiuJianMaoCao', 'Liu Jian Mao Cao', "'Liu Jian Mao Cao'", 'Liu+Jian+Mao+Cao', 'zh', 'd'],
    ['ZenOldMincho', 'Zen Old Mincho', "'Zen Old Mincho'", 'Zen+Old+Mincho', 'ja', 'x'],
    ['ShipporiMincho', 'Shippori Mincho', "'Shippori Mincho'", 'Shippori+Mincho', 'ja', 'x'],
    ['MPlusRounded', 'M PLUS Rounded 1c', "'M PLUS Rounded 1c'", 'M+PLUS+Rounded+1c', 'ja', 'x'],
    ['BIZUDPGothic', 'BIZ UDPGothic', "'BIZ UDPGothic'", 'BIZ+UDPGothic', 'ja', 'x'],
    ['BIZUDPMincho', 'BIZ UDPMincho', "'BIZ UDPMincho'", 'BIZ+UDPMincho', 'ja', 'x'],
    ['IBMPlexSansKR', 'IBM Plex Sans KR', "'IBM Plex Sans KR'", 'IBM+Plex+Sans+KR', 'ko', 'x'],
    ['Hahmlet', 'Hahmlet', "'Hahmlet'", 'Hahmlet', 'ko', 'x'],
    ['GothicA1', 'Gothic A1', "'Gothic A1'", 'Gothic+A1', 'ko', 'x'],
    ['SongMyung', 'Song Myung', "'Song Myung'", 'Song+Myung', 'ko', 'd'],
    ['System', 'System default', "system-ui,'Nirmala UI','Noto Sans Malayalam',sans-serif", '', 'all', 'b']
  ];
  THK.FONTS = FONT_ROWS.map(function (r) { return { id: r[0], label: r[1], stack: r[2], g: r[3], langs: r[4], type: r[5] }; });
  THK.lang = function (id) { return THK.LANGS.filter(function (l) { return l.id === id; })[0] || THK.LANGS[0]; };
  THK.defaultFont = function (lang) { return THK.lang(lang).def; };
  THK.fontsFor = function (lang, display) {
    return THK.FONTS.filter(function (f) {
      var ok = f.langs === 'all' || f.langs.split(',').indexOf(lang) >= 0;
      return ok && (display ? f.type !== 'b' : f.type !== 'd');
    });
  };
  THK.font = function (id) { return THK.FONTS.filter(function (x) { return x.id === id; })[0] || THK.FONTS[0]; };
  THK.fontStack = function (id) { return THK.font(id).stack + ",'Manjari','Meera',serif"; };
  THK.fontHref = function (f) { return 'https://fonts.googleapis.com/css2?family=' + f.g + '&display=swap'; };
  THK.fontLinkTags = function (ids) { // one small stylesheet per font, so one wrong name can never break the others
    var seen = {}, out = '';
    ids.forEach(function (id) { var f = id && THK.font(id); if (f && f.g && !seen[f.id]) { seen[f.id] = 1; out += '<link rel="stylesheet" href="' + THK.fontHref(f) + '">'; } });
    return out;
  };
  THK.loadFont = function (id) { // browser: add the stylesheet once (cached by the service worker for offline use)
    var f = THK.font(id); if (!f || !f.g || typeof document === 'undefined') return;
    var key = 'gf-' + f.id; if (document.getElementById(key)) return;
    var l = document.createElement('link'); l.id = key; l.rel = 'stylesheet'; l.href = THK.fontHref(f); document.head.appendChild(l);
  };
  THK.fontFaceCSS = function (base) {
    base = base || '';
    var f = function (fam, file, w, st) { return "@font-face{font-family:'" + fam + "';src:url('" + base + 'fonts/' + file + "') format('truetype');font-weight:" + w + ";font-style:" + (st || 'normal') + ";font-display:swap}"; };
    return f('Meera', 'Meera.ttf', 400) + f('Rachana', 'Rachana-Regular.ttf', 400) + f('Rachana', 'Rachana-Bold.ttf', 700) + f('Dyuthi', 'Dyuthi.ttf', 400) +
      f('Manjari Local', 'Manjari-Regular.ttf', 400) + f('Manjari Local', 'Manjari-Bold.ttf', 700) +
      f('Chilanka Local', 'Chilanka-Regular.ttf', 400) + f('Gayathri Local', 'Gayathri-Regular.ttf', 400) + f('Gayathri Local', 'Gayathri-Bold.ttf', 700) +
      f('Courier Prime Local', 'CourierPrime-Regular.ttf', 400) + f('Courier Prime Local', 'CourierPrime-Bold.ttf', 700) +
      f('Courier Prime Local', 'CourierPrime-Italic.ttf', 400, 'italic') + f('Courier Prime Local', 'CourierPrime-BoldItalic.ttf', 700, 'italic');
  };
  /* ---- rich text runs (bold / italic / underline / colour / size) -> HTML for the print engine ---- */
  THK.richHtml = function (text, runs, shift) {
    text = text || ''; runs = runs || []; shift = shift || 0;
    if (!runs.length) return esc(text);
    var pts = [0, text.length]; runs.forEach(function (r) { pts.push(r.s + shift, r.e + shift); });
    pts = pts.filter(function (p, i, a) { return p >= 0 && p <= text.length && a.indexOf(p) === i; }).sort(function (a, b) { return a - b; });
    var out = '';
    for (var i = 0; i < pts.length - 1; i++) {
      var p = pts[i], q = pts[i + 1], seg = esc(text.slice(p, q)), a = null;
      runs.forEach(function (r) { if (r.s + shift <= p && p < r.e + shift) a = r; });
      if (!a) { out += seg; continue; }
      var st = (a.b ? 'font-weight:700;' : '') + (a.i ? 'font-style:italic;' : '') + (a.u ? 'text-decoration:underline;' : '') + (a.c ? 'color:' + a.c + ';' : '') + (a.z ? 'font-size:' + a.z + 'pt;' : '');
      out += '<span style="' + st + '">' + seg + '</span>';
    }
    return out;
  };
  THK.todayStr = function () { var d = new Date(); return d.getDate() + ' ' + ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][d.getMonth()] + ' ' + d.getFullYear(); };


  /* ---- script analysis (breakdown, stats, contents page) ---- */
  var TOD = [
    ['day', /\b(day|morning|afternoon|noon|sunrise|dawn|daytime)\b|പകൽ|രാവിലെ|ഉച്ച|പുലർച്ചെ|പ്രഭാതം/i],
    ['night', /\b(night|midnight)\b|രാത്രി|അർദ്ധരാത്രി/i],
    ['evening', /\b(evening|dusk|sunset|twilight)\b|സന്ധ്യ|വൈകുന്നേരം|സായാഹ്നം/i]
  ];
  var TOD_STRIP = /\b(continuous|later|same time|day|morning|afternoon|noon|sunrise|dawn|daytime|night|midnight|evening|dusk|sunset|twilight)\b|പകൽ|രാവിലെ|ഉച്ച|പുലർച്ചെ|പ്രഭാതം|രാത്രി|അർദ്ധരാത്രി|സന്ധ്യ|വൈകുന്നേരം|സായാഹ്നം/ig;
  function cleanName(t) { return String(t || '').replace(/\(.*?\)/g, '').replace(/\b(CONT'?D\.?|V\.?O\.?|O\.?S\.?|O\.?C\.?)\b/ig, '').replace(/[:.\s]+$/, '').replace(/\s+/g, ' ').trim().toUpperCase(); }
  function wc(t) { t = String(t || '').trim(); return t ? t.split(/\s+/).length : 0; }
  function estLines(b) {
    var t = String(b.x || '') + (b.x2 ? ' ' + b.x2 : ''), ml = /[ഀ-ൿ]/.test(t), cpl = ({ action: 60, shot: 60, dial: 34, note: 0 })[b.t];
    if (cpl === 0) return 0; if (!cpl) return 2; if (ml) cpl = Math.round(cpl * 0.85);
    return Math.max(1, Math.ceil(t.length / cpl)) + (b.t === 'char' || b.t === 'paren' ? 0 : 1);
  }
  /* scene numbers some files carry inside the heading text ("12. INT. HOUSE", "INT. HOUSE - DAY   12", "#12#") – we number scenes ourselves */
  THK.stripSn = function (t) {
    t = String(t == null ? '' : t); var r = t.replace(/^\s*#?\d{1,4}[A-Z]?#?\s*[.)\-:]?\s*(?=(?:INT|EXT|I\s*\/\s*E|ഉൾ|പുറം))/i, '');
    r = r.replace(/(?:\t|\s{2,})#?\d{1,4}[A-Z]?#?\s*$/, '').replace(/\s+#\d{1,4}[A-Z]?#\s*$/, ''); return r;
  };
  THK.parseHeading = function (b) {
    var raw = THK.stripSn(String(b.x || '')).trim(), t2 = String(b.x2 || '').trim(), full = (raw + (t2 ? ' - ' + t2 : '')).trim();
    var m = /^\s*(INT\.?\s*\/\s*EXT\.?|EXT\.?\s*\/\s*INT\.?|I\s*\/\s*E|INT\.?|EXT\.?|ഉൾ|പുറം)\s*[.\-–—:]?\s*(.*)$/i.exec(raw), ie = '', rest = raw;
    if (m) { ie = /\//.test(m[1]) ? 'I/E' : (/^(INT|ഉൾ)/i.test(m[1]) ? 'INT' : 'EXT'); rest = m[2]; }
    var tod = 'other', todText = '';
    for (var i = 0; i < TOD.length; i++) { var mm = TOD[i][1].exec(full); if (mm) { tod = TOD[i][0]; todText = mm[0]; break; } }
    var loc = (t2 ? rest : rest).replace(TOD_STRIP, ' ').replace(/[\s\-–—.,:]+$/g, '').replace(/^[\s\-–—.,:]+/g, '').replace(/\s*[-–—]\s*[-–—]\s*/g, ' - ').replace(/\s+/g, ' ').trim();
    if (!loc) loc = rest.trim() || full;
    return { head: full || '(empty heading)', ie: ie, loc: loc, tod: tod, todText: todText };
  };
  THK.analyze = function (d) {
    var sc = [], cur = null, chars = {}, locs = {}, who = '', tot = { words: 0, dial: 0, action: 0, lines: 0 }, pre = { lines: 0 };
    (d.blocks || []).forEach(function (b) {
      var t = b.t, x = String(b.x || ''), w = wc(x) + wc(b.x2);
      if (t === 'scene') { var h = THK.parseHeading(b); cur = { n: sc.length + 1, id: b.id, head: h.head, ie: h.ie, loc: h.loc, tod: h.tod, todText: h.todText, chars: [], lines: 1, words: w, dial: 0, action: [], notes: 0 }; sc.push(cur); who = ''; tot.words += w; return; }
      var L = estLines(b); tot.lines += L; if (cur) cur.lines += L; else pre.lines += L;
      if (t === 'note') { if (cur) cur.notes++; return; }
      tot.words += w; if (cur) cur.words += w;
      if (t === 'char') { who = cleanName(x); if (who) { var c = chars[who] = chars[who] || { name: who, cues: 0, lines: 0, words: 0, scenes: {} }; c.cues++; if (cur) { c.scenes[cur.n] = 1; if (cur.chars.indexOf(who) < 0) cur.chars.push(who); } } return; }
      if (t === 'paren') return;
      if (t === 'dial') { tot.dial += w; if (cur) cur.dial += w; if (who && chars[who]) { chars[who].lines++; chars[who].words += w; } return; }
      who = ''; if (t === 'action' || t === 'shot') { tot.action += w; if (cur && x.trim()) cur.action.push(x.trim()); }
    });
    sc.forEach(function (s) { s.pages = s.lines / 54; var k = s.loc.toLowerCase(), l = locs[k] = locs[k] || { name: s.loc, ie: {}, scenes: [], day: 0, night: 0, evening: 0, other: 0, pages: 0 }; l.scenes.push(s.n); l[s.tod]++; l.pages += s.pages; if (s.ie) l.ie[s.ie] = 1; });
    var pages = Math.max(1, (tot.lines + pre.lines) / 54);
    return { scenes: sc, chars: Object.keys(chars).map(function (k) { var c = chars[k]; c.sceneList = Object.keys(c.scenes).map(Number); return c; }).sort(function (a, b) { return b.lines - a.lines || b.cues - a.cues; }), locs: Object.keys(locs).map(function (k) { return locs[k]; }).sort(function (a, b) { return b.scenes.length - a.scenes.length; }), words: tot.words, dialW: tot.dial, actW: tot.action, pages: pages, minutes: pages };
  };

  /* ---- typography ---- */
  THK.TYPO = { lh: 1.5, m: { t: 22, b: 20, l: 30, r: 20 }, el: { scene: { l: 0, r: 0, sb: 1 }, action: { l: 0, r: 0, sb: 0 }, char: { l: 60, r: 0, sb: 0.5 }, paren: { l: 48, r: 40, sb: 0 }, dial: { l: 26, r: 26, sb: 0 }, trans: { l: 0, r: 0, sb: 0.5 } } };
  THK.typoOf = function (d) {
    if (!d.typo) return null; var T = d.typo, D = THK.TYPO, o = { lh: T.lh || D.lh, m: Object.assign({}, D.m, d.fmt === 'two' ? { l: 20 } : {}, T.m || {}), el: {} };
    Object.keys(D.el).forEach(function (k) { o.el[k] = Object.assign({}, D.el[k], (T.el || {})[k] || {}); }); return o;
  };
  THK.typoPrintCss = function (d) {
    var T = THK.typoOf(d); if (!T || d.fmt === 'two') return '';
    var c = '';
    Object.keys(T.el).forEach(function (k) { var e = T.el[k]; c += 'main .b.' + k + '{margin-left:' + e.l + 'mm!important;margin-right:' + e.r + 'mm!important;max-width:none!important;margin-top:' + e.sb + 'em!important}'; });
    return c + 'main .b.char:not([class*="al-"]),main .b.paren:not([class*="al-"]){text-align:left}';
  };

  /* ---- headers and footers ---- */
  function cs(t) { return String(t == null ? '' : t).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\n/g, ' '); }
  THK.hfSlots = function (d) {
    var hf = d.hf || {}, s = {}; function add(k, p) { (s[k] = s[k] || []).push(p); }
    if (hf.title !== false) add('top-left', { t: d.title || 'Untitled' });
    if (d.hdr) add('top-right', { t: d.hdr });
    var pn = hf.pn || 'top-center'; if (pn !== 'off') add(pn, { n: 1 });
    if (hf.name && d.writer) add('bottom-left', { t: d.writer });
    if (hf.date) add('bottom-right', { t: hf.dateText || THK.todayStr() });
    if (hf.foot) add('bottom-center', { t: hf.foot });
    return s;
  };
  THK.hfCss = function (d, tc, ff) {
    var s = THK.hfSlots(d), pnf = (d.hf || {}).pnf || 'n', out = '';
    ['top-left', 'top-center', 'top-right', 'bottom-left', 'bottom-center', 'bottom-right'].forEach(function (k) {
      var parts = s[k]; if (!parts) return; var top = k.indexOf('top') === 0;
      var c = parts.map(function (p) { return p.n ? (pnf === 'page' ? "'Page ' counter(page)" : pnf === 'dot' ? "counter(page) '.'" : 'counter(page)') : "'" + cs(p.t) + "'"; }).join(" '  \\00B7  ' ");
      out += '@' + k + '{content:' + c + ';font:' + (parts.some(function (p) { return p.n; }) ? '8' : '7') + 'pt ' + ff + ';color:' + tc + ';opacity:.78;vertical-align:' + (top ? 'bottom' : 'top') + ';padding-' + (top ? 'bottom' : 'top') + ':4mm;white-space:nowrap}';
    });
    return out;
  };
  var NOBOX = '@top-left{content:none}@top-center{content:none}@top-right{content:none}@bottom-left{content:none}@bottom-center{content:none}@bottom-right{content:none}';

  THK.buildPrint = function (d, o) {
    o = o || {};
    var P = THK.paperOf(d), two = d.fmt === 'two', pwmm = parseFloat(P.w), ms = Math.min(1, pwmm / 210);
    var pc = d.pageColor || '#ffffff', tc = d.textColor || '#000000', fs = d.size || 12;
    var title = d.title || 'Untitled';
    var TY = THK.typoOf(d), mg = TY ? TY.m : { t: 22 * ms, r: 20 * ms, b: 20 * ms, l: (two ? 20 : 30) * ms }, ffs = THK.fontStack(d.font), acc = o.accent || tc;
    var snOn = o.sceneNos !== false, padL = snOn ? Math.max(3, Math.min(16, +mg.l - 1)) : 0, padR = snOn ? Math.max(3, Math.min(14, +mg.r - 1)) : 0;
    /* print engines clip anything drawn in the page margin, so the number columns are carved out of the margin and given back as padding on the script body */
    var pgL = +mg.l - padL, pgR = +mg.r - padR, snw = Math.max(2, padL - 2), snr = Math.max(2, padR - 2);
    var css = '@page{size:' + P.w + ' ' + P.h + ';background:' + pc + ';margin:' + (+mg.t).toFixed(1) + 'mm ' + pgR.toFixed(1) + 'mm ' + (+mg.b).toFixed(1) + 'mm ' + pgL.toFixed(1) + 'mm;' + THK.hfCss(d, tc, ffs) + '}' +
      (o.cover !== false ? '@page :first{counter-reset:page 0}' : '') + '@page cover{counter-reset:page 0;margin:20mm;background:' + pc + ';' + NOBOX + '}@page front{counter-reset:page 0;margin:20mm;background:' + pc + ';' + NOBOX + '}' + (THK.cv.hasLayers(d) && o.cover !== false ? THK.cv.layerPrintCss(d, NOBOX) : '') +
      '*{box-sizing:border-box}html,body{margin:0;padding:0;background:' + pc + ';color:' + tc + ';-webkit-print-color-adjust:exact;print-color-adjust:exact}' +
      'body{font-family:' + THK.fontStack(d.font) + ';font-size:' + fs + 'pt;line-height:' + (TY ? TY.lh : 1.5) + '}' +
      '.cover{page:cover;break-after:page;height:' + (parseFloat(P.h) - 41) + 'mm;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center}' +
      '.cover h1{font-family:' + THK.fontStack(d.titleFont || d.font) + ';font-size:' + (fs * 2.4) + 'pt;margin:0 0 14mm;font-weight:700;line-height:1.25;white-space:pre-wrap}' +
      '.cover p{margin:0 0 3mm;font-size:' + (fs * 1.1) + 'pt;white-space:pre-wrap}.cover b{font-weight:700}' +
      '.cover .lg{max-width:60mm;max-height:42mm;object-fit:contain;margin:0 0 10mm}' +
      '.cover.cv-left{align-items:flex-start;text-align:left;justify-content:flex-start;padding-top:48mm}.cover.cv-left h1{margin-bottom:12mm}' +
      '.cover.cv-bold h1{text-transform:uppercase;letter-spacing:.05em;font-size:' + (fs * 3.1) + 'pt;border-bottom:3pt solid ' + tc + ';padding-bottom:7mm;margin-bottom:12mm}' +
      '.cover.cv-minimal{align-items:flex-start;justify-content:flex-end;text-align:left}.cover.cv-minimal h1{font-size:' + (fs * 1.9) + 'pt;margin-bottom:8mm}' +
      '.cover.cv-framed{border:1.4pt solid ' + tc + ';padding:14mm;height:' + (parseFloat(P.h) - 43) + 'mm}.cover.cv-framed h1{border-bottom:.6pt solid ' + tc + ';padding-bottom:6mm}' +
      '.cover .cfoot{margin-top:auto;width:100%;display:flex;justify-content:space-between;align-items:flex-end;gap:10mm;text-align:left;font-size:' + (fs * 0.8) + 'pt;line-height:1.5}.cover .cfoot .r{text-align:right}.cover .cfoot p{font-size:inherit;margin:0}' +
      '.cover.has-foot{justify-content:flex-start;padding-top:44mm}.cover .bo{font-style:italic;margin-top:4mm}' +
      '.cover.cv-industry{justify-content:flex-start;padding-top:60mm}.cover.cv-industry h1{font-size:' + (fs * 2.1) + 'pt;margin-bottom:16mm;text-transform:uppercase;letter-spacing:.06em}' +
      '.cover.cv-modern{align-items:flex-start;text-align:left;justify-content:flex-end;border-left:4mm solid ' + acc + ';padding-left:12mm}.cover.cv-modern h1{font-size:' + (fs * 3) + 'pt;margin-bottom:10mm}.cover.cv-modern.has-foot{justify-content:flex-end;padding-top:0}' +
      '.cover.cvl-by .by{font-size:' + (fs * 0.85) + 'pt;opacity:.75;margin:0 0 1mm}.cover.cvl-by .nm{margin:0 0 7mm;font-size:' + (fs * 1.15) + 'pt}' + THK.cv.printCss({ H: parseFloat(P.h), fs: fs, tc: tc }) +
      '.toc{page:front;break-after:page;font-size:' + (fs * 0.95) + 'pt}.toc .tk{letter-spacing:.3em;font-size:' + (fs * 0.7) + 'pt;color:' + acc + ';font-weight:700}.toc h2{font-family:' + THK.fontStack(d.titleFont || d.font) + ';font-size:' + (fs * 1.9) + 'pt;margin:2mm 0 3mm;border-bottom:1.6pt solid ' + acc + ';padding-bottom:4mm}' +
      '.toc .sum{display:flex;gap:7mm;flex-wrap:wrap;margin:0 0 7mm;opacity:.85;font-size:' + (fs * 0.8) + 'pt}.toc .sum b{color:' + acc + '}.toc ol{list-style:none;margin:0;padding:0}.toc li{display:flex;gap:4mm;padding:1.6mm 0;border-bottom:.4pt solid rgba(128,128,128,.35);break-inside:avoid;align-items:baseline}.toc li .n{flex:0 0 9mm;color:' + acc + ';font-weight:700}.toc li .h{flex:1;text-transform:uppercase}.toc li .m{opacity:.65;font-size:' + (fs * 0.75) + 'pt;white-space:nowrap}' +
      (d.wm ? '.wmk{position:fixed;left:0;top:0;width:100%;height:100%;display:flex;align-items:center;justify-content:center;pointer-events:none;z-index:9}.wmk span{transform:rotate(-35deg);white-space:nowrap;font:700 ' + Math.max(20, Math.min(120, 1100 / Math.max(3, String(d.wm).length) * (pwmm / 210))).toFixed(0) + 'pt Arial,Helvetica,sans-serif;color:rgba(128,128,128,.17)}' : '') +
      '.body{counter-reset:page 0' + (snOn ? ';padding:0 ' + padR.toFixed(1) + 'mm 0 ' + padL.toFixed(1) + 'mm' : '') + '}' +
      '.b{margin:0 0 ' + (fs * 0.9) + 'pt;white-space:pre-wrap;word-wrap:break-word;orphans:2;widows:2;break-inside:avoid-page}' +
      '.b.pb{break-before:page}.b.scene{position:relative}.sn{position:absolute;top:0;width:' + snw.toFixed(1) + 'mm;left:-' + (snw + 2).toFixed(1) + 'mm;text-align:right;font-weight:700;font-size:.9em;text-transform:none;letter-spacing:0;white-space:nowrap}.sn.r{left:auto;right:-' + (snr + 2).toFixed(1) + 'mm;width:' + snr.toFixed(1) + 'mm;text-align:left}.b.scene,.b.char,.b.paren,.b.trans{font-weight:700}.b.scene{margin-top:' + fs + 'pt;break-after:avoid}.b.char,.b.paren{break-after:avoid;margin-bottom:' + (fs * 0.15) + 'pt}' +
      '.b.note{display:none}';
    if (!two) css += '.b.char,.b.paren{text-align:center;margin-left:15%;margin-right:15%}.b.dial{margin-left:16%;margin-right:16%}.b.trans{text-align:right}.b.scene{text-transform:uppercase}';
    else css += '.b.scene{display:flex;gap:0}.b.scene .l{flex:0 0 50%;text-transform:uppercase}.b.scene .r{flex:1;text-transform:uppercase}' +
      '.b.action,.b.shot,.b.scene,.b.trans,.b.note{clear:both}.b.action,.b.shot{width:46%}.b.char{float:left;clear:both;width:50%;margin:0;padding-right:1.2mm;text-align:right}.b.paren,.b.dial{margin-left:calc(50% + 3mm);text-align:left}.b.trans{text-align:center}';
    css += (THK.el ? THK.el.css(d, 'pr') : '') + THK.typoPrintCss(d) + '.al-left{text-align:left!important}.al-center{text-align:center!important}.al-right{text-align:right!important}.al-justify{text-align:justify!important}';
    if (o.marks) css += '.b.mk{background:var(--mk);}';
    var h = d.wm ? '<div class="wmk"><span>' + esc(String(d.wm)) + '</span></div>' : '';
    if (o.cover !== false && THK.cv.hasLayers(d)) h += THK.cv.sectionHtml(d);
    else if (o.cover !== false) {
      var cf = d.cfm || {};
      var hasFoot = !!(d.contact || d.draft), ind = THK.cv.opts(d).lbl === 'by', cvo = THK.cv.opts(d), dateTxt = d.date ? THK.richHtml(d.date, cf.date) : esc(THK.todayStr());
      h += '<section class="cover ' + THK.cv.classes(d) + (ind ? ' cvl-by' : '') + (hasFoot ? ' has-foot' : '') + '" style="' + THK.cv.vars(d, acc) + '">' + (d.logo ? '<img class="lg" src="' + d.logo + '" alt="">' : '') + '<h1>' + THK.richHtml(d.title || 'Untitled', cf.title) + '</h1>';
      if (ind) h += '<p class="by">Written by</p><p class="nm">' + THK.richHtml(d.writer || '', cf.writer) + '</p>' + (d.director ? '<p class="by">Directed by</p><p class="nm">' + THK.richHtml(d.director, cf.director) + '</p>' : '');
      else h += '<p><b>Writer :</b> ' + THK.richHtml(d.writer || '', cf.writer) + '</p><p><b>Director :</b> ' + THK.richHtml(d.director || '', cf.director) + '</p>' + (hasFoot ? '' : '<p><b>Date :</b> ' + dateTxt + '</p>');
      if (d.basedOn) h += '<p class="bo">' + esc(d.basedOn) + '</p>';
      if (hasFoot) h += '<div class="cfoot"><div class="l"><p>' + esc(d.contact || '').replace(/\n/g, '<br>') + '</p></div><div class="r"><p>' + (d.draft ? esc(d.draft) + '<br>' : '') + dateTxt + '</p></div></div>';
      h += '</section>';
    }
    if (o.toc) {
      var A = THK.analyze(d);
      h += '<section class="toc"><div class="tk">CONTENTS</div><h2>' + esc(d.title || 'Untitled') + '</h2><div class="sum"><span><b>' + A.scenes.length + '</b> scenes</span><span><b>' + A.locs.length + '</b> locations</span><span><b>' + A.chars.length + '</b> characters</span><span>about <b>' + Math.max(1, Math.round(A.pages)) + '</b> pages · <b>' + Math.max(1, Math.round(A.minutes)) + '</b> min</span></div><ol>' +
        A.scenes.map(function (s) { return '<li><span class="n">' + s.n + '</span><span class="h">' + esc(s.head) + '</span><span class="m">' + (s.tod !== 'other' ? s.tod : '') + (s.chars.length ? ' · ' + s.chars.length + ' ch' : '') + '</span></li>'; }).join('') + '</ol></section>';
    }
    if (o.payload !== false && THK.pdfPayload) h += '<a class="fnx" href="' + THK.pdfPayload(d) + '" style="position:absolute;left:0;top:0;display:block;width:2px;height:2px;overflow:hidden" aria-hidden="true" tabindex="-1"></a>';
    h += '<main class="body">';
    var sn = 0;
    d.blocks.forEach(function (b) {
      if (b.t === 'scene') sn++;
      var x = b.x || '', cls = 'b ' + b.t + (b.al ? ' al-' + b.al : '') + (b.pb ? ' pb' : '') + (o.marks && b.mk ? ' mk' : '');
      var st = o.marks && b.mk ? ' style="--mk:' + esc(b.mk) + '"' : '';
      if (!x.trim() && !(b.x2 || '').trim()) { if (b.pb) h += '<div class="b pb"' + st + '></div>'; return; }
      var fm = b.fm || {}, rx = THK.richHtml, X1 = '', X2 = '';
      if (b.t === 'scene' && snOn && !(fm.x && fm.x.length)) x = THK.stripSn(x);
      if (b.t === 'paren') x = '(' + x.replace(/^\(|\)$/g, '') + ')';
      var xh = b.t === 'paren' ? rx(x, fm.x, 1) : rx(x, fm.x) + (b.t === 'char' && two ? ' :' : '');
      var sl = b.t === 'scene' && snOn ? '<span class="sn">' + sn + '</span>' : '', sr = b.t === 'scene' && snOn ? '<span class="sn r">' + sn + '</span>' : '';
      if (b.t === 'scene' && two) h += '<div class="' + cls + '"' + st + '>' + sl + '<div class="l">' + xh + '</div><div class="r">' + rx(b.x2 || '', fm.x2) + '</div>' + sr + '</div>';
      else h += '<div class="' + cls + '"' + st + '>' + sl + xh + sr + '</div>';
    });
    h += '</main>';
    return { css: css, html: h };
  };

  THK.printDoc = function (d, o) {
    var p = THK.buildPrint(d, o);
    var base = (typeof location !== 'undefined' && /^(https?|file):/.test(location.href)) ? location.href.replace(/[#?].*$/, '').replace(/[^\/]*$/, '') : '';
    return '<!doctype html><html><head><meta charset="utf-8">' + (base ? '<base href="' + base + '">' : '') + '<title>' + esc(d.title || 'script') + '</title>' +
      '<link rel="stylesheet" href="fonts/fonts.css">' + THK.fontLinkTags([d.font, d.titleFont].concat(THK.cv.fontsOf(d))) + '<style>' + THK.fontFaceCSS('') + p.css + '</style></head><body' + (THK.lang(d.lang).rtl ? ' dir="rtl"' : '') + ' lang="' + (THK.lang(d.lang).bcp || 'en') + '">' + p.html + '</body></html>';
  };

  THK.fp = function () { // native Android helper (print to PDF + save dialog); null on web / desktop
    var C = window.Capacitor; if (!C) return null;
    if (C.Plugins && C.Plugins.FinnishPrint) return C.Plugins.FinnishPrint;
    if (typeof C.nativePromise === 'function') return {
      print: function (o) { return C.nativePromise('FinnishPrint', 'print', o); },
      saveFile: function (o) { return C.nativePromise('FinnishPrint', 'saveFile', o); },
      getPending: function (o) { return C.nativePromise('FinnishPrint', 'getPending', o || {}); }
    };
    if (typeof C.registerPlugin === 'function') { if (!THK._fp) THK._fp = C.registerPlugin('FinnishPrint'); return THK._fp; }
    return null;
  };
  THK.shell = function (d, css, body, fonts) {
    var base = (typeof location !== 'undefined' && /^(https?|file):/.test(location.href)) ? location.href.replace(/[#?].*$/, '').replace(/[^\/]*$/, '') : '';
    return '<!doctype html><html><head><meta charset="utf-8">' + (base ? '<base href="' + base + '">' : '') + '<title>' + esc(d.title || 'script') + '</title>' +
      '<link rel="stylesheet" href="fonts/fonts.css">' + THK.fontLinkTags(fonts || [d.font, d.titleFont]) + '<style>' + THK.fontFaceCSS('') + css + '</style></head><body' + (THK.lang(d.lang).rtl ? ' dir="rtl"' : '') + ' lang="' + (THK.lang(d.lang).bcp || 'en') + '">' + body + '</body></html>';
  };
  THK.printRaw = function (html, d, base) {
    var name = (base || d.title || 'script').replace(/[\\\/:*?"<>|\n]+/g, ' ').trim() || 'script';
    var N = window.finnishNative, FP = THK.fp();
    if (N && N.savePdf) return N.savePdf(html, name + '.pdf', THK.paperOf(d).n);
    if (FP) return FP.print({ html: html, name: name, paper: d.paper, wmm: parseFloat(THK.paperOf(d).w), hmm: parseFloat(THK.paperOf(d).h) }).catch(function (err) { alert('PDF export failed: ' + (err && err.message || err)); });
    return new Promise(function (res) {
      var f = document.createElement('iframe');
      f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0';
      f.onload = function () {
        var w = f.contentWindow, go = function () { setTimeout(function () { try { w.focus(); w.print(); } catch (e) { } setTimeout(function () { f.remove(); res(); }, 1500); }, 250); };
        var fonts = (f.contentDocument && f.contentDocument.fonts);
        if (fonts && fonts.ready) Promise.race([fonts.ready, new Promise(function (r) { setTimeout(r, 3000); })]).then(go); else go();
      };
      f.srcdoc = html; document.body.appendChild(f);
    });
  };
  THK.printScript = function (d, o) { return THK.printRaw(THK.printDoc(d, o), d); };
})();
