/* Old-font PDF reader. Many Malayalam screenplay PDFs were typed with 8-bit "ML-TT" fonts (Karthika / Revathi / Indulekha …) whose letters are stored as
   English-looking codes, and some PDFs lose conjunct letters when they are made. This file reads the raw glyph codes from the PDF's drawing
   operations and turns them into real Unicode, using per-font tables. A code the tables do not know is marked □ (never guessed). */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {};

  /* ---------------------------------------------------------------- tables */
  var ALPHA = 'കഖഗഘങചഛജഝഞടഠഡഢണതഥദധനപഫബഭമയരറലളഴവശഷസഹ';
  var BASE = {};
  (function () {
    var i, c;
    for (i = 0; i < ALPHA.length; i++) BASE[73 + i] = ALPHA.charAt(i);
    var v = { 65: 'അ', 66: 'ആ', 67: 'ഇ', 68: 'ഉ', 69: 'ഊ', 70: 'എ', 71: 'ഏ', 72: 'ഒ', 109: 'ാ', 110: 'ി', 111: 'ീ', 112: 'ു', 113: 'ൂ', 114: 'ൃ', 117: 'ൗ', 118: '്', 119: 'ം', 120: 'ഃ',
      46: '.', 58: ':', 44: ',', 40: '(', 41: ')', 33: '!', 63: '?', 34: '"', 39: "'", 47: '/', 43: '+', 59: ';', 37: '%', 45: '', 32: ' ', 3: ' ', 42: '*', 35: '#', 38: '&', 61: '=', 62: '>', 60: '<', 64: '@' };
    for (c in v) BASE[c] = v[c];
    for (i = 48; i < 58; i++) BASE[i] = String.fromCharCode(i);
  })();
  function mk(extra) { var o = {}, k; for (k in BASE) o[k] = BASE[k]; for (k in extra) o[k] = extra[k]; return o; }

  /* Karthika (Type 1 "ML-Karthika" / "MLB-Karthika"): the PDF's own code numbers change from file to file, but the glyph NAMES (read by pdf.js as the character
     in the 'unicode' field) are part of the font, so this table is keyed by that character */
  var KAR_N = {937: 'മ്മ', 8486: 'മ്മ', 916: 'വ്വ', 8710: 'വ്വ', 181: 'ന്ദ', 956: 'ന്ദ', 8211: 'ബ്ദ', "198": "ണ്ണ", "176": "ക്ക", "8706": "ന്ന", "172": "ൽ", "223": "ങ്ങ", "8800": "ണ്ട", "121": "്യ", "122": "്വ", "8776": "ള്ള", "216": "ത്ത", "402": "ൾ", "174": "ച്ച", "8218": "ന്റ", "8805": "ൻ", "186": "മ്പ", "177": "ദ്ദ", "191": "ർ", "8719": "പ്പ", "248": "യ്യ", "195": "സ്റ്റ", "180": "ട്ട", "8240": "റ്റ", "165": "ന്ത", "170": "ബ്ല", "163": "ക്ഷ", "8482": "ഞ്ഞ", "8486": "മ്മ", "8730": "ല്ല", "960": "പ്ല", "160": "സ്സ", "8226": "ഗ്ല", "168": "ൺ", "731": "–", "8804": "ദ്ധ", "8747": "ബ്ബ", "182": "ങ്ക", "8710": "വ്വ", "169": "ഞ്ച", "187": "ശ്ശ", "255": "സ്ഥ", "8721": "ന്മ", "8212": "ച്ഛ"};
  var KAR_B = {937: 'മ്മ', 8486: 'മ്മ', 174: 'ച്ച', 182: 'ങ്ക', 8747: 'ബ്ബ', 8804: 'ദ്ധ', 8706: 'ന്ന', 8211: 'ബ്ദ', "8805": "ൻ", "731": "–", "8226": "ഗ്ല", "172": "ൽ", "8719": "പ്പ", "176": "ക്ക", "8776": "ള്ള", "8218": "ന്റ", "186": "മ്പ", "402": "ൾ", "8240": "റ്റ", "180": "ട്ട", "8482": "ഞ്ഞ", "191": "ർ", "195": "സ്റ്റ", "160": "സ്സ", "216": "ത്ത", "169": "ഞ്ച", "168": "ൺ"};
  /* ML-TT family: Indulekha, Revathi, Karthika-TT and the unnamed CID copies used by Mission / Nettottam */
  var TT = { 172: 'ൺ', 180: 'ന്ത', 191: 'യ്യ', 174: 'ണ്ണ', 216: 'സ്ഥ', 165: 'ഗ്ല', 213: 'ത്സ', 205: 'ഡ്ഡ', 121: '്യ', 122: '്വ', 161: 'ക്ക', 162: 'ക്ല', 163: 'ക്ഷ', 166: 'ങ്ക', 167: 'ങ്ങ', 168: 'ച്ച', 169: 'ഞ്ച', 170: 'ഞ്ഞ', 171: 'ട്ട', 173: 'ണ്ട', 175: 'ത്ത', 177: 'ദ്ദ', 178: 'ദ്ധ', 179: 'ൻ', 181: 'ന്ദ', 182: 'ന്ന', 183: 'ന്മ', 184: 'പ്പ', 185: 'പ്ല', 186: 'ബ്ബ', 187: 'ബ്ല', 188: 'മ്പ', 189: 'മ്മ', 192: 'ർ', 194: 'ൽ', 195: 'ല്ല', 196: 'ൾ', 197: 'ള്ള', 198: 'ണ്ണ', 202: 'സ്സ', 204: 'സ്റ്റ', 209: 'ച്ഛ', 212: 'ഡ്ഡ', 214: 'ജ്ജ', 218: 'ജ്ഞ', 221: 'ശ്ച', 224: 'ക്ത', 225: 'ഗ്ന', 226: 'ന്റ', 228: 'റ്റ', 254: '–', 145: '‘', 146: '’', 147: '“', 148: '”', 150: '–' };
  var TABLES = { karN: mk(KAR_N), karB: mk(KAR_B), tt: mk(TT) };
  /* Windows-1252 bytes 0x80–0x9F come out of pdf.js as Unicode punctuation; map them back to the byte they were */
  var CP = { 8364: 128, 8218: 130, 402: 131, 8222: 132, 8230: 133, 8224: 134, 8225: 135, 710: 136, 8240: 137, 352: 138, 8249: 139, 338: 140, 381: 142, 8216: 145, 8217: 146, 8220: 147, 8221: 148, 8226: 149, 8211: 150, 8212: 151, 732: 152, 8482: 153, 353: 154, 8250: 155, 339: 156, 382: 158, 376: 159 };
  function byteOf(ch) { var n = ch.charCodeAt(0); return CP[n] || n; }

  /* Nirmala UI: letters the PDF forgot to name (glyph numbers are stable for this font) */
  var NIRMALA = {"1435": "ം", "1437": "അ", "1438": "ആ", "1439": "ഇ", "1440": "ഈ", "1441": "ഉ", "1442": "ഊ", "1445": "എ", "1446": "ഏ", "1447": "ഐ", "1448": "ഒ", "1449": "ഓ", "1450": "ഔ", "1451": "ക", "1452": "ഖ", "1453": "ഗ", "1454": "ഘ", "1455": "ങ", "1456": "ച", "1457": "ഛ", "1458": "ജ", "1460": "ഞ", "1461": "ട", "1462": "ഠ", "1463": "ഡ", "1465": "ണ", "1466": "ത", "1467": "ഥ", "1468": "ദ", "1469": "ധ", "1470": "ന", "1472": "പ", "1473": "ഫ", "1474": "ബ", "1475": "ഭ", "1476": "മ", "1477": "യ", "1478": "ര", "1479": "റ", "1480": "ല", "1481": "ള", "1482": "ഴ", "1483": "വ", "1484": "ശ", "1485": "ഷ", "1486": "സ", "1487": "ഹ", "1490": "ാ", "1491": "ി", "1492": "ീ", "1493": "ു", "1495": "ൂ", "1497": "ൃ", "1499": "െ", "1500": "േ", "1501": "ൈ", "1505": "്", "1508": "ൗ", "1513": "ൺ", "1514": "ൻ", "1515": "ർ", "1516": "ൽ", "1517": "ൾ", "1519": "ക്ക", "1522": "ക്ഷ", "1528": "ങ്ക", "1529": "ങ്ങ", "1530": "ച്ച", "1531": "ച്ഛ", "1537": "ഞ്ഞ", "1538": "ട്ട", "1541": "ഡ്ഡ", "1543": "ണ്ട", "1545": "ണ്ണ", "1547": "ത്ത", "1552": "ദ്ദ", "1553": "ദ്ധ", "1555": "ന്ത", "1557": "ന്ദ", "1558": "ഡ്ഡ", "1559": "ന്ന", "1561": "ന്റ", "1562": "പ്പ", "1564": "ഫ്ല", "1565": "ബ്ദ", "1570": "മ്പ", "1571": "മ്മ", "1573": "യ്യ", "1574": "റ്റ", "1576": "ല്ല", "1578": "ള്ള", "1581": "ശ്ച", "1584": "ഷ്ട", "1586": "സ്റ്റ", "1588": "സ്സ", "1593": "ക്ട", "1613": "ശ", "1615": "സ", "1617": "്യ", "1618": "\uE000", "1620": "്വ", "1629": "്ത", "1632": "്ന", "4419": "യ"};   /* every glyph number of Nirmala UI seen in screenplays: the real text, also used to correct PDFs whose own text map is wrong */
  /* PDFs that store conjuncts as unnamed glyphs inside the embedded font (codes are small numbers) */
  var LOSTFONT = {
    anjali: { 16: 'ക്ക', 19: 'ണ്ണ', 23: 'ട്ട', 6: 'ങ്ങ', 7: 'ൾ', 21: 'മ്മ', 5: 'ത്ര' },
    tt275: { 19: 'ന്ന', 28: 'ക്ക', 20: 'ൽ', 9: '്യ' }
  };

  /* ---------------------------------------------------------------- converting a run of old-font codes */
  function conv(codes, T) {
    var out = '', i = 0, n = codes.length;
    function isCons(c) { var v = T[c]; if (!v) return false; var a = v.charCodeAt(0), z = v.charAt(v.length - 1); return a >= 0x0D15 && a <= 0x0D3A && 'ാിീുൂൃൗ്ംഃ'.indexOf(z) < 0; }
    function post(c) { var v = T[c]; return v && v.length > 1 && v.charAt(0) === '്'; }
    function u(c) { var v = T[c]; return v === undefined ? '□' : v; }
    while (i < n) {
      var c = codes[i];
      if (c === 123) {                                   /* ് ര written before its letter */
        if (i + 1 < n && isCons(codes[i + 1])) { out += u(codes[i + 1]) + '്ര'; i += 2; continue; }
        out += '്ര'; i++; continue;
      }
      if (c === 115 || c === 116) {                      /* െ േ ൈ are typed before their letter */
        var pre = c === 115 ? 'െ' : 'േ', j = i + 1;
        if (c === 115 && j < n && codes[j] === 115) { pre = 'ൈ'; j++; }
        if (j < n && isCons(codes[j])) {
          var cl = u(codes[j]); j++;
          for (;;) {
            if (j + 1 < n && codes[j] === 118 && isCons(codes[j + 1])) { cl += '്' + u(codes[j + 1]); j += 2; }
            else if (j < n && (post(codes[j]) || codes[j] === 123)) { cl += codes[j] === 123 ? '്ര' : u(codes[j]); j++; }
            else break;
          }
          var sign = pre;
          if (j < n && codes[j] === 109 && pre !== 'ൈ' && pre) { sign = pre === 'െ' ? 'ൊ' : 'ോ'; j++; }
          else if (j < n && codes[j] === 117 && pre === 'െ') { sign = 'ൌ'; j++; }
          out += cl + sign; i = j; continue;
        }
        out += pre; i = j; continue;
      }
      out += u(c); i++;
    }
    return out;
  }
  THK.legacyConv = conv;

  var NAME_KAR_B = /(?:^|\+)ML-Karthika.*Bold/i, NAME_KAR = /(?:^|\+)ML-Karthika/i, NAME_TT = /(?:^|\+)ML-?TT/i;
  var LEGCH = /[¡-¿À-ÿ]/g;
  function kindByName(n) {
    if (NAME_KAR_B.test(n)) return 'karB';
    if (NAME_KAR.test(n)) return 'karN';
    if (NAME_TT.test(n)) return 'tt';
    return '';
  }

  /* ---------------------------------------------------------------- raw glyphs from the drawing operations */
  function glyphs(m, page) {
    var O = m.OPS, names = {}, out = [];
    var ctm = [1, 0, 0, 1, 0, 0], stack = [], tm = [1, 0, 0, 1, 0, 0], tlm = [1, 0, 0, 1, 0, 0], fs = 0, fname = '', cs = 0, ws = 0, hs = 1, lead = 0, rise = 0;
    function mul(a, b) { return [a[0] * b[0] + a[1] * b[2], a[0] * b[1] + a[1] * b[3], a[2] * b[0] + a[3] * b[2], a[2] * b[1] + a[3] * b[3], a[4] * b[0] + a[5] * b[2] + b[4], a[4] * b[1] + a[5] * b[3] + b[5]]; }
    function fontName(k) {
      if (names[k] !== undefined) return Promise.resolve(names[k]);
      return new Promise(function (rs) { var done = false, t = setTimeout(function () { if (!done) { done = true; rs(''); } }, 4000); try { page.commonObjs.get(k, function (o) { if (done) return; done = true; clearTimeout(t); rs((o && o.name) || ''); }); } catch (e) { clearTimeout(t); rs(''); } }).then(function (n) { names[k] = n; return n; });
    }
    function move(x, y) { tlm = [tlm[0], tlm[1], tlm[2], tlm[3], x * tlm[0] + y * tlm[2] + tlm[4], x * tlm[1] + y * tlm[3] + tlm[5]]; tm = tlm.slice(); }
    function show(gl) {
      for (var i = 0; i < gl.length; i++) {
        var g = gl[i];
        if (typeof g === 'number') { var tx = -g / 1000 * fs * hs; tm = [tm[0], tm[1], tm[2], tm[3], tm[4] + tx * tm[0], tm[5] + tx * tm[1]]; continue; }
        if (!g) continue;
        var f = mul(mul([fs * hs, 0, 0, fs, 0, rise], tm), ctm), w = (g.width || 0) / 1000, sc = Math.hypot(f[0], f[1]) / (hs || 1);
        out.push({ f: fname, c: g.originalCharCode, u: g.unicode || '', x: f[4], y: f[5], sz: Math.hypot(f[2], f[3]), adv: w * sc, rot: Math.abs(f[1]) > 0.3 * Math.hypot(f[2], f[3]) });
        var t = (w * fs + cs + (g.isSpace || g.unicode === ' ' ? ws : 0)) * hs;
        tm = [tm[0], tm[1], tm[2], tm[3], tm[4] + t * tm[0], tm[5] + t * tm[1]];
      }
    }
    return page.getOperatorList().then(function (ol) {
      var p = Promise.resolve();
      ol.fnArray.forEach(function (fn, i) {
        var a = ol.argsArray[i];
        p = p.then(function () {
          switch (fn) {
            case O.save: stack.push(ctm.slice()); break;
            case O.restore: if (stack.length) ctm = stack.pop(); break;
            case O.transform: ctm = mul([a[0], a[1], a[2], a[3], a[4], a[5]], ctm); break;
            case O.beginText: tm = [1, 0, 0, 1, 0, 0]; tlm = [1, 0, 0, 1, 0, 0]; break;
            case O.setFont: fs = a[1]; return fontName(a[0]).then(function (n) { fname = n; });
            case O.setCharSpacing: cs = a[0]; break;
            case O.setWordSpacing: ws = a[0]; break;
            case O.setHScale: hs = a[0] / 100; break;
            case O.setLeading: lead = a[0]; break;
            case O.setTextRise: rise = a[0]; break;
            case O.moveText: move(a[0], a[1]); break;
            case O.setLeadingMoveText: lead = -a[1]; move(a[0], a[1]); break;
            case O.setTextMatrix: { var M = a[0] && a[0].length ? a[0] : a; tm = [M[0], M[1], M[2], M[3], M[4], M[5]]; tlm = tm.slice(); break; }
            case O.nextLine: move(0, -lead); break;
            case O.showText: case O.showSpacedText: show(a[0]); break;
            case O.nextLineShowText: move(0, -lead); show(a[0]); break;
            case O.nextLineSetSpacingShowText: ws = a[0]; cs = a[1]; move(0, -lead); show(a[2]); break;
          }
        });
      });
      return p.then(function () { return out; });
    });
  }
  THK._pdfGlyphs = glyphs;

  /* ---------------------------------------------------------------- which fonts are old-style (needs the whole document's glyphs) */
  function classifyFonts(all) {
    var st = {}, kinds = {};
    all.forEach(function (g) { var s = st[g.f] || (st[g.f] = { n: 0, leg: 0, hi: 0, txt: 0 }); s.n++; if (g.u) { s.txt++; if (LEGCH.test(g.u)) s.leg++; LEGCH.lastIndex = 0; } });
    Object.keys(st).forEach(function (f) {
      var k = kindByName(f), s = st[f];
      if (!k && /^(?:\w+\+)?CIDFont\+?F\d|^CIDFont\+F\d/.test(f) && s.n > 300 && s.leg / Math.max(1, s.txt) > 0.05) k = 'tt';   /* unnamed copies of an ML-TT font */
      kinds[f] = k;
    });
    return kinds;
  }
  function lostTable(fname) {
    if (/^(?:\w+\+)?Nirmala ?UI/i.test(fname)) return NIRMALA;
    if (/AnjaliOldLipi/i.test(fname)) return LOSTFONT.anjali;
    if (/TT275t00/i.test(fname)) return LOSTFONT.tt275;
    return null;
  }
  function isLost(u) { return !u || /[\u0000-\u0008\u000B-\u001F�]/.test(u); }

  /* turns all glyphs of one page into text items like pdf.js's own getTextContent (so the normal row builder can use them) */
  function pageItems(gl, kinds, stats) {
    var items = [], cur = null;
    function flush() {
      if (!cur) return;
      var s;
      if (cur.k) {
        s = conv(cur.codes, TABLES[cur.k]);
        if (/□/.test(s)) stats.unknown += (s.match(/□/g) || []).length;
        stats.converted += cur.codes.length;
      } else {
        s = cur.s.replace(/\uE000((?:[ക-ഹ]്)*[ക-ഹ])/g, '$1്ര').replace(/\uE000/g, '□');
        if (/Nirmala ?UI/i.test(cur.f)) s = s.replace(/([െേൈ])((?:[ക-ഹ]്)*[ക-ഹ](?:്ര|്യ|്വ)*)/g, '$2$1').replace(/ൊ/g, 'ൊ').replace(/ോ/g, 'ോ');   /* signs drawn left of their letters go behind them */
      }
      items.push({ str: s, transform: [cur.sz, 0, 0, cur.sz, cur.x0, cur.y], width: Math.max(0, cur.x1 - cur.x0), height: cur.sz });
      cur = null;
    }
    gl.forEach(function (g) {
      if (g.rot) { flush(); return; }
      var k = kinds[g.f] || '', code, s;
      if (k) {
        code = g.u && !/[\u0000-\u001F]/.test(g.u) && (k !== 'tt' || /CIDFont/.test(g.f)) ? (k === 'tt' ? byteOf(g.u.charAt(0)) : g.u.charCodeAt(0)) : g.c;
        if (code === undefined) return;
      } else {
        var nt = /Nirmala ?UI/i.test(g.f) && g.c >= 1400 ? NIRMALA[g.c] : undefined;
        if (g.c === 3 && /^[\u200c\u200d]*$/.test(g.u || '')) s = ' ';
        else if (nt !== undefined) { s = nt; if (isLost(g.u)) stats.filled++; else if (nt !== g.u) stats.fixed = (stats.fixed || 0) + 1; }
        else if (isLost(g.u)) {
          var t = lostTable(g.f), v = t && t[g.c];
          if (g.u === ' ' || g.c === 3 && !t) s = ' '; else if (v !== undefined) { s = v; stats.filled++; } else { s = '□'; stats.unknown++; }
        } else s = g.u;
      }
      var gap = cur ? g.x - cur.x1 : 0;
      if (!cur || cur.k !== k || cur.f !== g.f || Math.abs(g.y - cur.y) > 0.35 * Math.max(g.sz, cur.sz) || gap < -0.6 * g.sz || gap > 6 * g.sz) { flush(); cur = { k: k, f: g.f, codes: [], s: '', x0: g.x, x1: g.x, y: g.y, sz: g.sz }; gap = 0; }
      if (gap > 0.32 * g.sz) { if (k) cur.codes.push(32); else cur.s += ' '; }
      if (k) cur.codes.push(code); else cur.s += s;
      cur.x1 = Math.max(cur.x1, g.x + (g.adv || 0)); cur.sz = Math.max(cur.sz, g.sz);
    });
    flush();
    return items;
  }

  /* public: read every page of a pdf.js document through glyph codes. Returns { pages:[{w,h,rows}], stats } */
  THK.pdfReadGlyphs = function (m, doc, pageRows, max, progress) {
    var n = Math.min(doc.numPages, max || 400), raw = [], i = 0;
    function next() {
      if (i >= n) return Promise.resolve();
      return doc.getPage(++i).then(function (pg) {
        var vp = pg.getViewport({ scale: 1 });
        return glyphs(m, pg).then(function (gl) { raw.push({ w: vp.width, h: vp.height, g: gl }); try { pg.cleanup(); } catch (e) { } if (progress) progress(i, n); return next(); });
      });
    }
    return next().then(function () {
      var all = []; raw.forEach(function (p) { all = all.concat(p.g); });
      var kinds = classifyFonts(all), stats = { unknown: 0, converted: 0, filled: 0, fonts: Object.keys(kinds).filter(function (f) { return kinds[f]; }) };
      var pages = raw.map(function (p) { return pageRows({ items: pageItems(p.g, kinds, stats) }, p.w, p.h); });
      return { pages: pages, stats: stats };
    });
  };
})();
