/* Importers/exporters for other screenwriting formats: Final Draft (.fdx), Scriptty (.screenplay), Fountain (see export.js). */
(function () {
  'use strict';
  var THK = window.THK = window.THK || {};
  function uid() { return Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4); }
  function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function newDoc(title) { return { id: uid(), title: title || '', credit: 'രചന', author: '', contact: '', draft: '', created: Date.now(), updated: Date.now(), blocks: [] }; }
  THK.newImportDoc = newDoc;
  function push(d, t, x) { x = String(x == null ? '' : x).replace(/ /g, ' ').replace(/[ \t]+\n/g, '\n').trim(); if (x) d.blocks.push({ id: uid(), t: t, x: x }); }

  /* ------------------------------------------------------------ Final Draft (.fdx) */
  var FDX_MAP = { 'scene heading': 'scene', 'action': 'action', 'general': 'action', 'character': 'char', 'dialogue': 'dial',
    'parenthetical': 'paren', 'transition': 'trans', 'shot': 'shot' };
  THK.isFDX = function (t) { return /<FinalDraft[\s>]/.test(t.slice(0, 4000)); };
  THK.parseFDX = function (xml) {
    var dom = new DOMParser().parseFromString(xml.replace(/^﻿/, ''), 'application/xml');
    if (dom.querySelector('parsererror')) throw new Error('Invalid FDX');
    var d = newDoc('');
    var textOf = function (p) { var s = ''; Array.prototype.forEach.call(p.children, function (c) { if (c.tagName === 'Text') s += c.textContent; }); return s; };
    // title page
    var tp = dom.querySelector('TitlePage > Content'), lines = [];
    if (tp) Array.prototype.forEach.call(tp.querySelectorAll(':scope > Paragraph'), function (p) { lines.push(textOf(p).trim()); });
    var ne = lines.filter(function (l) { return l; });
    if (ne.length) {
      d.title = ne[0];
      var ci = -1; ne.forEach(function (l, i) { if (ci < 0 && i > 0 && /^(written|screenplay|story|a film|by\b)/i.test(l)) ci = i; });
      if (ci > 0) { d.credit = ne[ci]; d.author = ne[ci + 1] || ''; d.contact = ne.slice(ci + 2).join('\n'); }
      else { d.contact = ne.slice(1).join('\n'); }
    }
    var cont = dom.querySelector('FinalDraft > Content') || dom.querySelector('Content');
    var n = 0;
    if (cont) Array.prototype.forEach.call(cont.children, function (p) {
      if (p.tagName !== 'Paragraph') return;
      var type = (p.getAttribute('Type') || 'Action').toLowerCase(), t = FDX_MAP[type];
      var x = textOf(p);
      if (type === 'cast list' || type === 'new act' || type === 'end of act' || type === 'show/ep. title' || type === 'outline') { if (type === 'outline') return; }
      if (!t) t = 'action';
      if (t === 'paren') x = x.trim().replace(/^\(/, '').replace(/\)$/, '');
      push(d, t, x); n++;
      Array.prototype.forEach.call(p.children, function (c) { if (c.tagName === 'ScriptNote') push(d, 'note', c.textContent); });
    });
    if (!d.title) d.title = 'Imported Final Draft script';
    if (!d.blocks.length) d.blocks.push({ id: uid(), t: 'scene', x: '' });
    return d;
  };

  THK.toFDX = function (doc) {
    var map = { scene: 'Scene Heading', action: 'Action', char: 'Character', dial: 'Dialogue', paren: 'Parenthetical', trans: 'Transition', shot: 'Shot' };
    var out = ['<?xml version="1.0" encoding="UTF-8" standalone="no" ?>', '<FinalDraft DocumentType="Script" Template="No" Version="5">', '<Content>'];
    var sn = 0;
    doc.blocks.forEach(function (b) {
      if (b.t === 'scene') sn++;
      var x = b.x.trim(); if (!x) return;
      if (b.t === 'note') { out.push('<Paragraph Type="Action"><ScriptNote><Paragraph><Text>' + esc(x) + '</Text></Paragraph></ScriptNote></Paragraph>'); return; }
      if (b.t === 'scene') x = (THK.stripSn ? THK.stripSn(x) : x).toUpperCase();
      if (b.t === 'paren') x = '(' + x + ')';
      out.push('<Paragraph Type="' + map[b.t] + '"' + (b.t === 'scene' ? ' Number="' + sn + '"' : '') + '><Text>' + esc(x) + '</Text></Paragraph>');
    });
    out.push('</Content>', '<TitlePage><Content>');
    var tl = [doc.title || '', '', doc.credit || '', doc.author || '', '', doc.contact || '', doc.draft || ''];
    tl.forEach(function (l) { out.push('<Paragraph Alignment="Center"><Text>' + esc(l) + '</Text></Paragraph>'); });
    out.push('</Content></TitlePage>', '</FinalDraft>');
    return out.join('\n');
  };

  /* ------------------------------------------------------------ Scriptty (.screenplay, JSON / ProseMirror-style tree) */
  var NODE_RULES = [
    [/scene|slug|heading/, 'scene'], [/transition/, 'trans'], [/paren/, 'paren'], [/character|speaker|cue/, 'char'],
    [/dialog|speech/, 'dial'], [/shot/, 'shot'], [/note/, 'note'], [/action|general|paragraph|description/, 'action']
  ];
  function mapType(t) {
    t = String(t || '').toLowerCase().replace(/[^a-z]/g, '');
    if (!t || t === 'text' || t === 'doc' || t === 'hardbreak') return null;
    for (var i = 0; i < NODE_RULES.length; i++) if (NODE_RULES[i][0].test(t)) return NODE_RULES[i][1];
    return null;
  }
  function plain(n) {
    if (n == null) return '';
    if (typeof n === 'string') return n;
    if (Array.isArray(n)) return n.map(plain).join('');
    if (typeof n.text === 'string') return n.text;
    var t = String(n.type || '').toLowerCase().replace(/[^a-z]/g, '');
    var inner = plain(n.content);
    return t === 'hardbreak' ? '\n' : inner;
  }
  function hasBlockChild(n) {
    if (!n || typeof n !== 'object') return false;
    var kids = Array.isArray(n) ? n : (Array.isArray(n.content) ? n.content : []);
    for (var i = 0; i < kids.length; i++) {
      var k = kids[i]; if (!k || typeof k !== 'object') continue;
      if (mapType(k.type) || hasBlockChild(k)) return true;
    }
    return false;
  }
  function walk(n, d, depth) {
    if (!n || typeof n !== 'object' || depth > 60) return;
    if (Array.isArray(n)) { n.forEach(function (c) { walk(c, d, depth + 1); }); return; }
    var t = mapType(n.type);
    if (t && !hasBlockChild(n)) {
      var x = plain(n.content != null ? n.content : n.text);
      if (t === 'paren') x = x.trim().replace(/^\(/, '').replace(/\)$/, '');
      push(d, t, x); return;
    }
    if (typeof n.type === 'string' && /^(text|hard_?break)$/i.test(n.type)) return;
    Object.keys(n).forEach(function (k) { if (k !== 'meta' && k !== 'marks' && k !== 'attrs' && typeof n[k] === 'object') walk(n[k], d, depth + 1); });
  }
  function metaOf(o) {
    var m = o.meta || o.metadata || o.title_page || o.titlePage || {};
    var g = function (keys) { for (var i = 0; i < keys.length; i++) { var v = m[keys[i]] != null ? m[keys[i]] : o[keys[i]]; if (typeof v === 'string' && v.trim()) return v.trim(); } return ''; };
    return { title: g(['title', 'name']), author: g(['author', 'writer', 'written_by']), draft: g(['draft_date', 'draftDate', 'draft', 'date']), contact: g(['contact']) };
  }

  /* ------------------------------------------------------------ Microsoft Word (.docx) */
  function u16(b, o) { return b[o] | (b[o + 1] << 8); }
  function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }
  THK.zipEntries = function (buf) { // reads the central directory of a .zip; returns {name: {m,cs,us,off}}
    var b = new Uint8Array(buf), e = b.length - 22; while (e >= 0 && u32(b, e) !== 0x06054b50) e--;
    if (e < 0) throw new Error('Not a .docx (zip) file'); var n = u16(b, e + 10), p = u32(b, e + 16), out = {};
    for (var i = 0; i < n; i++) {
      if (u32(b, p) !== 0x02014b50) break; var nl = u16(b, p + 28), xl = u16(b, p + 30), cl = u16(b, p + 32);
      var name = new TextDecoder().decode(b.subarray(p + 46, p + 46 + nl)); out[name] = { m: u16(b, p + 10), cs: u32(b, p + 20), off: u32(b, p + 42) }; p += 46 + nl + xl + cl;
    } return out;
  };
  THK.zipRead = function (buf, ents, name) {
    var en = ents[name]; if (!en) return Promise.resolve(null); var b = new Uint8Array(buf), o = en.off, ds = o + 30 + u16(b, o + 26) + u16(b, o + 28), raw = b.subarray(ds, ds + en.cs);
    if (en.m === 0) return Promise.resolve(new TextDecoder().decode(raw));
    if (typeof DecompressionStream === 'undefined') return Promise.reject(new Error('This device cannot unpack Word files. Save the script as .fdx or .txt instead.'));
    var st = new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Response(st).arrayBuffer().then(function (ab) { return new TextDecoder().decode(ab); });
  };
  var W_STYLE = [[/scene|heading|slug/, 'scene'], [/paren/, 'paren'], [/char/, 'char'], [/dialog|speech/, 'dial'], [/transition/, 'trans'], [/shot/, 'shot'], [/action|general|normal/, 'action']];
  THK.parseDocx = function (buf, fname) {
    var ents = THK.zipEntries(buf);
    return Promise.all([THK.zipRead(buf, ents, 'word/document.xml'), THK.zipRead(buf, ents, 'word/styles.xml')]).then(function (r) {
      if (!r[0]) throw new Error('No text found in this Word file');
      var P = new DOMParser(), doc = P.parseFromString(r[0], 'application/xml'), styles = {};
      if (r[1]) { var sd = P.parseFromString(r[1], 'application/xml'); Array.prototype.forEach.call(sd.getElementsByTagName('w:style'), function (s) { var n = s.getElementsByTagName('w:name')[0]; if (n) styles[s.getAttribute('w:styleId')] = (n.getAttribute('w:val') || '').toLowerCase(); }); }
      var on = function (el) { if (!el) return false; var v = el.getAttribute('w:val'); return v !== '0' && v !== 'false' && v !== 'none'; };
      var paras = [];
      Array.prototype.forEach.call(doc.getElementsByTagName('w:p'), function (p) {
        var pp = p.getElementsByTagName('w:pPr')[0], jc = '', ind = 0, sty = '';
        if (pp) {
          var j = pp.getElementsByTagName('w:jc')[0]; if (j) jc = j.getAttribute('w:val') || '';
          var d = pp.getElementsByTagName('w:ind')[0]; if (d) ind = +(d.getAttribute('w:left') || d.getAttribute('w:start') || 0) || 0;
          var ps = pp.getElementsByTagName('w:pStyle')[0]; if (ps) { var id = ps.getAttribute('w:val'); sty = (styles[id] || id || '').toLowerCase(); }
        }
        var text = '', runs = [], allBold = true, any = false;
        Array.prototype.forEach.call(p.getElementsByTagName('w:r'), function (r) {
          var rp = r.getElementsByTagName('w:rPr')[0], a = {}, caps = false;
          if (rp) {
            var q = function (t) { var e = rp.getElementsByTagName(t)[0]; return e; };
            if (on(q('w:b'))) a.b = 1; if (on(q('w:i'))) a.i = 1; if (on(q('w:u'))) a.u = 1; if (on(q('w:caps'))) caps = true;
            var c = q('w:color'); if (c) { var cv = c.getAttribute('w:val'); if (cv && /^[0-9a-f]{6}$/i.test(cv) && !/^0{6}$/.test(cv)) a.c = '#' + cv.toLowerCase(); }
            var z = q('w:sz'); if (z) { var zv = (+z.getAttribute('w:val')) / 2; if (zv >= 6 && zv <= 72 && Math.abs(zv - 12) > .6) a.z = zv; }
          }
          var t = ''; Array.prototype.forEach.call(r.childNodes, function (n) {
            var ln = n.nodeName; if (ln === 'w:t') t += n.textContent; else if (ln === 'w:tab') t += '  '; else if (ln === 'w:br' || ln === 'w:cr') t += '\n';
          });
          if (!t) return; if (caps) t = t.toUpperCase(); var s0 = text.length; text += t; any = true; if (!a.b && /\S/.test(t)) allBold = false;
          if (a.b || a.i || a.u || a.c || a.z) runs.push(Object.assign({ s: s0, e: text.length }, a));
        });
        paras.push({ text: text.replace(/ /g, ' ').replace(/[ \t]+$/g, ''), runs: runs, jc: jc, ind: ind, sty: sty, bold: any && allBold });
      });
      return THK.docxToScript(paras, fname);
    });
  };
  THK.docxToScript = function (paras, fname) {
    var d = newDoc((fname || '').replace(/\.[^.]+$/, '')), cl = [];
    paras.forEach(function (p) { var lead = p.text.match(/^\s*/)[0].length; p.text = p.text.replace(/^\s+/, ''); p.runs = p.runs.map(function (r) { return Object.assign({}, r, { s: Math.max(0, r.s - lead), e: Math.max(0, r.e - lead) }); }); });
    var P = paras.filter(function (p) { return p.text.trim(); }); // empty paragraphs only separate things
    var SCENE = /^(\d+\s*[\.\)\-]?\s*)?(INT|EXT|INT\.?\s*\/\s*EXT|I\s*\/\s*E|EST)\b|^(scene|സീൻ|രംഗം)\s*[\d:.\-]/i, TRANS = /(^|\s)(CUT TO|FADE (IN|OUT|TO)|DISSOLVE TO|SMASH CUT|MATCH CUT|CUT)\s*[:.]?$|TO:$|^(കട്ട്|ഫെയ്ഡ്)/i;
    var colonLines = P.filter(function (p) { return /^[^\s:：]{1,24}(\s[^\s:：]{1,18}){0,2}\s*[:：]\s+\S/.test(p.text) && !SCENE.test(p.text); }).length, useColon = colonLines >= 3;
    var firstScene = -1; P.forEach(function (p, i) { if (firstScene < 0 && (SCENE.test(p.text) || /scene heading|slug/.test(p.sty))) firstScene = i; });
    var i0 = 0;
    if (firstScene > 0 && firstScene <= 8) { // cover lines before the first scene: short + centred
      var head = P.slice(0, firstScene), cover = head.every(function (p) { return p.text.length <= 70 && (p.jc === 'center' || p.bold); });
      if (cover) { d.title = head[0].text; head.slice(1).forEach(function (p) { if (!d.writer && /(written|story|screenplay|by\b|രചന|തിരക്കഥ)/i.test(p.text)) d.writer = p.text.replace(/^(written by|screenplay by|by|രചന|തിരക്കഥ)\s*[:\-–]?\s*/i, '').trim() || p.text; }); i0 = firstScene; }
    }
    var after = ''; // what the previous block was: 'char' / 'paren' / 'dial'
    function add(t, p, txt, runs) {
      txt = txt == null ? p.text : txt; runs = runs || p.runs; var b = { id: Math.random().toString(36).slice(2, 8) + d.blocks.length, t: t, x: txt };
      if (t === 'scene') b.x2 = '';
      if (p.bold && t !== 'action' && t !== 'dial') runs = runs.map(function (r) { var o = Object.assign({}, r); delete o.b; return o; }).filter(function (r) { return r.i || r.u || r.c || r.z; });
      if (runs.length) b.fm = { x: runs.filter(function (r) { return r.e > r.s && r.s < txt.length; }) };
      if (b.fm && !b.fm.x.length) delete b.fm; d.blocks.push(b);
    }
    for (var i = i0; i < P.length; i++) {
      var p = P[i], t = p.text.trim(), nx = P[i + 1], st = null, sy = p.sty;
      W_STYLE.forEach(function (w) { if (!st && w[0].test(sy) && w[1] !== 'action') st = w[1]; });
      if (!st) {
        var wide = p.ind >= 1800 || p.jc === 'center' || p.jc === 'right';
        if (SCENE.test(t)) st = 'scene';
        else if (TRANS.test(t) && t.length <= 30 && (p.jc === 'right' || t === t.toUpperCase())) st = 'trans';
        else if (/^\(.*\)$/.test(t.replace(/\n/g, ' ')) && after !== '') st = 'paren';
        else if (useColon && /^[^\s:：]{1,24}(\s[^\s:：]{1,18}){0,2}\s*[:：]\s+\S/.test(t)) st = 'colon';
        else if (t.length <= 36 && !/[.!?…]$/.test(t) && nx && !SCENE.test(nx.text) && ((wide && p.jc !== 'right') || (/[A-Z]/.test(t) && t === t.toUpperCase() && !/\d{3}/.test(t)) || (p.bold && after !== 'char' && nx.ind > p.ind - 1 && !nx.bold && after === ''))) st = 'char';
        else if (after === 'char' || after === 'paren') st = 'dial';
        else if (after === 'dial' && p.ind >= 700 && p.jc !== 'center') st = 'dial';
        else st = 'action';
      }
      if (st === 'colon') { var m = t.match(/^([^:：]+?)\s*[:：]\s+([\s\S]+)$/), cut = t.length - m[2].length; add('char', p, m[1].trim(), []); add('dial', p, m[2], p.runs.map(function (r) { return Object.assign({}, r, { s: r.s - cut, e: r.e - cut }); }).filter(function (r) { return r.e > 0; }).map(function (r) { r.s = Math.max(0, r.s); return r; })); after = 'dial'; continue; }
      if (st === 'char') t = t.replace(/[:：]\s*$/, '');
      if (st === 'paren') { var pt = t.replace(/\n/g, ' ').replace(/^\(\s*/, '').replace(/\s*\)$/, ''); add('paren', p, pt, []); after = 'paren'; continue; }
      add(st, p, st === 'char' ? t : null, st === 'char' ? [] : null); after = st === 'scene' || st === 'trans' || st === 'action' || st === 'shot' || st === 'note' ? '' : st;
    }
    if (!d.blocks.length) throw new Error('No text found in this Word file');
    if (/[ഀ-ൿ]/.test(d.blocks.map(function (b) { return b.x; }).join('').slice(0, 2000))) { d.lang = 'ml'; } else { d.lang = 'en'; d.font = 'CourierPrime'; }
    return d;
  };

  THK.isScriptty = function (o) { return o && typeof o === 'object' && !o.app && !o.docs && (o.meta || o.doc || o.content || o.episodes || o.screenplay || o.type === 'doc'); };
  THK.parseScriptty = function (o) {
    var docs = [], m = metaOf(o);
    var build = function (node, title) {
      var d = newDoc(title || m.title || 'Imported Scriptty script'); d.author = m.author; d.draft = m.draft; d.contact = m.contact;
      walk(node, d, 0); if (!d.blocks.length) return null; return d;
    };
    var eps = o.episodes || (o.series && o.series.episodes);
    if (Array.isArray(eps) && eps.length) {
      eps.forEach(function (e, i) { var d = build(e.doc || e.content || e.screenplay || e, (m.title || 'Series') + ' – ' + (e.title || e.name || ('Episode ' + (i + 1)))); if (d) docs.push(d); });
    }
    if (!docs.length) { var d = build(o.doc || o.screenplay || o.content || o); if (d) docs.push(d); }
    if (!docs.length) throw new Error('No script content found');
    return docs;
  };
})();
