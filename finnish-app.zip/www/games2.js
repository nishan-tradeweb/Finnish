/* Game Centre — seven more calm games (Drift, Echo, Pairs, Merge, Word Mix, Pulse, Dim). Small, offline, soft colours. */
(function () {
  'use strict';
  var G = window.THK && THK.games; if (!G || !G.h) return;
  var H = G.h, el = H.el, shell = H.shell, endCard = H.endCard, dotsTxt = H.dotsTxt;

  var css = '#gc .lsc{color:var(--ink)}#gc .lsc.lit,#gc .lsc.ok{color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.25)}' +
    '#gc .mg{gap:8px}#gc .mg .lsc{font-size:clamp(18px,6.4vw,30px);font-weight:800;border-radius:18%}#gc .mg .lsc.pop{animation:mgpop .22s}@keyframes mgpop{0%{transform:scale(.6)}100%{transform:scale(1)}}' +
    '#gc .pr .lsc{font-size:clamp(20px,7vw,32px);border-radius:20%}' +
    '#gc .wd{position:absolute;left:50%;top:50%;transform:translate(-50%,-46%);width:min(92vw,460px);display:flex;flex-direction:column;align-items:center;gap:30px}' +
    '#gc .wds,#gc .wdt{display:flex;gap:8px;flex-wrap:wrap;justify-content:center}' +
    '#gc .wdc{width:44px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:24px;border:1.5px dashed rgba(128,128,128,.55);color:var(--ink);cursor:pointer}' +
    '#gc .wdc.f{border:var(--S-bd,1px solid var(--edge));background:var(--S-bg,var(--glass));box-shadow:var(--S-sh,var(--shadow))}' +
    '#gc .wdc.ok{border-color:transparent;background:linear-gradient(150deg,hsl(var(--gh,212),64%,74%),hsl(var(--gh,212),58%,54%));color:#fff}' +
    '#gc .wdc.bad{animation:lsshake .34s}' +
    '#gc .lsc.wdk{width:50px;height:56px;border-radius:18px;font-weight:800;font-size:24px}#gc .lsc.wdk.gone{visibility:hidden}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  function hsl(h, l, s) { return 'hsl(' + (((h % 360) + 360) % 360) + ',' + (s || 58) + '%,' + l + '%)'; }
  function rnd(n) { return Math.floor(Math.random() * n); }
  var AC = null;
  function tone(f, v, d) {
    try {
      if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)();
      var o = AC.createOscillator(), g = AC.createGain(), n = AC.currentTime; d = d || 0.5;
      o.type = 'sine'; o.frequency.value = f; g.gain.setValueAtTime(0, n); g.gain.linearRampToValueAtTime(v || 0.05, n + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, n + d);
      o.connect(g); g.connect(AC.destination); o.start(); o.stop(n + d + 0.05);
    } catch (e) { }
  }
  function freeAudio() { try { AC && AC.close(); } catch (e) { } AC = null; }

  /* shared scaffolding: HUD, timers, Esc, end card */
  function base(host, api, label, hint) {
    var s = { dead: false, tms: [], ui: shell(host, api, label, hint) };
    s.later = function (f, ms) { var t = setTimeout(function () { if (!s.dead) f(); }, ms); s.tms.push(t); return t; };
    s.clear = function () { s.tms.forEach(clearTimeout); s.tms.length = 0; };
    s.key = function (e) { if (e.key === 'Escape') api.exit(); };
    window.addEventListener('keydown', s.key);
    s.end = function (score, again, delay) { s.clear(); s.over = true; s.tms.push(endCard(host, api, s.ui, score, function () { s.over = false; again(); }, delay)); };
    s.done = function () { s.dead = true; s.clear(); window.removeEventListener('keydown', s.key); };
    return s;
  }
  function grid(host, cls) { var g = el('div', 'lsg' + (cls ? ' ' + cls : '')); host.appendChild(g); return g; }
  function ring(c, r, hu, l) { return '<circle cx="32" cy="32" r="' + r + '" stroke="' + hsl(hu, l || 62) + '"/>'; }
  var SV = '<svg viewBox="0 0 64 64" width="60" height="60" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">';

  /* ================= Drift (pop bubbles) ================= */
  function drift(host, api) {
    var cv = el('canvas'), ctx = cv.getContext('2d'), W = 0, H2 = 0, dpr = 1; host.appendChild(cv);
    var s = base(host, api, 'Popped', 'Tap the bubbles before they float away'), ui = s.ui;
    var bubs, score, chances, t, nxt, raf = 0, last = 0;
    function resize() { var r = host.getBoundingClientRect(); W = r.width; H2 = r.height; dpr = Math.min(2, window.devicePixelRatio || 1); cv.width = W * dpr; cv.height = H2 * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); }
    function reset() { s.clear(); s.over = false; bubs = []; score = 0; chances = 3; t = 0; nxt = 0.2; ui.num.textContent = 0; ui.dots.textContent = dotsTxt(3, 3); ui.hint.style.opacity = 1; }
    function spawn() { var r = 26 + Math.random() * 24; bubs.push({ x: r + Math.random() * Math.max(1, W - 2 * r), y: H2 + r, r: r, vy: Math.min(150, 46 + Math.random() * 30 + score * 1.2), h: 200 + Math.random() * 130, ph: Math.random() * 6.28, pop: -1 }); }
    function pop(b) { b.pop = 0; score++; ui.num.textContent = score; ui.hint.style.opacity = 0; tone(330 + (60 - b.r) * 9, 0.04, 0.35); try { navigator.vibrate && navigator.vibrate(5); } catch (e) { } }
    function tap(x, y) { if (s.over) return; for (var i = bubs.length - 1; i >= 0; i--) { var b = bubs[i]; if (b.pop < 0 && Math.hypot(b.x - x, b.y - y) <= b.r + 12) { pop(b); return; } } }
    function step(dt) {
      var i, b; t += dt;
      if (!s.over) { nxt -= dt; if (nxt <= 0) { spawn(); nxt = Math.max(0.42, 1.25 - score * 0.02) + Math.random() * 0.35; } }
      for (i = bubs.length - 1; i >= 0; i--) {
        b = bubs[i];
        if (b.pop >= 0) { b.pop += dt * 3.2; if (b.pop >= 1) bubs.splice(i, 1); continue; }
        b.y -= b.vy * dt; b.x += Math.sin(t * 1.3 + b.ph) * 16 * dt;
        if (b.y + b.r < 0) { bubs.splice(i, 1); if (!s.over) { chances--; ui.dots.textContent = dotsTxt(chances, 3); if (chances <= 0) s.end(score, reset, 600); } }
      }
    }
    function draw() {
      ctx.clearRect(0, 0, W, H2);
      for (var i = 0; i < bubs.length; i++) {
        var b = bubs[i], k = b.pop < 0 ? 0 : b.pop, r = b.r * (1 + k * 0.45), g = ctx.createRadialGradient(b.x - r * 0.3, b.y - r * 0.35, r * 0.08, b.x, b.y, r);
        g.addColorStop(0, 'hsla(' + b.h + ',70%,90%,.95)'); g.addColorStop(1, 'hsla(' + b.h + ',58%,64%,.55)');
        ctx.globalAlpha = 1 - k; ctx.fillStyle = g; ctx.beginPath(); ctx.arc(b.x, b.y, r, 0, 6.2832); ctx.fill();
        ctx.strokeStyle = 'hsla(' + b.h + ',60%,74%,.9)'; ctx.lineWidth = 1.6; ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    function loop(ts) { raf = requestAnimationFrame(loop); var dt = Math.max(0.001, Math.min(0.05, (ts - last) / 1000 || 0.016)); last = ts; step(dt); draw(); }
    function onDown(e) { if (e.target.closest && (e.target.closest('.btn') || e.target.closest('.over'))) return; e.preventDefault(); var r = host.getBoundingClientRect(); tap(e.clientX - r.left, e.clientY - r.top); }
    host.addEventListener('pointerdown', onDown); window.addEventListener('resize', resize); resize(); reset(); last = performance.now(); raf = requestAnimationFrame(loop);
    return {
      stop: function () { s.done(); cancelAnimationFrame(raf); api.setBest(score); host.removeEventListener('pointerdown', onDown); window.removeEventListener('resize', resize); freeAudio(); },
      _t: function () { return { score: function () { return score; }, chances: function () { return chances; }, bubs: bubs, tap: tap, step: step }; }
    };
  }

  /* ================= Echo (repeat the colours) ================= */
  function echo(host, api) {
    var s = base(host, api, 'Round', 'Watch, then repeat'), ui = s.ui, g = grid(host), pads = [], HU = [212, 262, 330, 160], FR = [392, 494, 587, 698];
    var seq, pos, chances, phase, score;
    g.style.gridTemplateColumns = 'repeat(2,1fr)';
    for (var i = 0; i < 4; i++) (function (i) { var b = el('button', 'lsc'); b.style.setProperty('--gh', HU[i]); b.setAttribute('aria-label', 'Pad ' + (i + 1)); b.addEventListener('pointerdown', function (e) { e.preventDefault(); press(i); }); g.appendChild(b); pads.push(b); })(i);
    function flash(i, ms) { pads[i].classList.add('lit'); tone(FR[i], 0.06, 0.45); s.later(function () { pads[i].classList.remove('lit'); }, ms); }
    function play() {
      phase = 'show'; ui.hint.textContent = 'Watch…'; var sp = Math.max(360, 720 - seq.length * 22);
      seq.forEach(function (p, j) { s.later(function () { flash(p, sp * 0.62); }, 700 + j * sp); });
      s.later(function () { phase = 'input'; pos = 0; ui.hint.textContent = 'Your turn'; }, 700 + seq.length * sp);
    }
    function round() { seq.push(rnd(4)); ui.num.textContent = seq.length; play(); }
    function reset() { s.clear(); seq = []; chances = 2; score = 0; ui.dots.textContent = dotsTxt(chances, 2); round(); }
    function press(i) {
      if (phase !== 'input') return;
      if (i === seq[pos]) {
        flash(i, 200); pos++;
        if (pos === seq.length) { score = seq.length; phase = 'wait'; ui.hint.textContent = 'Lovely'; s.later(round, 900); }
      } else {
        phase = 'wait'; chances--; ui.dots.textContent = dotsTxt(chances, 2); pads[i].classList.add('bad'); s.later(function () { pads[i].classList.remove('bad'); }, 400);
        if (chances > 0) { ui.hint.textContent = 'Watch once more'; s.later(play, 1000); } else s.end(score, reset, 700);
      }
    }
    reset();
    return { stop: function () { s.done(); api.setBest(score); freeAudio(); }, _t: function () { return { seq: seq, phase: function () { return phase; }, press: press, score: function () { return score; }, chances: function () { return chances; } }; } };
  }

  /* ================= Pairs (memory cards) ================= */
  var GL = ['●', '▲', '■', '◆', '★', '✚', '☾', '♥', '✿', '☀'], GH = [212, 262, 330, 160, 36, 190, 290, 350, 100, 50], COLS = { 6: 3, 8: 4, 10: 5, 12: 4, 14: 7, 16: 4, 18: 6, 20: 5 };
  function pairs(host, api) {
    var s = base(host, api, 'Level', 'Find the matching pairs'), ui = s.ui, g = grid(host, 'pr'), lvl, deck, cards, first, lock, found, miss, n;
    function build() {
      s.clear(); n = Math.min(2 + lvl, 10); var tot = n * 2, cols = COLS[tot] || 5; deck = []; found = 0; first = -1; lock = false; miss = n + 3;
      for (var i = 0; i < n; i++) deck.push(i, i); for (i = tot - 1; i > 0; i--) { var j = rnd(i + 1), t = deck[i]; deck[i] = deck[j]; deck[j] = t; }
      g.innerHTML = ''; g.style.gridTemplateColumns = 'repeat(' + cols + ',1fr)'; g.style.aspectRatio = cols + '/' + Math.ceil(tot / cols); cards = [];
      deck.forEach(function (v, i) { var c = el('button', 'lsc'); c.setAttribute('aria-label', 'Card ' + (i + 1)); c.addEventListener('pointerdown', function (e) { e.preventDefault(); tap(i); }); g.appendChild(c); cards.push(c); });
      ui.num.textContent = lvl; ui.dots.textContent = dotsTxt(miss, miss); ui.hint.textContent = 'Find the matching pairs';
    }
    function show(i) { var c = cards[i]; c.textContent = GL[deck[i]]; c.style.setProperty('--gh', GH[deck[i]]); c.classList.add('lit'); }
    function hide(i) { var c = cards[i]; c.textContent = ''; c.classList.remove('lit'); }
    function reset() { lvl = 1; build(); }
    function tap(i) {
      if (lock || cards[i].classList.contains('lit')) return; show(i);
      if (first < 0) { first = i; return; }
      var a = first; first = -1;
      if (deck[a] === deck[i]) { cards[a].classList.add('ok'); cards[i].classList.add('ok'); tone(520 + deck[i] * 40, 0.05, 0.4); if (++found === n) { lock = true; ui.hint.textContent = 'Lovely'; lvl++; s.later(build, 1000); } }
      else {
        lock = true; miss--; ui.dots.textContent = dotsTxt(miss, n + 3);
        s.later(function () { hide(a); hide(i); lock = false; if (miss <= 0) { lock = true; s.end(lvl - 1, reset, 100); } }, 800);
      }
    }
    reset();
    return { stop: function () { s.done(); api.setBest(lvl - 1); freeAudio(); }, _t: function () { return { lvl: function () { return lvl; }, deck: deck, cards: cards, tap: tap, miss: function () { return miss; } }; } };
  }

  /* ================= Merge (2048-style) ================= */
  function merge(host, api) {
    var s = base(host, api, 'Score', 'Swipe to slide and merge'), ui = s.ui, g = grid(host, 'mg'), b, score, cells = [], sx = 0, sy = 0, down = false, newAt = -1;
    host.style.touchAction = 'none'; g.style.gridTemplateColumns = 'repeat(4,1fr)';
    for (var i = 0; i < 16; i++) { var c = el('div', 'lsc'); c.style.cursor = 'default'; g.appendChild(c); cells.push(c); }
    function add() { var e = []; b.forEach(function (v, i) { if (!v) e.push(i); }); if (!e.length) return; newAt = e[rnd(e.length)]; b[newAt] = Math.random() < 0.9 ? 2 : 4; }
    function render() {
      b.forEach(function (v, i) {
        var c = cells[i]; c.textContent = v || ''; c.classList.toggle('lit', !!v); c.classList.remove('pop');
        if (v) { c.style.setProperty('--gh', (212 + Math.log2(v) * 24) % 360); c.style.fontSize = v > 999 ? '0.72em' : v > 99 ? '0.86em' : ''; } if (i === newAt && v) { void c.offsetWidth; c.classList.add('pop'); }
      }); ui.num.textContent = score; newAt = -1;
    }
    function lines(d) {
      var out = [], r, c, k, a;
      for (r = 0; r < 4; r++) { a = []; for (k = 0; k < 4; k++) a.push(d < 2 ? r * 4 + k : k * 4 + r); if (d === 1 || d === 3) a.reverse(); out.push(a); }
      return out;
    }
    function canMove() { for (var i = 0; i < 16; i++) { if (!b[i]) return true; if ((i % 4 < 3 && b[i] === b[i + 1]) || (i < 12 && b[i] === b[i + 4])) return true; } return false; }
    function move(d) {
      if (s.over) return false; var ch = false;
      lines(d).forEach(function (ids) {
        var vals = ids.map(function (i) { return b[i]; }).filter(Boolean), out = [], k;
        for (k = 0; k < vals.length; k++) { if (vals[k] === vals[k + 1]) { out.push(vals[k] * 2); score += vals[k] * 2; k++; } else out.push(vals[k]); }
        while (out.length < 4) out.push(0);
        ids.forEach(function (id, j) { if (b[id] !== out[j]) ch = true; b[id] = out[j]; });
      });
      if (ch) { add(); tone(300 + Math.min(500, score), 0.03, 0.2); render(); ui.hint.style.opacity = 0; if (!canMove()) s.end(score, reset, 700); }
      return ch;
    }
    function reset() { s.clear(); b = []; for (var i = 0; i < 16; i++) b.push(0); score = 0; add(); add(); ui.hint.style.opacity = 1; ui.dots.textContent = ''; render(); }
    function onDown(e) { if (e.target.closest && (e.target.closest('.btn') || e.target.closest('.over'))) return; down = true; sx = e.clientX; sy = e.clientY; }
    function onUp(e) {
      if (!down) return; down = false; var dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.max(Math.abs(dx), Math.abs(dy)) < 26) return;
      move(Math.abs(dx) > Math.abs(dy) ? (dx < 0 ? 0 : 1) : (dy < 0 ? 2 : 3));
    }
    function onKey(e) { var d = { ArrowLeft: 0, ArrowRight: 1, ArrowUp: 2, ArrowDown: 3 }[e.key]; if (d != null) { e.preventDefault(); move(d); } }
    host.addEventListener('pointerdown', onDown); host.addEventListener('pointerup', onUp); window.addEventListener('keydown', onKey); reset();
    return {
      stop: function () { s.done(); api.setBest(score); host.removeEventListener('pointerdown', onDown); host.removeEventListener('pointerup', onUp); window.removeEventListener('keydown', onKey); freeAudio(); },
      _t: function () { return { b: function () { return b; }, set: function (a) { b = a; render(); }, move: move, score: function () { return score; } }; }
    };
  }

  /* ================= Word Mix (unscramble writing words) ================= */
  var WORDS = ('FILM STAR HERO PLOT CAST CLIP TAKE FADE CUT SHOT MOOD NOTE HOOK SCENE ACTOR STORY FRAME DRAMA THEME TWIST STAGE SOUND MUSIC VOICE LIGHT DREAM HEART STORM RIVER PAPER DRAFT TITLE VILLAIN WRITER EDITOR CINEMA MOVIE ACTION CAMERA SCRIPT ENDING GENRE CLIMAX SEQUEL COMEDY LETTER WINDOW SUNSET GARDEN SILENCE MOTION SHADOW PENCIL OUTLINE SETTING MYSTERY TRAGEDY ROMANCE REWRITE CHAPTER DIALOGUE DIRECTOR PRODUCER THRILLER ADVENTURE CHARACTER').split(' ');
  function words(host, api) {
    var s = base(host, api, 'Words', 'Tap the letters in order'), ui = s.ui, wrap = el('div', 'wd'), slotsEl = el('div', 'wds'), tilesEl = el('div', 'wdt'), skipB = el('button', 'btn sm', 'Skip');
    var word, letters, ans, solved, chances, seen, lock;
    wrap.appendChild(slotsEl); wrap.appendChild(tilesEl); wrap.appendChild(skipB); host.appendChild(wrap);
    function pick() {
      var mx = Math.min(9, 4 + Math.floor(solved / 2)), c = WORDS.filter(function (w) { return w.length <= mx && !seen[w]; });
      if (!c.length) c = WORDS.filter(function (w) { return !seen[w]; }); if (!c.length) { seen = {}; c = WORDS; } return c[rnd(c.length)];
    }
    function next() {
      s.clear(); word = pick(); seen[word] = 1; ans = []; lock = false; letters = word.split('');
      for (var t = 0; t < 12; t++) { for (var i = letters.length - 1; i > 0; i--) { var j = rnd(i + 1), x = letters[i]; letters[i] = letters[j]; letters[j] = x; } if (letters.join('') !== word) break; }
      ui.hint.textContent = 'Tap the letters in order'; draw();
    }
    function draw(state) {
      slotsEl.innerHTML = ''; tilesEl.innerHTML = '';
      for (var i = 0; i < word.length; i++) (function (i) { var d = el('div', 'wdc' + (ans[i] != null ? ' f' : '') + (state ? ' ' + state : ''), ans[i] != null ? letters[ans[i]] : ''); d.style.setProperty('--gh', (212 + solved * 18) % 360); d.addEventListener('pointerdown', function (e) { e.preventDefault(); if (!lock && i < ans.length) { ans.length = i; draw(); } }); slotsEl.appendChild(d); })(i);
      letters.forEach(function (ch, k) { var b = el('button', 'lsc wdk' + (ans.indexOf(k) >= 0 ? ' gone' : ''), ch); b.addEventListener('pointerdown', function (e) { e.preventDefault(); tap(k); }); tilesEl.appendChild(b); });
    }
    function lose() { chances--; ui.dots.textContent = dotsTxt(chances, 3); return chances <= 0; }
    function tap(k) {
      if (lock || ans.indexOf(k) >= 0) return; ans.push(k); tone(420 + ans.length * 40, 0.03, 0.2); draw();
      if (ans.length < word.length) return;
      var w = ans.map(function (a) { return letters[a]; }).join(''); lock = true;
      if (w === word) { solved++; ui.num.textContent = solved; ui.hint.textContent = 'Lovely'; draw('ok'); s.later(next, 1000); }
      else { draw('bad'); ui.hint.textContent = 'Not quite'; if (lose()) s.later(function () { s.end(solved, reset, 100); }, 500); else s.later(function () { ans = []; lock = false; ui.hint.textContent = 'Tap the letters in order'; draw(); }, 600); }
    }
    function skip() { if (lock) return; lock = true; ui.hint.textContent = 'It was ' + word; letters = word.split(''); ans = letters.map(function (_, i) { return i; }); draw('ok'); if (lose()) s.later(function () { s.end(solved, reset, 100); }, 1100); else s.later(next, 1300); }
    skipB.addEventListener('click', skip);
    function reset() { solved = 0; chances = 3; seen = {}; ui.num.textContent = 0; ui.dots.textContent = dotsTxt(3, 3); next(); }
    reset();
    return { stop: function () { s.done(); api.setBest(solved); }, _t: function () { return { word: function () { return word; }, letters: function () { return letters; }, tap: tap, skip: skip, solved: function () { return solved; }, chances: function () { return chances; } }; } };
  }

  /* ================= Pulse (timing) ================= */
  function pulse(host, api) {
    var cv = el('canvas'), ctx = cv.getContext('2d'), W = 0, H2 = 0, dpr = 1, ink = '#222'; host.appendChild(cv);
    var s = base(host, api, 'Streak', 'Tap when the ring meets the circle'), ui = s.ui, R0 = 62, rg = null, fl = [], score, chances, raf = 0, last = 0, tol, spd;
    function resize() { var r = host.getBoundingClientRect(); W = r.width; H2 = r.height; dpr = Math.min(2, window.devicePixelRatio || 1); cv.width = W * dpr; cv.height = H2 * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ink = getComputedStyle(host).color; }
    function hue() { return 212 + score * 14; }
    function spawn() { if (s.over) return; var dur = Math.max(0.85, 1.9 - score * 0.05), rs = R0 + Math.min(230, Math.min(W, H2) * 0.4); tol = Math.max(11, 22 - score * 0.4); spd = (rs - R0) / dur; rg = { r: rs }; }
    function reset() { s.clear(); s.over = false; score = 0; chances = 3; fl = []; rg = null; ui.num.textContent = 0; ui.dots.textContent = dotsTxt(3, 3); ui.hint.style.opacity = 1; s.later(spawn, 700); }
    function result(good) {
      var cx = W / 2, cy = H2 * 0.52; fl.push({ r: R0, t: 0, good: good }); rg = null;
      if (good) { score++; ui.num.textContent = score; ui.hint.style.opacity = 0; tone(392 + (score % 6) * 66, 0.06, 0.5); try { navigator.vibrate && navigator.vibrate(6); } catch (e) { } s.later(spawn, 650); }
      else { chances--; ui.dots.textContent = dotsTxt(chances, 3); if (chances <= 0) s.end(score, reset, 700); else s.later(spawn, 900); }
    }
    function tap() { if (!rg || s.over) return; result(Math.abs(rg.r - R0) <= tol); }
    function step(dt) {
      if (rg) { rg.r -= spd * dt; if (rg.r < R0 - tol) result(false); }
      for (var i = fl.length - 1; i >= 0; i--) { fl[i].t += dt * 1.6; if (fl[i].t >= 1) fl.splice(i, 1); }
    }
    function draw() {
      var cx = W / 2, cy = H2 * 0.52, i; ctx.clearRect(0, 0, W, H2); ctx.lineWidth = 2; ctx.strokeStyle = ink; ctx.globalAlpha = 0.3; ctx.beginPath(); ctx.arc(cx, cy, R0, 0, 6.2832); ctx.stroke();
      ctx.fillStyle = hsl(hue(), 66); ctx.globalAlpha = 0.14; ctx.beginPath(); ctx.arc(cx, cy, R0 - 2, 0, 6.2832); ctx.fill();
      if (rg) { var near = Math.abs(rg.r - R0) <= tol; ctx.globalAlpha = near ? 0.95 : 0.7; ctx.strokeStyle = hsl(hue(), 62); ctx.lineWidth = near ? 6 : 3.5; ctx.beginPath(); ctx.arc(cx, cy, Math.max(1, rg.r), 0, 6.2832); ctx.stroke(); }
      for (i = 0; i < fl.length; i++) { var f = fl[i]; ctx.globalAlpha = (1 - f.t) * 0.7; ctx.lineWidth = 3; ctx.strokeStyle = f.good ? hsl(hue(), 62) : ink; ctx.beginPath(); ctx.arc(cx, cy, f.r + f.t * 70, 0, 6.2832); ctx.stroke(); }
      ctx.globalAlpha = 1;
    }
    function loop(ts) { raf = requestAnimationFrame(loop); var dt = Math.max(0.001, Math.min(0.05, (ts - last) / 1000 || 0.016)); last = ts; step(dt); draw(); }
    function onDown(e) { if (e.target.closest && (e.target.closest('.btn') || e.target.closest('.over'))) return; e.preventDefault(); tap(); }
    host.addEventListener('pointerdown', onDown); window.addEventListener('resize', resize); resize(); reset(); last = performance.now(); raf = requestAnimationFrame(loop);
    return {
      stop: function () { s.done(); cancelAnimationFrame(raf); api.setBest(score); host.removeEventListener('pointerdown', onDown); window.removeEventListener('resize', resize); freeAudio(); },
      _t: function () { return { score: function () { return score; }, chances: function () { return chances; }, ring: function () { return rg; }, R0: R0, tol: function () { return tol; }, tap: tap, step: step }; }
    };
  }

  /* ================= Dim (turn the lights off) ================= */
  function dim(host, api) {
    var s = base(host, api, 'Level', 'Turn every light off'), ui = s.ui, g = grid(host), lvl, size, b, moves, cells, lock;
    function sz(l) { return l <= 3 ? 3 : l <= 7 ? 4 : 5; }
    function toggle(i) { var x = i % size, y = Math.floor(i / size); b[i] ^= 1; if (x > 0) b[i - 1] ^= 1; if (x < size - 1) b[i + 1] ^= 1; if (y > 0) b[i - size] ^= 1; if (y < size - 1) b[i + size] ^= 1; }
    function render() { cells.forEach(function (c, i) { c.classList.toggle('lit', !!b[i]); }); ui.dots.textContent = 'Moves left ' + moves; }
    function build() {
      s.clear(); size = sz(lvl); var n = size * size, k = Math.min(n - 2, 2 + lvl), i; lock = false;
      do { b = []; for (i = 0; i < n; i++) b.push(0); var pool = []; for (i = 0; i < n; i++) pool.push(i); for (i = 0; i < k; i++) toggle(pool.splice(rnd(pool.length), 1)[0]); } while (!b.some(Boolean));
      moves = k + 2; g.innerHTML = ''; g.style.gridTemplateColumns = 'repeat(' + size + ',1fr)'; g.style.setProperty('--gh', (212 + lvl * 18) % 360); cells = [];
      for (i = 0; i < n; i++) (function (i) { var c = el('button', 'lsc'); c.setAttribute('aria-label', 'Light ' + (i + 1)); c.addEventListener('pointerdown', function (e) { e.preventDefault(); tap(i); }); g.appendChild(c); cells.push(c); })(i);
      ui.num.textContent = lvl; ui.hint.textContent = 'Turn every light off'; render();
    }
    function reset() { lvl = 1; build(); }
    function tap(i) {
      if (lock) return; toggle(i); moves--; tone(330 + i * 12, 0.03, 0.25); render();
      if (!b.some(Boolean)) { lock = true; ui.hint.textContent = 'Lovely'; lvl++; s.later(build, 900); }
      else if (moves <= 0) { lock = true; s.end(lvl - 1, reset, 500); }
    }
    reset();
    return { stop: function () { s.done(); api.setBest(lvl - 1); freeAudio(); }, _t: function () { return { lvl: function () { return lvl; }, b: function () { return b; }, moves: function () { return moves; }, tap: tap }; } };
  }

  /* ---- icons ---- */
  var I = {
    drift: SV + '<circle cx="22" cy="40" r="11" stroke="' + hsl(212, 62) + '"/><circle cx="43" cy="26" r="8" stroke="' + hsl(262, 60, 68) + '"/><circle cx="40" cy="48" r="5" stroke="' + hsl(330, 58, 70) + '"/><circle cx="25" cy="13" r="4" stroke="' + hsl(190, 56, 62) + '"/></svg>',
    echo: SV + '<rect x="8" y="8" width="21" height="21" rx="7" fill="' + hsl(212, 66) + '" stroke="none"/><rect x="35" y="8" width="21" height="21" rx="7" stroke="' + hsl(262, 60, 68) + '"/><rect x="8" y="35" width="21" height="21" rx="7" stroke="' + hsl(330, 58, 70) + '"/><rect x="35" y="35" width="21" height="21" rx="7" stroke="' + hsl(160, 50, 56) + '"/></svg>',
    pairs: SV + '<rect x="6" y="14" width="23" height="34" rx="7" fill="' + hsl(262, 60, 70) + '" stroke="none"/><rect x="35" y="14" width="23" height="34" rx="7" stroke="' + hsl(212, 62) + '"/><circle cx="17.5" cy="31" r="5" fill="#fff" stroke="none"/></svg>',
    merge: SV + '<rect x="8" y="8" width="21" height="21" rx="7" fill="' + hsl(212, 66) + '" stroke="none"/><rect x="35" y="8" width="21" height="21" rx="7" fill="' + hsl(236, 62, 68) + '" stroke="none"/><rect x="8" y="35" width="21" height="21" rx="7" stroke="' + hsl(262, 58, 68) + '"/><rect x="35" y="35" width="21" height="21" rx="7" fill="' + hsl(290, 56, 70) + '" stroke="none"/></svg>',
    words: SV + '<rect x="5" y="20" width="16" height="24" rx="6" stroke="' + hsl(212, 62) + '"/><rect x="24" y="20" width="16" height="24" rx="6" fill="' + hsl(262, 60, 70) + '" stroke="none"/><rect x="43" y="20" width="16" height="24" rx="6" stroke="' + hsl(330, 58, 70) + '"/></svg>',
    pulse: SV + ring(0, 7, 222) + ring(0, 15, 250, 68) + ring(0, 24, 282, 70).replace('/>', ' stroke-opacity=".7"/>') + '</svg>',
    dim: SV + (function () { var o = '', on = { 1: 1, 3: 1, 4: 1, 5: 1, 7: 1 }; for (var i = 0; i < 9; i++) { var x = 8 + (i % 3) * 18, y = 8 + Math.floor(i / 3) * 18; o += '<rect x="' + x + '" y="' + y + '" width="14" height="14" rx="5"' + (on[i] ? ' fill="' + hsl(250, 62, 68) + '" stroke="none"' : '') + '/>'; } return o; })() + '</svg>'
  };

  [{ id: 'drift', name: 'Drift', tag: 'Pop the bubbles', icon: I.drift, start: drift },
    { id: 'echo', name: 'Echo', tag: 'Repeat the colours', icon: I.echo, start: echo },
    { id: 'pairs', name: 'Pairs', tag: 'Match the cards', icon: I.pairs, start: pairs },
    { id: 'merge', name: 'Merge', tag: 'Slide and combine', icon: I.merge, start: merge },
    { id: 'words', name: 'Word Mix', tag: 'Unscramble film words', icon: I.words, start: words },
    { id: 'pulse', name: 'Pulse', tag: 'Tap in perfect time', icon: I.pulse, start: pulse },
    { id: 'dim', name: 'Dim', tag: 'Switch all lights off', icon: I.dim, start: dim }
  ].forEach(G.add);
})();
