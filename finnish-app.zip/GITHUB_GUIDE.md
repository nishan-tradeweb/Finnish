# finnish – the easy way (from now on)
Creator: Nishan.

**One-time setup**
1. In your repository delete the old files `.github/workflows/build-apk.yml`, `build-exe.yml`, `pages.yml` (open the file → ⋯ menu → Delete file → Commit).
2. Add the new `build.yml`: **Add file → Create new file**, name it `.github/workflows/build.yml` (typing `/` makes folders), paste the full text of `build.yml`, **Commit**.

**Every update after that**
1. **Add file → Upload files**, upload `finnish-app.zip` (do NOT unzip it) to the repository root. If a file with that name exists, GitHub replaces it. **Commit changes**.
2. Open **Actions**: the run *Build finnish (APK + EXE)* starts by itself and builds the APK and the EXE at the same time (~10 min).
3. Download: **Code tab → Releases → "finnish – latest build"** → tap `finnish.apk` (Android) or the `.exe` files (Windows). (Also under Actions → the run → Artifacts.)

If something fails: open the red run → the red step → send the last red lines to Claude.

---
# Old detailed guide (first-time GitHub setup)
# finnish – from this folder to an APK and a Windows EXE, step by step
Creator: Nishan. You do **not** need to install Android Studio, Java or Node on your own computer: GitHub's free build servers (GitHub Actions) make both files for you.

## PART 1 – Create the GitHub account and the repository
1. Go to **github.com** → **Sign up** → enter e-mail, password, username → verify the e-mail code. (Skip if you already have an account.)
2. Click the **+** at the top right → **New repository**.
3. *Repository name*: `finnish`. Choose **Public** (Actions are free and unlimited for public repos; Private also works but uses your free monthly minutes). Leave all "Add a README / .gitignore / licence" boxes **unticked**. Click **Create repository**.

## PART 2 – Upload the project
Unzip `finnish-app.zip` on your computer. Inside you will see `www`, `electron`, `android-patch`, `assets`, `build`, `scripts`, `.github`, `package.json`, `capacitor.config.json`, `README.txt` …

**Method A – in the browser (no software)**
1. On the empty repository page click **uploading an existing file**.
2. Open the unzipped folder, select **everything inside it** (Ctrl+A) and drag it into the browser window. Wait until every file shows in the list (the `.github` folder is hidden on some systems – in Windows File Explorer tick *View ▸ Show ▸ Hidden items*; on Mac press Cmd+Shift+.).
3. GitHub allows 100 files per upload. If it complains, upload `www` first (commit), then the rest in a second round.
4. Scroll down → **Commit changes** (keep "Commit directly to the main branch").
5. Check that the repository now shows `.github/workflows/build-apk.yml`. If the `.github` folder is missing: **Add file ▸ Create new file**, type `.github/workflows/build-apk.yml` as the name (typing `/` makes folders), paste the file content, commit. Repeat for `build-exe.yml` and `pages.yml`.

**Method B – with Git (command line)** – install Git from git-scm.com, open a terminal in the unzipped folder:
```
git init
git add .
git commit -m "finnish v2"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/finnish.git
git push -u origin main
```
(When asked to log in, use your username and a **Personal Access Token** from GitHub ▸ Settings ▸ Developer settings ▸ Tokens (classic) ▸ tick `repo` and `workflow`.)

## PART 3 – Switch on Actions and build the APK
1. Open the repository → **Actions** tab. If you see "Workflows aren't being run on this repository", click **I understand my workflows, go ahead and enable them**.
2. Click **Build Android APK** in the left list → **Run workflow** (grey button, right) → branch `main` → green **Run workflow**.
3. Wait 6–12 minutes. A yellow dot = running, green tick = done, red cross = failed (see Part 7).
4. Click the finished run → scroll to **Artifacts** → click **finnish-apk** → a zip downloads; unzip it to get `finnish.apk`.

## PART 4 – Build the Windows EXE
1. **Actions** → **Build Windows EXE** → **Run workflow** → **Run workflow**.
2. After ~5–8 minutes open the run → **Artifacts** → **finnish-windows** → download and unzip. You get
   * `finnish-2.0.0-setup.exe` – the installer (adds Start-menu + desktop icon),
   * `finnish-2.0.0-portable.exe` – a single file you can run from a pen-drive, no install.

## PART 5 – Install on your devices
**Android phone**: copy `finnish.apk` to the phone (WhatsApp-to-self, USB, Drive) → tap it → if asked, allow "Install unknown apps" for that app (Files / Chrome) → **Install** → open **finnish**. It works with no internet; your scripts are stored inside the app (see the **Saved** tab).
**Windows PC**: double-click the installer (or portable exe). Windows SmartScreen may say "Windows protected your PC" because the app is not code-signed: click **More info ▸ Run anyway**. Scripts are saved as normal `.finnish` files wherever you choose (Save / Save As) and are also auto-saved inside the app.

## PART 6 – Making release links (optional, nicer)
Instead of "Run workflow", create a tag: repository → **Releases ▸ Draft a new release** → *Choose a tag* → type `v2.0.0` → **Create new tag** → **Publish release**. Both workflows start by themselves and attach `finnish.apk` and the `.exe` files to that release page, giving you permanent download links to share.

## PART 7 – If something fails
* Open the run → click the red step → read the last red lines. Copy them to Claude and ask for a fix.
* "fetch-fonts SKIP …" lines are harmless: the fonts then download from Google when the user is online the first time.
* APK step `npx cap add android` fails: check `package.json` was uploaded in the root of the repository (not inside another folder).
* The APK is a **debug-signed** build: perfect for your own phone. For Play Store you would add a release keystore (ask Claude to add it).
* Updating the app later: change files in the repository (or re-upload), then run the workflows again.

## PART 8 – Web version (optional)
**Settings ▸ Pages ▸ Source: GitHub Actions**, then **Actions ▸ Publish web version ▸ Run workflow**. You get a link such as `https://YOUR-USERNAME.github.io/finnish/`; open it in Chrome on the phone and use **Add to Home screen** to install it as an offline app (no APK needed).

## What was not tested here
The APK and EXE builds, the Android print plugin and Final Draft / Scriptty files from real users could not be built or tested in the sandbox where this was written; the web app itself, PDF export, and importers were tested with Chromium and sample files.
