# finnish – project handoff (read this first)

You are continuing a project started in another Claude account. The user is **Nishan** (creator; filmmaker, native Malayalam speaker). Environment notes: the user works mainly from an Android tablet/phone, builds APK/EXE on **GitHub Actions** (repo `gazaldarbar/finnish`, branch `main`), and uploads changed files through the GitHub web editor. So: **always send fixes as "replace only these files" with exact folder paths**, and keep answers short and step-by-step. He likes visual/iOS "liquid glass" design.

## What finnish is
Offline **Malayalam/English screenplay writer** (PWA wrapped as Android APK via Capacitor 7 and Windows EXE via Electron 35). Vanilla JS, no framework. Creator line in About: **"Creator : Nishan"**. Logo assets in `www/icons/` (wordmark + "fn" glass icon supplied by the user).

## Requirements the user set (all implemented unless noted)
1. Standard + **Two Column** formats; Malayalam Unicode fonts (Manjari, Meera, Rachana, Dyuthi, Chilanka, Gayathri, Noto Sans/Serif Malayalam, System); PDF export; fully offline; phone + PC.
2. Splash: full-screen liquid-glass, full logo, "by Nishan" (bold italic serif, black, right under logo).
3. Home: two big glass buttons **Standard / Two Column**; tabs **New script | Saved**; Import; About; Theme.
4. Wizard: cover (title, Writer, Director, Date-of-export) → paper **A4/Letter** → first page.
5. Editor: top **Next page** button; ribbon (undo/redo, element select, align, font, size, Colours, Reverse colours, Marker, Find, Scenes/Markers panel, Save, Export); bottom element bar + Manglish toggle; character-name suggestions.
6. Scene heading / character / parenthetical / transition always **bold**. Parenthetical auto-shows `( )` with cursor inside, centred like character (standard).
7. Cover page editable any time; printed first with **no** header/page number. Other pages: tiny title top-left + page number top-middle (CSS @page margin boxes). Known limit: cover counts as page 1 so first script page shows "2" (Chromium can't reset the page counter).
8. One-tap page/text colour presets, **Reverse** (swap, reversible), custom colours; 5-colour **line markers** (line or whole scene), Markers list.
9. Two column: vertical middle line in editor only (not printed); scene heading = two boxes (place | time) crossing the line; transition centred; **character name on the left of the middle line, right-aligned with " :", level with first dialogue line, dialogue on the right** (matches the user's "Nettottam" sample); action on left half.
10. Saving: autosave to IndexedDB (+ localStorage crash journal & recovery), **Save / Save As**; phone saves inside app and lists under **Saved** tab; PC uses File System Access / Electron save dialog (`.finnish`); Android Save As uses system "Save as" dialog.
11. Import: Final Draft `.fdx`, Scriptty `.screenplay` (heuristic – schema undocumented), Fountain/text, `.finnish`. **PDF import was deliberately dropped** (user chose that; explain to export .fdx/Fountain from Final Draft). Export: PDF, FDX, Fountain, `.finnish` backup.
12. Android "Open with finnish" for downloaded files (intent filters + `getPending`).
13. UI/UX reference PDF + two sample screenshots were supplied; skipped items (honest): edge scrubber, stylus layer, voice dictation, right inspector, pinch-to-PDF.

## Code map
- `www/index.html`, `www/style.css` – shell + liquid-glass CSS (themes via `data-theme`).
- `www/app.js` – everything UI/editor: doc model (`blocks:[{id,t,x,x2?,al?,mk?,pb?}]`, fields title/writer/director/date/fmt/paper/font/size/pageColor/textColor), storage (IDB `finnish`/`docs`), history, Manglish (`tlType`/`tlBack` using `ML.translit`), events (`onKey` etc.), ribbon, side panel (closes on outside click), find/replace, save/save-as/deliver, import, boot. Contains an injected `EXTRA_CSS` string in `bind()` for std/two-col char/paren/dial rules.
- `www/export.js` – Fountain, `THK.buildPrint/printDoc/printScript` (print engine; two-col uses float for char), fonts list `THK.FONTS`, `THK.fp()` = native Android helper accessor (via `Capacitor.nativePromise`), Electron `finnishNative`.
- `www/import.js` – FDX + Scriptty parse/serialize. `www/translit.js` – Manglish→Malayalam. `www/sw.js` – offline cache (VERSION `finnish-v3`).
- `electron/` (main.js, preload.js – IPC pdf/saveFile/saveText), `android-patch/` (`MainActivity.java`, `FinnishPrintPlugin.java`: print to PDF via attached 2×2 WebView + PrintManager, ACTION_CREATE_DOCUMENT save, getPending for Open-with), `scripts/patch-android.sh` (copies Java, adds androidx.webkit, patches AndroidManifest intent-filters), `scripts/fetch-fonts.mjs` (Manjari/Chilanka/Gayathri from google/fonts in CI), `.github/workflows/` (build-apk.yml, build-exe.yml, pages.yml), `package.json`, `capacitor.config.json`, `assets/`, `build/icon.ico`.
- `GITHUB_GUIDE.md` – step-by-step GitHub/APK/EXE guide. `README.txt`.

## Fix history (what broke on real devices and how it was solved)
- Windows EXE failed: `${target}` placeholder in electron-builder artifactName → replaced with per-target names.
- Android PDF closed silently / exports "downloaded" without saving: plugin not found + detached WebView → `THK.fp()` via `nativePromise`, native save dialog, print WebView attached.
- Added Open-with, parenthetical brackets, side-panel close, two-column char-left layout (all verified in Chromium; Android parts confirmed working by the user after rebuild).

## State at handoff
Everything above works on the user's phone/tablet (APK) per his last reports. Latest code is in this zip (equal to the files the user uploaded in fix1–fix4, plus the original v2 baseline). The user should check his GitHub repo matches; if unsure, re-upload from this zip.

## Ideas the user is considering next (UI polish round)
Mockups first (2–3 styles), then change one screen at a time. Candidates: focus/zen mode, paper texture + page-break tabs, film-style home with script "posters", scene card board (drag reorder), contextual element bar, character list panel, daily word/page goal, dark paper themes, haptics/typewriter sound. Open questions asked of the user: glassy vs calmer minimal; phone or tablet primary; which idea first.

## Known limitations / honest notes
APK/EXE can only be built on GitHub (not in the sandbox). Scriptty importer is a best guess. Page numbers count the cover. Manjari/Chilanka/Gayathri come from CI download or Google Fonts when online first. Manglish typing needs a physical keyboard (phones should use a Malayalam keyboard).
