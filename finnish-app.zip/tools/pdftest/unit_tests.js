/* quick unit tests for the importer's rules (no PDF needed).  node unit_tests.js */
const fs=require('fs'),path=require('path'),assert=require('assert');
global.window={};global.document={baseURI:'',createElement:()=>({}),head:{appendChild(){}}};
global.THK={newImportDoc:t=>({title:t,blocks:[]}),defaultFont:()=>'x',lang:()=>({rtl:false}),stripSn:x=>x};
(0,eval)(fs.readFileSync(path.join(__dirname,'../../www/pdfimport.js'),'utf8'));
const row=(y,x,t)=>({y,sz:12,segs:[{x0:x,x1:x+t.length*6,t}]});
const page=rows=>({w:612,h:792,rows});
function run(lines){let y=700;const rows=[];lines.forEach(l=>{if(l===null){y-=12;return}rows.push(row(y,l[0],l[1]));y-=12});
 const pg=[];for(let i=0;i<3;i++)pg.push(page(rows.map(r=>({...r,y:r.y}))));return THK.pdfPagesToScript(pg,'t.pdf').blocks.map(b=>b.t+':'+b.x)}
let n=0;const t=(name,fn)=>{try{fn();console.log('ok  ',name);n++}catch(e){console.log('FAIL',name,'-',e.message)}};
t('standard layout',()=>{const b=run([[108,'INT. ROOM - DAY'],null,[108,'Rain taps the window.'],null,[252,'RAVI'],[180,'Anybody there?'],null,[432,'CUT TO:'],null,[108,'EXT. STREET - NIGHT'],null,[108,'A bus passes.'],null,[252,'ANITA'],[216,'(softly)'],[180,'Come to bed.']]);
 assert(b.includes('scene:INT. ROOM - DAY'));assert(b.includes('char:RAVI'));assert(b.includes('dial:Anybody there?'));assert(b.includes('paren:softly'));assert(b.some(x=>x.startsWith('trans:CUT TO')))});
t('CONT\'D is stripped from names',()=>{const b=run([[108,'INT. A - DAY'],null,[252,"RAVI (CONT'D)"],[180,'Yes.'],null,[108,'INT. B - DAY'],null,[252,'RAVI'],[180,'No.']]);assert(b.includes('char:RAVI'))});
console.log(n+' passed');
