/* Step 3 – accuracy harness. Compares the importer to the (corrected) ground_truth files, line by line.
   usage: node run_tests.js [--min 0.90]     exit code 1 when overall accuracy is below the minimum (use it as a build gate)
   Lines are matched in order by their text (whitespace-insensitive); the type must also match. Drafts that were never corrected measure 100% by construction – set "draft":false in a file once you have checked it. */
const fs=require('fs'),path=require('path');
global.window={};global.document={baseURI:'',createElement:()=>({}),head:{appendChild(){}}};
global.THK={newImportDoc:t=>({title:t,blocks:[]}),defaultFont:()=>'x',lang:()=>({rtl:false}),stripSn:x=>x.replace(/^\s*\d{1,4}[A-Z]?\s+(?=\S)/,'')};
(0,eval)(fs.readFileSync(path.join(__dirname,'../../www/pdfimport.js'),'utf8'));
const min=+(process.argv[process.argv.indexOf('--min')+1])||0.90,norm=s=>s.replace(/\s+/g,' ').trim().slice(0,60);
const by={type:{},source:{},language:{}};let ok=0,tot=0,skipped=0;
const add=(g,k,hit)=>{const o=g[k]||(g[k]={ok:0,n:0});o.n++;if(hit)o.ok++};
for(const f of fs.readdirSync('ground_truth')){const gt=JSON.parse(fs.readFileSync('ground_truth/'+f));if(gt.draft){skipped++;continue}
 let d;try{d=THK.pdfPagesToScript(JSON.parse(fs.readFileSync('cache/'+gt.file+'.json')),gt.file)}catch(e){console.log('FAIL',gt.file,e.message.slice(0,80));gt.lines.forEach(l=>{tot++;add(by.type,l.type,0);add(by.source,gt.source,0);add(by.language,gt.language,0)});continue}
 const got=d.blocks;let j=0;
 gt.lines.forEach(l=>{let k=j,hit=false;while(k<Math.min(got.length,j+6)){if(norm(got[k].x).startsWith(norm(l.text).slice(0,20))||norm(l.text).startsWith(norm(got[k].x).slice(0,20))){hit=got[k].t===l.type;j=k+1;break}k++}
  tot++;if(hit)ok++;add(by.type,l.type,hit);add(by.source,gt.source,hit);add(by.language,gt.language,hit)});}
const pr=(t,g)=>{console.log('\nby '+t);Object.keys(g).sort().forEach(k=>console.log('  '+k.padEnd(14),(100*g[k].ok/g[k].n).toFixed(1)+'%','('+g[k].n+' lines)'))};
pr('element type',by.type);pr('source',by.source);pr('language',by.language);
console.log('\nverified files: '+(fs.readdirSync('ground_truth').length-skipped)+', draft files skipped: '+skipped);
if(!tot){console.log('No corrected ground-truth files yet (all are drafts).');process.exit(0)}
const acc=ok/tot;console.log('overall accuracy',(acc*100).toFixed(1)+'%','(minimum '+(min*100)+'%)');process.exit(acc<min?1:0);
