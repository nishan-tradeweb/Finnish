/* Step 1 – read every PDF in a folder with the app's own PDF reader (pdf.js) and save the text rows with coordinates.
   usage:  node extract.js <pdf-folder> [name-filter]      (needs: npm i playwright, and the app served on http://localhost:8765/)
   output: cache/<file>.json  (one entry per page: {w,h,rows:[{y,sz,segs:[{x0,x1,t}]}]}) */
const {chromium}=require('playwright');const fs=require('fs'),path=require('path');
const PDFDIR=path.resolve(process.argv[2]||'test_data'),only=process.argv[3],URL=process.env.APP||'http://localhost:8765/';
(async()=>{fs.mkdirSync('cache',{recursive:true});const b=await chromium.launch();const p=await (await b.newContext({serviceWorkers:'block'})).newPage();
await p.route('**/__pdf/**',r=>{const f=decodeURIComponent(r.request().url().split('/__pdf/')[1]);r.fulfill({body:fs.readFileSync(path.join(PDFDIR,f)),contentType:'application/pdf'})});
await p.goto(URL);await p.waitForTimeout(2500);
for(const f of fs.readdirSync(PDFDIR).filter(x=>/\.pdf$/i.test(x))){
 if(only&&f.indexOf(only)<0)continue;const o='cache/'+f+'.json';if(fs.existsSync(o))continue;const t0=Date.now();
 const r=await p.evaluate(async f=>{try{const buf=await (await fetch('/__pdf/'+encodeURIComponent(f))).arrayBuffer();
  const m=await import(new URL('vendor/pdfjs/pdf.min.js',document.baseURI).href);m.GlobalWorkerOptions.workerSrc=new URL('vendor/pdfjs/pdf.worker.min.js',document.baseURI).href;
  const doc=await m.getDocument({data:new Uint8Array(buf),cMapUrl:new URL('vendor/pdfjs/cmaps/',document.baseURI).href,cMapPacked:true,isEvalSupported:false,useSystemFonts:true,verbosity:0}).promise;
  const out=[];for(let i=1;i<=Math.min(doc.numPages,400);i++){const pg=await doc.getPage(i);const vp=pg.getViewport({scale:1});const tc=await pg.getTextContent();out.push(THK._pageRows(tc,vp.width,vp.height));}
  return out}catch(e){return {err:String(e)}}},f);
 if(r.err){console.log('ERR',f,r.err);continue}
 fs.writeFileSync(o,JSON.stringify(r));console.log(f,r.length,'pages',((Date.now()-t0)/1000)|0,'s');}
await b.close()})();
