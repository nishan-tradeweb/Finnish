/* Step 2 – run the importer on the cached rows and write a DRAFT ground-truth file you can correct.
   usage: node classify.js            -> ground_truth/<file>.json  (lines marked "u":1 are low-confidence – check those first)
   Existing files are NOT overwritten unless you pass --force. */
const fs=require('fs'),path=require('path');
global.window={};global.document={baseURI:'',createElement:()=>({}),head:{appendChild(){}}};
global.THK={newImportDoc:t=>({title:t,blocks:[]}),defaultFont:()=>'x',lang:()=>({rtl:false}),stripSn:x=>x.replace(/^\s*\d{1,4}[A-Z]?\s+(?=\S)/,'')};
(0,eval)(fs.readFileSync(path.join(__dirname,'../../www/pdfimport.js'),'utf8'));
const META=JSON.parse(fs.existsSync('meta.json')?fs.readFileSync('meta.json','utf8'):'{}');
fs.mkdirSync('ground_truth',{recursive:true});const force=process.argv.includes('--force');
for(const f of fs.readdirSync('cache')){const name=f.replace(/\.json$/,''),out='ground_truth/'+name.replace(/\.pdf$/i,'')+'.json';
 if(fs.existsSync(out)&&!force)continue;
 try{const d=THK.pdfPagesToScript(JSON.parse(fs.readFileSync('cache/'+f)),name);const m=META[name]||{};
  fs.writeFileSync(out,JSON.stringify({file:name,source:m.source||'unknown',language:m.language||'?',draft:true,lines:d.blocks.map(b=>{const o={text:(b.t==='scene'?b.x:b.x).slice(0,160),type:b.t};if(b.c<0.75)o.u=1;return o})}));
  console.log('draft',out,d.blocks.length,'lines,',d.blocks.filter(b=>b.c<0.75).length,'uncertain');
 }catch(e){console.log('skip',name,'-',e.message.slice(0,80))}}
