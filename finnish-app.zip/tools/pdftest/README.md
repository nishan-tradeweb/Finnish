# PDF importer test kit

Runs on a computer with Node 18+ (not on the phone).

    npm i playwright && npx playwright install chromium
    cd www && python3 -m http.server 8765 &          # serve the app
    cd tools/pdftest
    node unit_tests.js                                # rule tests, no PDFs needed
    node extract.js /path/to/test_data/final_draft    # repeat per folder (word, scanned, other_languages)
    node classify.js                                  # writes draft ground truth into ground_truth/
    # open ground_truth/*.json, fix wrong "type" values (lines with "u":1 are the uncertain ones), then set "draft": false
    node run_tests.js --min 0.90                      # accuracy per type / source / language, exit 1 under 90%

meta.json maps each PDF file name to {source, language} (final_draft | word | scanned | subtitle ...).
Draft files measure 100% by construction – only files with "draft": false are scored.
