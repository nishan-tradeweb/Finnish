const {chromium}=require('playwright');const fs=require('fs');
const files=process.argv.slice(2);
(async()=>{const b=await chromium.launch();const ctx=await b.newContext({serviceWorkers:'block'});
for(const f of files){const p=await ctx.newPage();
await p.route('**/__pdf/**',r=>{const n=decodeURIComponent(r.request().url().split('/__pdf/')[1]);r.fulfill({body:fs.readFileSync(process.env.PDFDIR+'/'+n),contentType:'application/pdf'})});
await p.goto('http://localhost:8765/');await p.waitForTimeout(1200);
const t0=Date.now();
const r=await p.evaluate(async f=>{try{const ab=await (await fetch('/__pdf/'+f)).arrayBuffer();const d=await THK.parsePdf(ab,f);const bl=d.blocks;const cnt={};bl.forEach(x=>cnt[x.t]=(cnt[x.t]||0)+1);
 const sq=bl.filter(x=>x.t==='scene').slice(0,3).map(x=>x.x);const ch=bl.filter(x=>x.t==='char').slice(0,3).map(x=>x.x);const di=bl.filter(x=>x.t==='dial').slice(2,5).map(x=>x.x.slice(0,70));
 const box=bl.filter(x=>x.x&&x.x.indexOf('□')>=0).length;
 return {n:bl.length,cnt,sq,ch,di,box,imp:{warn:d._imp.warn.map(w=>w.slice(0,90)),method:d._imp.method,ocr:d._imp.ocr},title:d.title}}catch(e){return {err:e.message}}},f);
console.log('==',f.slice(0,28),((Date.now()-t0)/1000).toFixed(1)+'s');console.log(JSON.stringify(r));await p.close()}
await b.close()})();
